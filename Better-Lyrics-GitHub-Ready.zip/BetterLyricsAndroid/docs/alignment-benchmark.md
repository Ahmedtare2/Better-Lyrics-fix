# Word-alignment benchmark data

`org.betterlyrics.android.alignment.AlignmentBenchmark` evaluates predictions against
manually annotated word occurrences. It does not create references and does not load or
run audio models. Current unit tests use synthetic timing objects solely to test metric
calculations; they are **not** accuracy results for songs.

## Annotation workflow

1. Use a recording you have permission to retain and distribute.
2. Manually verify each lyric occurrence against the recording. Assign a unique occurrence
   `id` (repeated chorus words must have different IDs), original displayed `text`, begin/end
   seconds, and singer/agent ID.
3. Add tags at the case or word level as appropriate: `arabic`, `english`, `mixed`,
   `egyptian`, `rap`, `sustained`, `repeated-chorus`, `multiple-singers`, `backing-vocals`.
4. Store reference and engine predictions separately in a dataset using schema version 1.
   Never use engine output as the reference.
5. Keep audio, annotation provenance, and dataset access controlled according to recording
   rights. Do not check in private recordings, lyrics, or personal metadata without permission.
6. Run the benchmark against the same fixed dataset before and after an alignment change.

Dataset Kotlin types and JSON codec:

```kotlin
val dataset = AlignmentBenchmark.parseDataset(jsonText)
val report = AlignmentBenchmark.evaluate(dataset)
```

The report includes overall metrics and per-tag subsets. Boundary error is reported in
seconds. Combined MAE/median/P90 are calculated over start and end boundary absolute errors.
Word coverage is uniquely matched occurrence IDs divided by reference occurrences. Missing,
extra, duplicate, invalid predictions and unintended same-singer overlaps are counted
separately. An overlap that is present in the reference is not penalized. Confidence expected
calibration error is withheld unless at least 20 matched predictions carry confidence values;
“correct” means both boundaries are within 80 ms for that calibration measure.

No real-song benchmark dataset is currently included, so no real-world accuracy percentage
is available or claimed.
