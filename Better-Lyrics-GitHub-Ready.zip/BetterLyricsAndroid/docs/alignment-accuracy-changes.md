# Alignment accuracy changes

Verification status: Kotlin syntax checked with kotlinc 2.0.20; the new resampler is covered by a
numeric test (pass-band gain, alias rejection, timing). **No real-song accuracy has been measured**
(see `alignment-benchmark.md`): run `AlignmentBenchmark` on a fixed hand-annotated set before/after.

1. **Restored the CTC Viterbi aligner as the main path.** A later refactor replaced it with a
   text-length-weighted split of each line window (wav2vec2 output computed, then discarded) and left
   `alignTokensInWindow` / `reconcileCrossLineTransitions…` unreachable. The original engine is back
   (multi-stem candidates, wider-window retry, left-edge clip detection, background-vocal alignment,
   cross-line reconciliation).
2. **Dropped `enforceChorusContinuity`.** It shifted repeated lines by half the difference between
   each line's duration and the median duration (using the median of *absolute* start times of
   different chorus occurrences), which can only add error. Also dropped the refactor's edits to the
   vocabulary fallbacks (`<s>`/`<unk>` chain, a bogus English fallback key).
3. **Anti-aliased resampling.** All three resamplers (CTC 44.1k->16k, stereo mono-mix, decoder
   48k->44.1k) now share `BandLimitedResampler`: polyphase windowed-sinc, cutoff 90 % of the target
   Nyquist, ~70 dB stop-band. The old cubic interpolation had no low-pass filter, so 9-21 kHz content
   (measured -0.3 .. -3 dB, i.e. essentially un-attenuated) folded into the 0-8 kHz band.
4. **`OnnxProviders`** reduced to the Demucs session settings that are actually used (the NNAPI/GPU
   "config entries" were ignored by ONNX Runtime).
5. **Optional FP32 Arabic model** via the `arabic_fp32` workflow input.

Not changed on purpose (needs benchmark data first): emission weights / voicing gates in the trellis,
sustain-end thresholds, the 10 ms frame-centre offset, Demucs overlap, the model-output cache.

## Round 2 - fixes derived from the Banadeek Taala benchmark (app TTML vs hand-refined TTML)

Baseline measured on 119 words: 29% of words within 80 ms, median word error 888 ms, P90 ~3 s. The first word of a line
was the weakest (11% within 80 ms). The refined file showed that the CTC end of the first word was almost always right,
while its begin had been pulled back to the end of the previous line.

1. `reconcileCrossLineTransitionsAndBuildDiagnostics`: the energy scan that starts at the previous line's end may no longer
   move the next line's first word more than 120 ms earlier than its CTC onset (unless the LRC stamp really clipped the
   left window edge). This stops the first word from swallowing instrumental gaps / bleed.
2. Same function: the "carried vowel" extension of the previous line's last word is capped at +0.60 s and at the CTC onset
   of the next line, which previously pushed the next line's start late.
3. New `repairUnassignedVocalGaps` (runs before the reconcile step): if >= 1.5 s of clearly active vocal stem lies between
   a line's last word and the next line's first word, the line is aligned again with the window extended up to that onset.
   The result is kept only when it uses the gap, word lengths stay plausible and CTC confidence is not worse.
   `alignTokensInWindow` got an optional `maxPhraseSec` (default 12 s, identical behaviour) so such windows can be longer.

Not changed on purpose: CTC lattice, emission gates, sustain refinement, 5 ms attack refinement.

## Round 3 - after the second benchmark run (v2 build output)

The v2 fixes changed only 15 of 119 words, so the first-word problem was not coming from the reconcile step alone.
New evidence: the 13 refrain lines ("بناديك تعالى، بناديك تعالى") scored 22% of boundaries within 80 ms against 61% for all
other lines. Typical failure: first three words packed into ~0.7 s, last word ~2.6 s (hand timing: ~1 s each).

1. Stage 2B lead/backing separation is no longer run. The aligner, onset analysis and onset snapper use the full HTDemucs
   vocal stem only. The heuristic separator removed/smeared the chorus responses that are part of the sung lyrics, and it
   cost time and memory. (`AlignmentForegroundServiceAndModelManager.kt`)
2. `redistributeCrushedWords`: if the last word of a line (>= 3 words, span >= 1.2 s) is >= 3x its letter-proportional
   share while the other words average < 0.5x, the words are laid out proportionally to letter count over the existing
   span. Offline check on the benchmark: lines 15, 16, 17, 21 improved from 0.9-1.0 s to 0.06-0.24 s mean boundary error.
3. `trimSilentLeadIn`: a first word >= 1.2 s that starts with >= 0.6 s of true silence (< 4% of its own peak RMS) now begins
   where the silence ends.

## Round 4 - v3 benchmark, neighbour context, overlap, exports, history

v3 vs hand-refined file: median boundary error 323 -> 180 ms, mean 849 -> 688 ms, but within-80-ms share fell 44.5% -> 38.7%.
Cause: removing Stage 2B made line-final words run to the 2.6 s hold limit (L6 +1.4 s, L26 +1.3 s, 13 lines), because the full
stem keeps chorus tails alive. Stage 2B is therefore ON again (v2 behaviour). The reference also shows that 10 of 26 line
transitions overlap by 0.07-0.41 s (a held word while the next line starts).

1. Stage 2B restored.
2. `refineWithNeighborContext` (config `enableNeighborContextAlignment`, default on): each v1 line is aligned again in one CTC
   window together with the previous and next line (pair when the triple exceeds 22 s). Only the middle line's words are
   kept, and only when CTC confidence is not worse (suspicious lines) or clearly better (+0.02, normal lines); changes < 40 ms
   are ignored. This fixes lines whose LRC stamp is seconds off and held words that run into the next line (L13/14, L19/20, L9).
3. Pass order after the per-line loop: trim silent lead-in -> unassigned-gap repair -> neighbour context -> crushed-line guard -> reconcile.
4. Reconcile: a short (<= 0.45 s) overlap with the previous line no longer pushes the next line's first word late; the held
   word is trimmed to the CTC onset instead.
5. New: export of the separated vocals as AAC (.m4a, MediaCodec) or WAV from the Home tab (no MP3: Android has no MP3 encoder).
6. New: Alignment History (Home tab). Every finished alignment saves its TTML to app storage; Open / Export .ttml / Delete.

## Round 5 (v5) – corrective build after scoring v4 against the hand-refined reference

Scored on "Banadeek Taala" (pooled boundary error, mean / median): v3 688 / 182 ms, v4 831 / 220 ms. v4 was worse.

* **Neighbour-line context pass disabled by default** (`enableNeighborContextAlignment = false`). It scrambled word order on refrains (L5, L10, L17/L18).
* **Stage 2B (lead/backing separation) removed again.** CTC alignment and onset snapping use the combined HTDemucs vocal stem, which gave the better refrain lines in v3.
* **Final-word cap** (`maxFinalWordDurationSec = 1.8`): applied after the Stage 4 snapper, whose sustained-voice follower ran line-final words to the 2.6 s ceiling. Offline on v3 output the mean last-word end error fell 0.60 s -> 0.44 s and lines within 0.2 s rose 42% -> 50%.
* **Crushed-word guard now runs after the snapper** (it never fired in v4 because the snapper creates the pattern afterwards).
* Vocal export (.m4a/.wav) and alignment history are unchanged.

## Round 5.1 (v5.1) – scored v5 (pooled mean/median 683/174 ms, best so far) and fixed what remained

* **First word no longer starts in silence** (`trimLeadInToVocalOnset`, runs after Stage 4): the begin moves to the first sustained voiced stretch of the stem. Offline on v5 output first-word begin error 1.68 s -> 0.84 s (L19 "لمس" started 13.7 s early, L2/L3/L22/L23 1.8-2.9 s early).
* **Neighbour-context pass re-enabled for non-refrain lines only.** v4 vs v5 on unique lyric lines: median error 1 ms vs 109 ms; on refrains v4 was far worse (845 vs 457 ms). Lines that repeat a word, or whose words are a subset of another line, are skipped.

## Round 5.2 (v5.2) – scored v5.1 (pooled mean/median 614/148 ms, best so far)

* **Squeezed first words** (~0.12 s while the singer is already holding the word; L4, L6, L8, L12, L18, L27): after Stage 4 the begin moves to the latest clear (>= 8 dB) energy valley 0.25-2.2 s before the squeezed begin. Offline on v5.1 output all six lines move toward the reference (e.g. L12 95.02 -> 94.16, reference 94.16; L6 65.15 -> 64.23, reference 64.30). The previous line's last word is trimmed so they do not overlap.
* **Lead-in trim now runs before the repair passes** (with the robust 20 s reference level and sustained-onset test). Previously a first word spanning a long instrumental gap (L19) was not trimmed until the end, so the neighbour-context window for L19/L20 was > 22 s and was skipped, leaving the rest of the line (قلبي ... عليه) squeezed.

## Round 5.3 (v5.3) – scored v5.2 (pooled mean/median 582/128 ms, best so far)

* **Swallowed lines** (L13 تصدقني… / L14 and L19 لمس… / L20): the line is squeezed into its short LRC slot (median word < 0.4 s) and the NEXT line's first word absorbs the rest (7.0 s and 3.9 s long). Two repairs:
  1. `repairSwallowedLines` (CTC, before the other repair passes): aligns line i together with the next line's first word in one window ending at the swallowing word's end; accepted only when line i gets plausible word lengths.
  2. `redistributeSwallowedLine` (deterministic fallback after Stage 4): strict test (also requires the stem to keep singing through the span), then words 2..n are laid out letter-proportionally up to `next.first.end - 1.2 s`. Offline on the v5.2 output the mean error of these 17 words falls from 2.43 s to 0.46 s. The detector fires on exactly these two line pairs and on none of the other 25.

## Round 5.4 (v5.4) – scored v5.3 (pooled mean/median 339/159 ms; v5.2 was 582/128)

* v5.3 repaired the swallowed lines: L13 total error 42.9 s -> 9.9 s, L19 26.6 s -> 4.1 s, L14 and L20 also better.
* **Threshold fix:** the squeezed-first-word rule used `< 0.30 s`; L12's first word came out 0.301 s and was skipped. Now `< 0.35 s` (offline: 7 hits on v5.1 output, one near-miss, no new harm on v5.2/v5.3 output). The "first words crushed, last word huge" guard now runs after that rule instead of before it, because L4 was being laid out letter-proportionally from the wrong start.
* **Early-start probe (overlapping lines)** `probeEarlierLineStarts`, `enableEarlyStartProbe = true`: each line is aligned a second time in a window that starts up to 2.4 s before its first word. The singer begins 0.4-2.0 s before the LRC stamp on ~25% of the benchmark lines (L7-L10, L14/L15, L20/L21, L24/L25, L27) while the previous line's last word is still held. The new timing is accepted only if the first word starts >= 0.40 s earlier, the stem is voiced between the new and old start, an energy valley (>= 6 dB) sits within 0.25 s of the new start, CTC confidence is not worse, word lengths are plausible and the line does not end later. Not testable offline (needs the CTC model) - verify on device.

## Round 5.5 (v5.5) – scored v5.4 (pooled mean/median 296/116 ms, within-80 ms 45%, best so far)

v5.4 improved L10, L11, L12, L17 and L27 (early-start probe and valley fixes). Two lines got worse because an earlier start cut the previous line's last word:
* L8 started on a word boundary inside L7 (74.44 s; reference 75.51 s), leaving L7's last word 0.26 s long.
* L21 overshot (157.20 s; reference 157.70 s) and left L20's last word 0.12 s long.

Fix: a line may no longer start earlier than 0.30 s after the BEGIN of the previous line's last word (both in the early-start probe and in the squeezed-first-word valley rule). Overlap with the tail of that word is still allowed.

## Round 5.6 (v5.6) – scored v5.5 (317/113 ms; v5.4 was 296/116) and reverted its probe rule

The v5.5 "do not start before the previous last word" rule in the early-start probe cost more than it gained: L10 lost 4.7 s (the previous line L9 was itself 1.75 s late, so the rule blocked the correct start), L20 gained 0.8 s, L8/L7 did not change at all (their early L8 start does not come from that rule). The rule is removed from the probe again; it stays in the post-Stage-4 first-word valley rule. Expected result: v5.4 behaviour (296/116 ms).

## Round 5.7 (v5.7) – second benchmark song (Beit Kebeer, Tamer Ashour) scored against its hand-refined TTML

v5.6 on Beit Kebeer: pooled boundary error mean 211 ms, median 0 ms (102 of 200 words identical to the reference), within 80 ms 66%. Non-last words: mean 156 ms; LAST words: mean 474 ms (34% within 80 ms).

* The 1.8 s final-word cap (fitted on Banadeek Taala) cut real held notes in Beit Kebeer (reference last words of 2.3, 3.1, 4.0 and 4.8 s came out as exactly 1.80 s). It now applies only when the next line starts within 3.3 s of the word's begin; before a long gap or at the end of the song the snapper's own hold is kept. Banadeek Taala is unaffected (all its capped words were followed by the next line within ~1 s).
* Not fixed (needs the vocal stem of this song to test): (a) overlap where the last word is held under the next line (L22 -> L23, 3.4 s overlap; L25 -> L26, 1.7 s): the held word ends 3.0 s early and the next line starts 0.7-1.2 s late; (b) L14 squeezed into a 1.5 s LRC slot although the line lasts 4.5 s (gap repair did not fire).
