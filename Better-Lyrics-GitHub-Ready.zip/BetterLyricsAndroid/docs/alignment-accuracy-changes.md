# Alignment accuracy changes

Verification status: Kotlin syntax checked with kotlinc 2.0.20; the new resampler is covered by a
numeric test (pass-band gain, alias rejection, timing). **No real-song accuracy has been measured**
(see `alignment-benchmark.md`): run `AlignmentBenchmark` on a fixed hand-annotated set before/after.

1. **Restored the CTC Viterbi aligner as the main path.** A later refactor replaced it with a
   text-length-weighted split of each line window (wav2vec2 output computed, then discarded) and left
   `alignTokensInWindow` / `reconcileCrossLineTransitions…` unreachable. The original engine is back
   (multi-stem candidates, wider-window retry, left-edge clip detection, background-vocal alignment,
   cross-line reconciliation).
2. **Dropped `enforceChorusContinuity`.** It shifted repeated lines by half the difference between
   each line's duration and the median duration (using the median of *absolute* start times of
   different chorus occurrences), which can only add error. Also dropped the refactor's edits to the
   vocabulary fallbacks (`<s>`/`<unk>` chain, a bogus English fallback key).
3. **Anti-aliased resampling.** All three resamplers (CTC 44.1k->16k, stereo mono-mix, decoder
   48k->44.1k) now share `BandLimitedResampler`: polyphase windowed-sinc, cutoff 90 % of the target
   Nyquist, ~70 dB stop-band. The old cubic interpolation had no low-pass filter, so 9-21 kHz content
   (measured -0.3 .. -3 dB, i.e. essentially un-attenuated) folded into the 0-8 kHz band.
4. **`OnnxProviders`** reduced to the Demucs session settings that are actually used (the NNAPI/GPU
   "config entries" were ignored by ONNX Runtime).
5. **Optional FP32 Arabic model** via the `arabic_fp32` workflow input.

Not changed on purpose (needs benchmark data first): emission weights / voicing gates in the trellis,
sustain-end thresholds, the 10 ms frame-centre offset, Demucs overlap, the model-output cache.
