# Keep ONNX Runtime JNI bindings and WebView JavascriptInterface bridge methods
-keep class ai.onnxruntime.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn ai.onnxruntime.**
