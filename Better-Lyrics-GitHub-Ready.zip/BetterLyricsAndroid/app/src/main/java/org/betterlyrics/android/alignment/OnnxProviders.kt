package org.betterlyrics.android.alignment

import ai.onnxruntime.OrtSession

/**
 * ONNX Runtime session settings shared by the DSP code.
 *
 * Note: these are plain CPU-execution-provider settings. Hardware delegates (NNAPI / XNNPACK) are
 * deliberately NOT enabled: wav2vec2 uses dynamic input lengths and dynamically-quantized INT8
 * MatMul nodes, which NNAPI partitions poorly and can compute with different numerics. Enable one
 * only after measuring it with `AlignmentBenchmark` on a fixed, hand-annotated dataset.
 */
object OnnxProviders {

    /**
     * NO_OPT prevents constant-folding of FP16 casts (critical for HTDemucs): with graph
     * optimisation enabled the Cast(FP16->FP32) nodes are folded at load time and RAM triples.
     */
    fun createSessionOptionsNoOpt(): OrtSession.SessionOptions {
        return OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.NO_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            setInterOpNumThreads(1)
            setMemoryPatternOptimization(false)
            setCPUArenaAllocator(false)
        }
    }
}
