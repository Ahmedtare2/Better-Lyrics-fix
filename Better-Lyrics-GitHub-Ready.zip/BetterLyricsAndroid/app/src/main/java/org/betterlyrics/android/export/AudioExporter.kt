package org.betterlyrics.android.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.min

/**
 * Exports the separated stems that the pipeline writes as 16-bit PCM WAV files.
 *
 * Android ships an AAC encoder (MediaCodec) but no MP3 encoder, so the compressed export is AAC-LC in an
 * MPEG-4 audio container (.m4a), which every phone, computer and music player can open.
 */
object AudioExporter {

    private data class WavInfo(
        val channels: Int,
        val sampleRate: Int,
        val dataOffset: Long,
        val dataSize: Long
    )

    private fun readLeInt(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or
            ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or
            ((b[off + 3].toInt() and 0xFF) shl 24)

    private fun readLeShort(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)

    /** Parses a RIFF/WAVE header; only 16-bit PCM is supported (that is what the pipeline writes). */
    private fun readWavInfo(file: File): WavInfo? {
        RandomAccessFile(file, "r").use { raf ->
            val length = raf.length()
            val riff = ByteArray(12)
            if (length < 44 || raf.read(riff) != 12) return null
            if (String(riff, 0, 4, Charsets.US_ASCII) != "RIFF" || String(riff, 8, 4, Charsets.US_ASCII) != "WAVE") return null

            var channels = 0
            var sampleRate = 0
            var bits = 0
            var format = 0
            var pos = 12L
            val header = ByteArray(8)
            while (pos + 8 <= length) {
                raf.seek(pos)
                if (raf.read(header) != 8) return null
                val id = String(header, 0, 4, Charsets.US_ASCII)
                val size = readLeInt(header, 4).toLong() and 0xFFFFFFFFL
                val body = pos + 8
                if (id == "fmt ") {
                    val fmt = ByteArray(16)
                    raf.seek(body)
                    if (raf.read(fmt) != 16) return null
                    format = readLeShort(fmt, 0)
                    channels = readLeShort(fmt, 2)
                    sampleRate = readLeInt(fmt, 4)
                    bits = readLeShort(fmt, 14)
                } else if (id == "data") {
                    if (format != 1 || bits != 16 || channels !in 1..2 || sampleRate <= 0) return null
                    val available = (length - body).coerceAtLeast(0L)
                    val dataSize = if (size == 0L || size > available) available else size
                    return WavInfo(channels, sampleRate, body, dataSize)
                }
                pos = body + size + (size and 1L)
            }
        }
        return null
    }

    /**
     * Encodes a 16-bit PCM WAV file to AAC-LC (.m4a). Blocking; call it from a background dispatcher.
     * [onProgress] receives values in 0..1.
     */
    fun encodeWavToM4a(
        wavFile: File,
        outputFile: File,
        bitRate: Int = 192_000,
        onProgress: (Float) -> Unit = {}
    ) {
        val info = readWavInfo(wavFile) ?: throw IllegalArgumentException("Unsupported or missing WAV file: ${wavFile.name}")
        val blockAlign = info.channels * 2

        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, info.sampleRate, info.channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
        }

        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerStarted = false
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            RandomAccessFile(wavFile, "r").use { raf ->
                raf.seek(info.dataOffset)
                val chunk = ByteArray(16 * 1024)
                val bufferInfo = MediaCodec.BufferInfo()
                var consumed = 0L
                var presentationUs = 0L
                var inputDone = false
                var outputDone = false
                var track = -1

                while (!outputDone) {
                    if (!inputDone) {
                        val inIndex = codec.dequeueInputBuffer(10_000L)
                        if (inIndex >= 0) {
                            val inBuf = codec.getInputBuffer(inIndex)
                            if (inBuf == null) {
                                codec.queueInputBuffer(inIndex, 0, 0, presentationUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                inBuf.clear()
                                val remaining = info.dataSize - consumed
                                val maxWant = min(min(inBuf.remaining(), chunk.size).toLong(), remaining).toInt()
                                val want = maxWant - (maxWant % blockAlign)
                                val got = if (want > 0) raf.read(chunk, 0, want) else -1
                                if (got <= 0) {
                                    codec.queueInputBuffer(inIndex, 0, 0, presentationUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputDone = true
                                } else {
                                    val usable = got - (got % blockAlign)
                                    inBuf.put(chunk, 0, usable)
                                    codec.queueInputBuffer(inIndex, 0, usable, presentationUs, 0)
                                    consumed += usable
                                    presentationUs = (consumed / blockAlign) * 1_000_000L / info.sampleRate
                                    onProgress((consumed.toDouble() / info.dataSize.coerceAtLeast(1L).toDouble()).toFloat().coerceIn(0f, 1f))
                                }
                            }
                        }
                    }

                    val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (outIndex >= 0) {
                        val outBuf = codec.getOutputBuffer(outIndex)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (outBuf != null && bufferInfo.size > 0 && muxerStarted) {
                            outBuf.position(bufferInfo.offset)
                            outBuf.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(track, outBuf, bufferInfo)
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                }
            }
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
        onProgress(1f)
    }
}
