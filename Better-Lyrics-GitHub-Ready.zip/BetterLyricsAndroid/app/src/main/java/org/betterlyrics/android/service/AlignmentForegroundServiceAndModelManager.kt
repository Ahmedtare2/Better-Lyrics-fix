package org.betterlyrics.android.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.betterlyrics.android.alignment.ArabicAlignmentBackend
import org.betterlyrics.android.alignment.BilingualForcedAlignmentEngine
import org.betterlyrics.android.alignment.BilingualScriptAndNormalizer
import org.betterlyrics.android.alignment.ForcedAlignmentConfig
import org.betterlyrics.android.domain.ttml.Agent
import org.betterlyrics.android.domain.ttml.BackgroundVocalExtractor
import org.betterlyrics.android.domain.ttml.LyricLine
import org.betterlyrics.android.domain.ttml.ProjectMetadata
import org.betterlyrics.android.domain.ttml.TTMLOptions
import org.betterlyrics.android.domain.ttml.TtmlSerializer
import org.betterlyrics.android.domain.ttml.TtmlValidation
import org.betterlyrics.android.domain.ttml.TtmlValidatorAndParser
import org.betterlyrics.android.dsp.AudioCodec
import org.betterlyrics.android.dsp.HtDemucsOnnxSeparator
import org.betterlyrics.android.dsp.LeadBackingVocalSeparator
import org.betterlyrics.android.dsp.SpectralOnsetDetector
import org.betterlyrics.android.ui.MainActivity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.concurrent.TimeUnit

// ================================================================================================
// 1. OFFLINE-FIRST ONNX MODEL MANAGER (Verified HuggingFace URLs + Bundled Assets + SAF Sideload)
// ================================================================================================

enum class ModelId(
    val filename: String,
    val vocabFilename: String?,
    val title: String,
    val description: String,
    val approxMb: Int,
    val defaultDownloadUrl: String,
    val fallbackDownloadUrl: String? = null,
    val vocabDownloadUrl: String? = null,
    val expectedSha256: String? = null
) {
    HTDEMUCS_FP32(
        filename = "htdemucs_fp32.onnx",
        vocabFilename = null,
        title = "HTDemucs 4-Stem Vocal Separator (FP32 Studio Precision)",
        description = "Full 32-bit floating-point Hybrid Transformer Demucs ONNX model (StemSplitio/htdemucs-onnx, opset 17).",
        approxMb = 316,
        defaultDownloadUrl = "https://huggingface.co/StemSplitio/htdemucs-onnx/resolve/d54ed9eb60e258ea82131c6ee14578628816456a/htdemucs.onnx"
    ),
    HTDEMUCS_FP16(
        filename = "htdemucs_fp16.onnx",
        vocabFilename = null,
        title = "HTDemucs 4-Stem Vocal Separator (FP16 Weights)",
        description = "166 MB FP16-weight Hybrid Transformer Demucs ONNX model with FP32 I/O tensors (parity-verified vs PyTorch).",
        approxMb = 166,
        defaultDownloadUrl = "https://huggingface.co/StemSplitio/htdemucs-onnx/resolve/d54ed9eb60e258ea82131c6ee14578628816456a/htdemucs_fp16weights.onnx",
        fallbackDownloadUrl = "https://huggingface.co/Best-Practice/htdemucs-onnx/resolve/main/htdemucs_fp16weights.onnx",
        expectedSha256 = "d05c269d0178d2a72ad484b10b11dd370193fc923201c3b27a99f848745db70a"
    ),
    MMS_FA_AR_EN_FP32(
        filename = "ctc_ar.onnx",
        vocabFilename = "vocab_ar.json",
        title = "Wav2Vec2 Arabic (ar) + English (en) Neural CTC Forced Aligner",
        description = "Pre-bundled & downloadable Wav2Vec2 CTC acoustic models + exact vocab.json for Arabic and English forced alignment.",
        approxMb = 95,
        defaultDownloadUrl = "https://huggingface.co/onnx-community/wav2vec2-base-arabic-without-reused-en-token-ids-v1-ONNX/resolve/908b2bead4fe5c3ea5d5e31be904129fda068f74/onnx/model.onnx",
        fallbackDownloadUrl = "https://huggingface.co/onnx-community/wav2vec2-base-arabic-without-reused-en-token-ids-v1-ONNX/resolve/908b2bead4fe5c3ea5d5e31be904129fda068f74/onnx/model_fp16.onnx",
        vocabDownloadUrl = "https://huggingface.co/onnx-community/wav2vec2-base-arabic-without-reused-en-token-ids-v1-ONNX/resolve/908b2bead4fe5c3ea5d5e31be904129fda068f74/vocab.json",
        expectedSha256 = "209d73e012442c76b68a1df998e758876cda48c621bea28dae7e88c252d1773c"
    ),
    PARSEH_ALIGNER_AR_INT8(
        filename = "parseh_aligner_ar_int8.onnx",
        vocabFilename = "vocab_parseh_ar.json",
        title = "Parseh Aligner-AR (XLSR-53 24-Layer Arabic CTC INT8)",
        description = "Optional 340 MB XLSR-53 Large Arabic CTC forced-alignment model (parseh/aligner-ar, Apache-2.0) for Egyptian Arabic & connected speech.",
        approxMb = 340,
        defaultDownloadUrl = "https://huggingface.co/parseh/aligner-ar/resolve/main/model.int8.onnx",
        fallbackDownloadUrl = "https://huggingface.co/parseh/aligner-ar/resolve/main/model.onnx",
        vocabDownloadUrl = "https://huggingface.co/parseh/aligner-ar/resolve/main/vocab.json"
    ),
    UVR_MDXNET_KARA_2(
        filename = "uvr_mdxnet_kara_2.onnx",
        vocabFilename = null,
        title = "UVR MDX-Net Karaoke 2 (Stage-2 Lead vs. Backing Vocal Separator)",
        description = "Optional 52 MB ONNX Karaoke separator (MIT) that isolates Lead Vocals (v1) from Backing/Chorus Vocals (v2 / x-bg).",
        approxMb = 52,
        defaultDownloadUrl = "https://huggingface.co/seanghay/uvr_models/resolve/main/UVR_MDXNET_KARA_2.onnx",
        fallbackDownloadUrl = "https://huggingface.co/poiqazwsx/uvr_weights/resolve/main/UVR_MDXNET_KARA_2.onnx"
    )
}

data class ModelStatus(
    val modelId: ModelId,
    val isInstalled: Boolean,
    val sizeBytes: Long,
    val sha256Prefix: String?,
    val isDownloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val errorMessage: String? = null
)

class OfflineModelManager(private val context: Context) {
    val modelsDir: File = File(context.filesDir, "models").apply { mkdirs() }
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val _statuses = MutableStateFlow<Map<ModelId, ModelStatus>>(emptyMap())
    val statuses: StateFlow<Map<ModelId, ModelStatus>> = _statuses.asStateFlow()
    private val downloadLocks = ModelId.entries.associateWith { kotlinx.coroutines.sync.Mutex() }

    companion object {
        const val EN_CTC_FILENAME = "ctc_en.onnx"
        const val EN_VOCAB_FILENAME = "vocab_en.json"
    const val EN_CTC_URL = "https://huggingface.co/onnx-community/wav2vec2-base-960h-ONNX/resolve/729c1a6730fb549c20a1c73a3d3f96f11020225e/onnx/model_quantized.onnx"
    const val EN_VOCAB_URL = "https://huggingface.co/onnx-community/wav2vec2-base-960h-ONNX/resolve/729c1a6730fb549c20a1c73a3d3f96f11020225e/vocab.json"
    const val EN_CTC_SHA256 = "1d9a366c27b2966625cd5035ac3db8847c53bba617169912bb251b42975a3a22"
    }

    init {
        refreshStatuses()
    }

    fun getModelFile(modelId: ModelId): File = File(modelsDir, modelId.filename)
    fun getArabicCtcFile(): File = File(modelsDir, ModelId.MMS_FA_AR_EN_FP32.filename)
    fun getArabicVocabFile(): File = File(modelsDir, "vocab_ar.json")
    fun getArabicMetaFile(): File = File(modelsDir, "meta_ar.json")
    fun getEnglishCtcFile(): File = File(modelsDir, EN_CTC_FILENAME)
    fun getEnglishVocabFile(): File = File(modelsDir, EN_VOCAB_FILENAME)
    fun getEnglishMetaFile(): File = File(modelsDir, "meta_en.json")
    fun getParsehArabicCtcFile(): File = File(modelsDir, ModelId.PARSEH_ALIGNER_AR_INT8.filename)
    fun getParsehArabicVocabFile(): File = File(modelsDir, "vocab_parseh_ar.json")
    fun getParsehArabicMetaFile(): File = File(modelsDir, "meta_parseh_ar.json")
    fun getMdxKaraokeFile(): File = File(modelsDir, ModelId.UVR_MDXNET_KARA_2.filename)

    /**
     * Checks `/storage/emulated/0/Download/TTML-models` (`aligner-ar` and `aligner-en`) first,
     * and only extracts bundled APK assets if a model is not yet installed (never overwriting
     * the user's 339.79 MB `aligner-ar/model.int8.onnx` or `aligner-en/model.int8.onnx`!).
     */
    fun extractBundledAssetsIfPresent() {
        runCatching {
            // Keep htdemucs_fp16.onnx so Stage 2 runs real 4-stem neural vocal separation

            // 1. Try direct import from /storage/emulated/0/Download/TTML-models if accessible
            tryImportFromDownloadTtmlModelsDir()

            // 2. Fall back to APK bundled assets only for missing files
            val assetFiles = context.assets.list("models") ?: return
            for (name in assetFiles) {
                val dest = File(modelsDir, name)
                if (!dest.exists() || dest.length() < 128L) {
                    context.assets.open("models/$name").use { input ->
                        FileOutputStream(dest).use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    }
                }
            }
        }
    }

    private fun tryImportFromDownloadTtmlModelsDir() {
        runCatching {
            val dlRoot = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val candidates = listOf(
                File(dlRoot, "TTML-models"),
                File("/storage/emulated/0/Download/TTML-models"),
                File("/sdcard/Download/TTML-models")
            )
            val ttmlDir = candidates.firstOrNull { it.exists() && it.isDirectory } ?: return
            ttmlDir.listFiles()?.firstOrNull { it.name.contains("demucs", ignoreCase = true) && it.name.endsWith(".onnx") }?.let { demucsOnnx ->
                if (demucsOnnx.canRead() && getModelFile(ModelId.HTDEMUCS_FP16).length() != demucsOnnx.length()) {
                    demucsOnnx.inputStream().use { inp -> FileOutputStream(getModelFile(ModelId.HTDEMUCS_FP16)).use { out -> inp.copyTo(out, 64 * 1024) } }
                }
            }
            val arDir = File(ttmlDir, "aligner-ar")
            if (arDir.exists() && arDir.isDirectory) {
                val onnx = File(arDir, "model.int8.onnx").takeIf { it.exists() }
                    ?: arDir.listFiles()?.firstOrNull { it.name.endsWith(".onnx") }
                if (onnx != null && onnx.canRead() && getArabicCtcFile().length() != onnx.length()) {
                    onnx.inputStream().use { inp -> FileOutputStream(getArabicCtcFile()).use { out -> inp.copyTo(out, 64 * 1024) } }
                }
                val vocab = File(arDir, "vocab.json")
                if (vocab.exists() && vocab.canRead()) vocab.copyTo(getArabicVocabFile(), overwrite = true)
                val meta = File(arDir, "meta.json")
                if (meta.exists() && meta.canRead()) meta.copyTo(getArabicMetaFile(), overwrite = true)
            }
            val enDir = File(ttmlDir, "aligner-en")
            if (enDir.exists() && enDir.isDirectory) {
                val onnx = File(enDir, "model.int8.onnx").takeIf { it.exists() }
                    ?: enDir.listFiles()?.firstOrNull { it.name.endsWith(".onnx") }
                if (onnx != null && onnx.canRead() && getEnglishCtcFile().length() != onnx.length()) {
                    onnx.inputStream().use { inp -> FileOutputStream(getEnglishCtcFile()).use { out -> inp.copyTo(out, 64 * 1024) } }
                }
                val vocab = File(enDir, "vocab.json")
                if (vocab.exists() && vocab.canRead()) vocab.copyTo(getEnglishVocabFile(), overwrite = true)
                val meta = File(enDir, "meta.json")
                if (meta.exists() && meta.canRead()) meta.copyTo(getEnglishMetaFile(), overwrite = true)
            }
        }
    }

    /**
     * Imports `aligner-ar` and/or `aligner-en` (`model.int8.onnx`, `vocab.json`, `meta.json`)
     * from a user-selected SAF folder (`OpenDocumentTree`), supporting selecting either the parent
     * `TTML-models` folder or `aligner-ar` / `aligner-en` directly!
     */
    suspend fun importAlignerFolderFromTreeUri(
        treeUri: Uri,
        onStatus: suspend (String) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cr = context.contentResolver
            val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val importedSummary = mutableListOf<String>()

            data class DocEntry(val docId: String, val name: String, val mime: String, val size: Long)

            fun listChildren(parentDocId: String): List<DocEntry> {
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
                val list = mutableListOf<DocEntry>()
                val projection = arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE
                )
                cr.query(childrenUri, projection, null, null, null)?.use { cursor ->
                    while (cursor.moveToNext()) {
                        val id = cursor.getString(0) ?: continue
                        val name = cursor.getString(1) ?: ""
                        val mime = cursor.getString(2) ?: ""
                        val sz = if (!cursor.isNull(3)) cursor.getLong(3) else 0L
                        list.add(DocEntry(id, name, mime, sz))
                    }
                }
                return list
            }

            fun copyDocToFile(docId: String, target: File) {
                val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                val temp = File(modelsDir, "${target.name}.import.tmp")
                try {
                    cr.openInputStream(fileUri)?.use { inp ->
                        FileOutputStream(temp).use { out ->
                        inp.copyTo(out, bufferSize = 128 * 1024)
                            out.fd.sync()
                        }
                    } ?: throw IllegalStateException("Cannot open $docId")
                    replaceFileAtomically(temp, target)
                } catch (t: Throwable) {
                    runCatching { temp.delete() }
                    throw t
                }
            }

            suspend fun importSingleAlignerDir(dirLabel: String, entries: List<DocEntry>) {
                val onnxEntry = entries.firstOrNull { it.name.equals("model.int8.onnx", ignoreCase = true) }
                    ?: entries.firstOrNull { it.name.endsWith(".onnx", ignoreCase = true) }
                    ?: return
                val vocabEntry = entries.firstOrNull { it.name.equals("vocab.json", ignoreCase = true) }
                val metaEntry = entries.firstOrNull { it.name.equals("meta.json", ignoreCase = true) }

                // Determine whether this folder is Arabic (ar) or English (en)
                var isArabic = dirLabel.contains("ar", ignoreCase = true) && !dirLabel.contains("en", ignoreCase = true)
                if (!dirLabel.contains("ar", ignoreCase = true) && !dirLabel.contains("en", ignoreCase = true) && vocabEntry != null) {
                    val vUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, vocabEntry.docId)
                    val vText = cr.openInputStream(vUri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    isArabic = Regex("[\u0600-\u06FF]").containsMatchIn(vText)
                }

                val langTag = if (isArabic) "Arabic (aligner-ar)" else "English (aligner-en)"
                onStatus("Importing $langTag: ${onnxEntry.name} (${onnxEntry.size / (1024 * 1024)} MB)…")

                if (isArabic) {
                    copyDocToFile(onnxEntry.docId, getArabicCtcFile())
                    vocabEntry?.let { copyDocToFile(it.docId, getArabicVocabFile()) }
                    metaEntry?.let { copyDocToFile(it.docId, getArabicMetaFile()) }
                    importedSummary.add("AR (${getArabicCtcFile().length() / (1024 * 1024)} MB)")
                } else {
                    copyDocToFile(onnxEntry.docId, getEnglishCtcFile())
                    vocabEntry?.let { copyDocToFile(it.docId, getEnglishVocabFile()) }
                    metaEntry?.let { copyDocToFile(it.docId, getEnglishMetaFile()) }
                    importedSummary.add("EN (${getEnglishCtcFile().length() / (1024 * 1024)} MB)")
                }
            }

            val rootEntries = listChildren(rootDocId)
            // Check if the selected folder itself contains model.int8.onnx
            if (rootEntries.any { it.name.endsWith(".onnx", ignoreCase = true) }) {
                importSingleAlignerDir(rootDocId, rootEntries)
            }
            // Also check child subfolders (e.g. aligner-ar and aligner-en inside TTML-models)
            for (child in rootEntries) {
                if (child.mime == DocumentsContract.Document.MIME_TYPE_DIR ||
                    child.name.contains("aligner", ignoreCase = true)
                ) {
                    val subEntries = listChildren(child.docId)
                    if (subEntries.any { it.name.endsWith(".onnx", ignoreCase = true) }) {
                        importSingleAlignerDir(child.name, subEntries)
                    }
                }
            }

            refreshStatuses()
            if (importedSummary.isEmpty()) {
                throw IllegalArgumentException("No model.int8.onnx found in selected folder. Select TTML-models, aligner-ar, or aligner-en.")
            }
            "Imported: ${importedSummary.joinToString(" + ")}"
        }
    }

    fun refreshStatuses() {
        val updated = ModelId.entries.associateWith { id ->
            val f = getModelFile(id)
            val exists = f.exists() && f.length() > 1024L
            ModelStatus(
                modelId = id,
                isInstalled = exists,
                sizeBytes = if (exists) f.length() else 0L,
                sha256Prefix = if (exists) computeFastSha256Prefix(f) else null
            )
        }
        _statuses.value = updated
    }

    suspend fun sideloadModelFromUri(modelId: ModelId, sourceUri: Uri): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val target = getModelFile(modelId)
            val tempFile = File(modelsDir, "${modelId.filename}.tmp")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                    output.fd.sync()
                }
            } ?: throw IllegalArgumentException("Could not open selected model file.")

            if (tempFile.length() < 1024L) {
                tempFile.delete()
                throw IllegalArgumentException("Selected file is too small to be a valid ONNX model.")
            }
            replaceFileAtomically(tempFile, target)
            refreshStatuses()
            target
        }
    }

    suspend fun downloadModel(
        modelId: ModelId,
        customUrl: String? = null,
        onProgressCallback: (suspend (Float) -> Unit)? = null
    ): Result<File> = withContext(Dispatchers.IO) {
        val modelLock = downloadLocks.getValue(modelId)
        modelLock.lock()
        try {
            val primaryUrl = customUrl?.trim()?.takeIf { it.isNotEmpty() } ?: modelId.defaultDownloadUrl
            updateModelState(modelId) { it.copy(isDownloading = true, downloadProgress = 0f, errorMessage = null) }

            val result = runCatching {
            val target = getModelFile(modelId)
            val urlsToTry = buildList {
                add(primaryUrl)
                modelId.fallbackDownloadUrl?.let { add(it) }
                if (modelId == ModelId.MMS_FA_AR_EN_FP32) {
                    val base = "https://huggingface.co/onnx-community/wav2vec2-base-arabic-without-reused-en-token-ids-v1-ONNX/resolve/main"
                    add("$base/onnx/model_int8.onnx")
                    add("$base/onnx/model_uint8.onnx")
                    add("$base/onnx/model_fp16.onnx")
                    add("$base/onnx/model_q4.onnx")
                    add("$base/onnx/model.onnx")
                    add("$base/model.onnx")
                }
            }.distinct()
            var lastError: Throwable? = null
            var downloadedOk = false

            for (url in urlsToTry) {
                try {
                    downloadUrlToFile(
                        url,
                        target,
                        modelId.approxMb * 1024L * 1024L,
                        expectedSha256 = modelId.expectedSha256.takeIf {
                            customUrl.isNullOrBlank() && url == modelId.defaultDownloadUrl
                        }
                    ) { frac ->
                        updateModelState(modelId) { it.copy(isDownloading = true, downloadProgress = frac) }
                        onProgressCallback?.invoke(frac)
                    }
                    downloadedOk = true
                    break
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (t: Throwable) {
                    lastError = t
                }
            }
            if (!downloadedOk) throw (lastError ?: IllegalStateException("Download failed"))

            // Also download companion vocab.json + English CTC model when downloading the CTC Aligner bundle
            if (modelId == ModelId.MMS_FA_AR_EN_FP32) {
                val arabicVocab = getArabicVocabFile()
                if (!arabicVocab.exists() || arabicVocab.length() < 16L) {
                    val vocabUrl = requireNotNull(modelId.vocabDownloadUrl) {
                        "Arabic vocabulary URL is not configured."
                    }
                    downloadUrlToFile(vocabUrl, arabicVocab, 4096L) {}
                }
                if (!getEnglishCtcFile().exists() || getEnglishCtcFile().length() < 1024L) {
                    downloadUrlToFile(
                        EN_CTC_URL,
                        getEnglishCtcFile(),
                        95 * 1024L * 1024L,
                        expectedSha256 = EN_CTC_SHA256
                    ) {}
                }
                if (!getEnglishVocabFile().exists() || getEnglishVocabFile().length() < 16L) {
                    downloadUrlToFile(EN_VOCAB_URL, getEnglishVocabFile(), 4096L) {}
                }
            } else if (modelId == ModelId.PARSEH_ALIGNER_AR_INT8) {
                modelId.vocabDownloadUrl?.let { vUrl ->
                    downloadUrlToFile(vUrl, getParsehArabicVocabFile(), 4096L) {}
                }
                downloadUrlToFile(
                    "https://huggingface.co/parseh/aligner-ar/resolve/main/meta.json",
                    getParsehArabicMetaFile(),
                    4096L
                ) {}
            }

            refreshStatuses()
            target
        }.onFailure { err ->
            updateModelState(modelId) {
                it.copy(isDownloading = false, errorMessage = err.message ?: "Download failed")
            }
        }
            if (result.exceptionOrNull() is CancellationException) throw result.exceptionOrNull() as CancellationException
            result
        } finally {
            modelLock.unlock()
        }
    }

    /**
     * Verifies that both Arabic (`ctc_ar.onnx` + `vocab_ar.json`) and English (`ctc_en.onnx` + `vocab_en.json`)
     * CTC model and vocabulary files exist and are non-corrupted.
     */
    fun hasValidBilingualCtcAssets(): Boolean {
        val arOk = getArabicCtcFile().exists() && getArabicCtcFile().length() > 1024L &&
            getArabicVocabFile().exists() && getArabicVocabFile().length() > 16L
        val enOk = getEnglishCtcFile().exists() && getEnglishCtcFile().length() > 1024L &&
            getEnglishVocabFile().exists() && getEnglishVocabFile().length() > 16L
        return arOk && enOk
    }

    private suspend fun downloadUrlToFile(
        url: String,
        target: File,
        fallbackBytes: Long,
        expectedSha256: String? = null,
        onProgress: suspend (Float) -> Unit
    ) {
        val tempFile = File(modelsDir, "${target.name}.download")
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "BetterLyricsAndroid/3.0")
                .get()
                .build()

            val digest = expectedSha256?.let { MessageDigest.getInstance("SHA-256") }
            var receivedBytes = 0L
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IllegalStateException("HTTP ${response.code} for $url")
                }
                val body = response.body ?: throw IllegalStateException("Empty response body")
                val totalBytes = body.contentLength().takeIf { it > 0L } ?: fallbackBytes

                body.byteStream().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var loaded = 0L
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                            loaded += read
                            receivedBytes += read
                            digest?.update(buffer, 0, read)
                            val progress = (loaded.toFloat() / totalBytes.toFloat()).coerceIn(0f, 0.99f)
                            onProgress(progress)
                        }
                        output.fd.sync()
                    }
                    if (body.contentLength() >= 0L && receivedBytes != body.contentLength()) {
                        throw IllegalStateException(
                            "Incomplete download for ${target.name}: received $receivedBytes of ${body.contentLength()} bytes."
                        )
                    }
                }
            }
            if (tempFile.length() < 16L) {
                throw IllegalStateException("Downloaded file ${target.name} is empty or truncated")
            }
            if (expectedSha256 != null) {
                val actual = digest!!.digest().joinToString("") { "%02x".format(it) }
                if (!actual.equals(expectedSha256, ignoreCase = true)) {
                    throw SecurityException("SHA-256 verification failed for ${target.name}.")
                }
            }
            replaceFileAtomically(tempFile, target)
        } catch (t: Exception) {
            // Phase 2 Failure-Cleanup Guarantee: Remove partial `.download` file so corrupt artifacts never remain
            runCatching { if (tempFile.exists()) tempFile.delete() }
            throw t
        }
    }

    private fun replaceFileAtomically(temporary: File, target: File) {
        try {
            Files.move(
                temporary.toPath(),
                target.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        } catch (t: Exception) {
            throw IllegalStateException(
                "Could not atomically install ${target.name}; the existing model was preserved.",
                t
            )
        }
    }

    private fun updateModelState(modelId: ModelId, transform: (ModelStatus) -> ModelStatus) {
        val current = _statuses.value.toMutableMap()
        val existing = current[modelId] ?: ModelStatus(modelId, false, 0L, null)
        current[modelId] = transform(existing)
        _statuses.value = current
    }

    private fun computeFastSha256Prefix(file: File): String = runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buf = ByteArray(65536)
            var remaining = 1024 * 1024
            while (remaining > 0) {
                val r = fis.read(buf, 0, minOf(buf.size, remaining))
                if (r <= 0) break
                digest.update(buf, 0, r)
                remaining -= r
            }
        }
        digest.update(file.length().toString().toByteArray())
        digest.digest().take(6).joinToString("") { "%02x".format(it) }
    }.getOrDefault("verified")
}

// ================================================================================================
// 2. FOREGROUND PIPELINE SERVICE WITH PARTIAL_WAKE_LOCK & AUTOMATIC MODEL PROVISIONING
// ================================================================================================

enum class PipelineStage(val stepNumber: Int, val title: String) {
    IDLE(0, "Ready"),
    STAGE_1_DECODE(1, "Stage 1/4: Audio Decoding & Model Check"),
    STAGE_2_DEMUCS(2, "Stage 2/4: Vocal Isolation (HTDemucs or DSP Fallback)"),
    STAGE_3_ALIGNMENT(3, "Stage 3/4: CTC Alignment Where Available + Spectral Fallback"),
    STAGE_4_ONSET_SNAP(4, "Stage 4/4: 5ms Transient Polish & TTML Validation"),
    COMPLETED(5, "Studio TTML Generation Complete"),
    CANCELLED(-1, "Cancelled"),
    FAILED(-2, "Pipeline Error")
}

data class PipelineJobRequest(
    val audioUri: Uri,
    val metadata: ProjectMetadata,
    val agents: List<Agent>,
    val initialLines: List<LyricLine>,
    val demucsModelVariant: ModelId = ModelId.HTDEMUCS_FP16,
    val arabicBackend: ArabicAlignmentBackend = ArabicAlignmentBackend.AUTO_CALIBRATED,
    val useHardwareAcceleration: Boolean = false,
    val enableSyllableSplitting: Boolean = false,
    val autoExtractBackgroundVocals: Boolean = true,
    val snapToSpectralOnsets: Boolean = true
)

data class PipelineState(
    val stage: PipelineStage = PipelineStage.IDLE,
    val detailMessage: String = "Select an audio file and lyrics to start.",
    val overallProgress: Float = 0f,
    val elapsedMillis: Long = 0L,
    val resultLines: List<LyricLine>? = null,
    val resultMetadata: ProjectMetadata? = null,
    val generatedTtmlXml: String? = null,
    val validationStatus: TtmlValidation? = null,
    val vocalsWavFile: File? = null,
    val instrumentalWavFile: File? = null,
    val vocalOnsetSeconds: DoubleArray? = null,
    val primingSamplesStripped: Int = 0
)

/**
 * Generation token used to keep cancelled runs from finalizing resources owned by a replacement run.
 * This class is deliberately platform-free so its race semantics can be unit tested.
 */
internal class PipelineRunOwnership {
    private var nextId = 0L
    private var activeId: Long? = null

    @Synchronized
    fun beginRun(): Long {
        nextId += 1
        activeId = nextId
        return nextId
    }

    @Synchronized
    fun currentRunId(): Long? = activeId

    @Synchronized
    fun isCurrent(runId: Long): Boolean = activeId == runId

    @Synchronized
    fun runIfCurrent(runId: Long, action: () -> Unit): Boolean {
        if (activeId != runId) return false
        action()
        return true
    }

    /** Returns true only to the run that still owns shared service resources. */
    @Synchronized
    fun finishRun(runId: Long): Boolean {
        if (activeId != runId) return false
        activeId = null
        return true
    }

    @Synchronized
    fun failRun(runId: Long, onFailure: () -> Unit): Boolean {
        if (activeId != runId) return false
        activeId = null
        onFailure()
        return true
    }
}

class AlignmentForegroundService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): AlignmentForegroundService = this@AlignmentForegroundService
    }

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var currentJob: Job? = null
    private var currentJobOwnerRunId: Long? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val runOwnership = PipelineRunOwnership()
    private val lifecycleGuard = Any()
    private var wakeLockOwnerRunId: Long? = null

    private val _pipelineState = MutableStateFlow(PipelineState())
    val pipelineState: StateFlow<PipelineState> = _pipelineState.asStateFlow()

    companion object {
        const val CHANNEL_ID = "better_lyrics_dsp_channel"
        const val NOTIFICATION_ID = 44100
        const val ACTION_CANCEL_PIPELINE = "org.betterlyrics.android.action.CANCEL_PIPELINE"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL_PIPELINE) {
            cancelPipeline()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    fun startPipeline(request: PipelineJobRequest, modelManager: OfflineModelManager) {
        var startupFailed = false
        synchronized(lifecycleGuard) {
            val runId = runOwnership.beginRun()
            currentJob?.cancel()
            currentJob = null
            currentJobOwnerRunId = null

            val initialNotification = buildProgressNotification(
                title = PipelineStage.STAGE_1_DECODE.title,
                detail = "Starting foreground audio processing…",
                progressPercent = 2
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        initialNotification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    )
                } else {
                    startForeground(NOTIFICATION_ID, initialNotification)
                }
            } catch (t: Exception) {
                // Do not run expensive DSP without a successfully established foreground service.
                val failure = "Could not start foreground audio processing: ${t.message ?: t.javaClass.simpleName}"
                failStartupRun(runId, failure)
                startupFailed = true
            }
            if (!startupFailed) {
                try {
                    acquireWakeLock(runId)
                } catch (t: Exception) {
                    val failure = "Could not acquire alignment processing resources: ${t.message ?: t.javaClass.simpleName}"
                    failStartupRun(runId, failure)
                    startupFailed = true
                }
            }
            if (!startupFailed) {

                val startTimeMs = System.currentTimeMillis()
                // LAZY ensures ownership is recorded before the coroutine can reach its finally block.
                val runJob = serviceScope.launch(start = CoroutineStart.LAZY) {
            try {
                // --------------------------------------------------------------------------------
                // STAGE 1: Audio Decoding, LAME Priming Compensation & Neural Model Provisioning
                // --------------------------------------------------------------------------------
                updateState(
                    runId = runId,
                    startTimeMs = startTimeMs,
                    stage = PipelineStage.STAGE_1_DECODE,
                    detail = "Decoding audio to 44.1 kHz stereo float32 & compensating LAME priming…",
                    progress = 0.03f
                )

                val decoded = AudioCodec.decodeUriToFloat32(
                    context = applicationContext,
                    uri = request.audioUri,
                    stripPriming = true
                )
                val songDurationSec = decoded.durationSeconds
                val totalAudioFrames = decoded.numFrames
                val primingStripped = decoded.primingSamplesStripped

                val preparedLines = if (request.autoExtractBackgroundVocals) {
                    BackgroundVocalExtractor.extractBackgroundVocals(request.initialLines)
                } else {
                    request.initialLines
                }

                val resolvedLanguage = request.metadata.language?.takeIf { it.isNotBlank() }
                    ?: BilingualScriptAndNormalizer.detectDominantLanguage(preparedLines)
                val updatedMetadata = request.metadata.copy(
                    duration = songDurationSec,
                    language = resolvedLanguage,
                    extra = buildMap {
                        putAll(request.metadata.extra.orEmpty())
                        if (primingStripped > 0) {
                            put("lamePrimingSamplesStripped", primingStripped.toString())
                        }
                    }.takeIf { it.isNotEmpty() }
                )

                // Extract pre-bundled INT8 Neural CTC models & vocab.json files on background IO thread
                updateState(
                    runId = runId,
                    startTimeMs = startTimeMs,
                    stage = PipelineStage.STAGE_1_DECODE,
                    detail = "Provisioning pre-bundled INT8 Neural CTC models & vocabulary…",
                    progress = 0.06f
                )
                withContext(Dispatchers.IO) {
                    modelManager.extractBundledAssetsIfPresent()
                    modelManager.refreshStatuses()
                }

                var ctcProvisioningWarning: String? = null
                // Auto-download neural CTC models on first run only if not already bundled in APK
                if (!modelManager.getArabicCtcFile().exists() || modelManager.getArabicCtcFile().length() < 1024L ||
                    !modelManager.hasValidBilingualCtcAssets()
                ) {
                    updateState(
                        runId = runId,
                        startTimeMs = startTimeMs,
                        stage = PipelineStage.STAGE_1_DECODE,
                        detail = "First-time setup: downloading Arabic + English Neural CTC ONNX models…",
                        progress = 0.08f
                    )
                    val downloadResult = modelManager.downloadModel(ModelId.MMS_FA_AR_EN_FP32) { dlFrac ->
                        updateState(
                            runId = runId,
                            startTimeMs = startTimeMs,
                            stage = PipelineStage.STAGE_1_DECODE,
                            detail = "Downloading Neural CTC Forced Aligner ONNX (${(dlFrac * 100).toInt()}%)…",
                            progress = 0.08f + 0.05f * dlFrac
                        )
                    }
                    downloadResult.exceptionOrNull()?.let {
                        ctcProvisioningWarning = "CTC model download failed (${it.message ?: it.javaClass.simpleName})."
                    }
                }
                if (!modelManager.hasValidBilingualCtcAssets()) {
                    ctcProvisioningWarning = listOfNotNull(
                        ctcProvisioningWarning,
                        "Arabic/English CTC model or vocabulary assets are incomplete; affected timings will use acoustic fallback and be marked for review."
                    ).joinToString(" ")
                    updateState(
                        runId = runId,
                        startTimeMs = startTimeMs,
                        stage = PipelineStage.STAGE_1_DECODE,
                        detail = "$ctcProvisioningWarning Continuing; fallback timings will be flagged for review.",
                        progress = 0.13f
                    )
                }

                // --------------------------------------------------------------------------------
                // STAGE 2: Zero-Freeze On-Device Vocal Stem Isolation (50% Overlap-Add)
                // Uses Studio STFT Mid/Side + Formant Wiener Vocal Isolator by default on mobile
                // so the phone NEVER runs out of native RAM or reboots!
                // --------------------------------------------------------------------------------
                val chosenDemucs = modelManager.getModelFile(request.demucsModelVariant)
                val fp16Demucs = modelManager.getModelFile(ModelId.HTDEMUCS_FP16)
                if ((!chosenDemucs.exists() || chosenDemucs.length() < 1024L) &&
                    (!fp16Demucs.exists() || fp16Demucs.length() < 1024L)
                ) {
                    updateState(
                        runId = runId,
                        startTimeMs = startTimeMs,
                        stage = PipelineStage.STAGE_1_DECODE,
                        detail = "Caching HTDemucs FP16 neural vocal separator ONNX…",
                        progress = 0.11f
                    )
                    modelManager.downloadModel(ModelId.HTDEMUCS_FP16) { dlFrac ->
                        updateState(
                            runId = runId,
                            startTimeMs = startTimeMs,
                            stage = PipelineStage.STAGE_1_DECODE,
                            detail = "Downloading HTDemucs FP16 Vocal Separator (${(dlFrac * 100).toInt()}%)…",
                            progress = 0.11f + 0.04f * dlFrac
                        )
                    }
                }
                val activeDemucsFile = chosenDemucs.takeIf { it.exists() && it.length() > 1024L }
                    ?: fp16Demucs.takeIf { it.exists() && it.length() > 1024L }

                updateState(
                    runId = runId,
                    startTimeMs = startTimeMs,
                    stage = PipelineStage.STAGE_2_DEMUCS,
                    detail = "Isolating vocals: HTDemucs when available, otherwise CPU spectral fallback…",
                    progress = 0.15f
                )

                val separator = HtDemucsOnnxSeparator()
                val separation = separator.separateVocals(
                    channels = decoded.channels,
                    totalFrames = totalAudioFrames,
                    modelFile = activeDemucsFile,
                    useHardwareAcceleration = request.useHardwareAcceleration
                ) { processed, total ->
                    val frac = 0.15f + 0.35f * (processed.toFloat() / total.coerceAtLeast(1).toFloat())
                    updateState(
                        runId = runId,
                        startTimeMs = startTimeMs,
                        stage = PipelineStage.STAGE_2_DEMUCS,
                        detail = "Vocal stem isolation: chunk $processed / $total (${(frac * 100).toInt()}%)",
                        progress = frac
                    )
                }
                val separationWarning = if (separation.usedDspFallback) {
                    "HTDemucs neural separation was not used: ${separation.fallbackReason ?: "DSP fallback selected."} CPU spectral fallback was used instead."
                } else null

                // Extract lightweight 16 kHz mono reference (~25 MB on a 6.5-min song) directly from
                // stereo channels without allocating an intermediate 69 MB 44.1 kHz mono array, then
                // immediately release the 44.1 kHz stereo decoded audio (~138 MB) before Stage 2B starts!
                val originalMono16k = runCatching {
                    AudioCodec.mixAndResampleToMono(
                        decoded.channels,
                        fromRate = AudioCodec.TARGET_SAMPLE_RATE,
                        toRate = BilingualForcedAlignmentEngine.CTC_SAMPLE_RATE
                    )
                }.getOrNull()
                decoded.channels[0] = FloatArray(0)
                if (decoded.channels.size > 1) decoded.channels[1] = FloatArray(0)
                System.gc()

                // Persist separated vocals WAV and extract lightweight 16 kHz combined vocal stem BEFORE
                // Stage 2B reuses the 44.1 kHz buffers in-place (prevents 3x 138 MB stereo stem accumulation on long songs!).
                val stemsDir = File(applicationContext.cacheDir, "stems").apply { mkdirs() }
                val vocalsWav = File(stemsDir, "vocals_isolated.wav")
                withContext(Dispatchers.IO) {
                    AudioCodec.writeFloatChannelsToWavFile(separation.vocals, separation.sampleRate, vocalsWav)
                }
                val vocalMono16k = AudioCodec.mixAndResampleToMono(
                    separation.vocals,
                    fromRate = AudioCodec.TARGET_SAMPLE_RATE,
                    toRate = BilingualForcedAlignmentEngine.CTC_SAMPLE_RATE
                )

                // Stage 2B: Lead vs. Backing Vocal Separation (reuses 44.1 kHz buffers in-place with 0 MB extra allocation)
                val hasExplicitMultiVoiceLyrics = preparedLines.any { !it.backgroundText.isNullOrBlank() || it.agentId != "v1" }
                updateState(
                    runId = runId,
                    startTimeMs = startTimeMs,
                    stage = PipelineStage.STAGE_2_DEMUCS,
                    detail = "Stage 2B: Separating Lead Vocals (v1) from Backing/Chorus Vocals (v2 / x-bg)…",
                    progress = 0.49f
                )
                val leadBackingSeparator = LeadBackingVocalSeparator()
                val leadBackingResult = leadBackingSeparator.separateLeadAndBacking(
                    vocalChannels44k = separation.vocals,
                    mdxKaraokeModelFile = if (hasExplicitMultiVoiceLyrics) {
                        modelManager.getMdxKaraokeFile().takeIf { it.exists() && it.length() > 1024L }
                    } else null,
                    reuseInputBuffersInPlace = true
                )

                // Compute compact spectral-flux onset analyses (~160 KB) and 16 kHz mono stems (~25 MB),
                // then immediately release ALL 44.1 kHz arrays before loading ONNX CTC models in Stage 3!
                val leadOnsetAnalysis = SpectralOnsetDetector.analyzeVocalChannels(leadBackingResult.leadVocals)
                val leadVocalMono16k = AudioCodec.mixAndResampleToMono(
                    leadBackingResult.leadVocals,
                    fromRate = AudioCodec.TARGET_SAMPLE_RATE,
                    toRate = BilingualForcedAlignmentEngine.CTC_SAMPLE_RATE
                )
                for (i in leadBackingResult.leadVocals.indices) {
                    leadBackingResult.leadVocals[i] = FloatArray(0)
                }

                val hasDistinctBacking = leadBackingResult.hasDistinctBackingStem && leadBackingResult.separationConfidence >= 0.18f
                val backingOnsetAnalysis = if (hasDistinctBacking) {
                    SpectralOnsetDetector.analyzeVocalChannels(leadBackingResult.backingVocals)
                } else null
                val backingVocalMono16k = if (hasDistinctBacking) {
                    AudioCodec.mixAndResampleToMono(
                        leadBackingResult.backingVocals,
                        fromRate = AudioCodec.TARGET_SAMPLE_RATE,
                        toRate = BilingualForcedAlignmentEngine.CTC_SAMPLE_RATE
                    )
                } else null
                for (i in leadBackingResult.backingVocals.indices) {
                    leadBackingResult.backingVocals[i] = FloatArray(0)
                }
                for (i in separation.vocals.indices) {
                    separation.vocals[i] = FloatArray(0)
                }
                val empty44kPlaceholder = arrayOf(FloatArray(0), FloatArray(0))
                System.gc()

                // --------------------------------------------------------------------------------
                // STAGE 3 & STAGE 4: Chorus-Aware Multi-Source Neural CTC + Spectral Aligner
                // --------------------------------------------------------------------------------
                updateState(
                    runId = runId,
                    startTimeMs = startTimeMs,
                    stage = PipelineStage.STAGE_3_ALIGNMENT,
                    detail = "Starting chorus-aware alignment ($resolvedLanguage); neural CTC is used where available and heuristic timings are flagged for review…",
                    progress = 0.52f
                )

                val aligner = BilingualForcedAlignmentEngine()
                val alignedLines = aligner.alignLyricsToVocalStem(
                    lines = preparedLines,
                    vocalChannels44k = empty44kPlaceholder,
                    songDurationSeconds = songDurationSec,
                    ctcModelFile = modelManager.getArabicCtcFile(),
                    config = ForcedAlignmentConfig(
                        lrcWindowPaddingSeconds = 1.20,
                        enableSyllableSplitting = request.enableSyllableSplitting,
                        extractAndAlignBackgroundVocals = request.autoExtractBackgroundVocals,
                        snapToSpectralOnsets = request.snapToSpectralOnsets,
                        autoCorrectLrcGlobalOffset = true,
                        arabicBackend = request.arabicBackend,
                        enableChorusMultiSourceComparison = true
                    ),
                    arabicCtcModelFile = modelManager.getArabicCtcFile(),
                    arabicVocabFile = modelManager.getArabicVocabFile(),
                    englishCtcModelFile = modelManager.getEnglishCtcFile(),
                    englishVocabFile = modelManager.getEnglishVocabFile(),
                    originalMono16k = originalMono16k,
                    leadBackingSeparationConfidence = leadBackingResult.separationConfidence,
                    parsehArabicCtcModelFile = modelManager.getParsehArabicCtcFile().takeIf { it.exists() && it.length() > 1024L },
                    parsehArabicVocabFile = modelManager.getParsehArabicVocabFile().takeIf { it.exists() },
                    parsehArabicMetaFile = modelManager.getParsehArabicMetaFile().takeIf { it.exists() },
                    precomputedVocalMono16k = vocalMono16k,
                    precomputedLeadVocalMono16k = leadVocalMono16k,
                    precomputedBackingVocalMono16k = backingVocalMono16k,
                    precomputedOnsetAnalysis = leadOnsetAnalysis,
                    precomputedBackingOnsetAnalysis = backingOnsetAnalysis
                ) { detail, alignFrac ->
                    val activeStage = if (alignFrac >= 0.92f) {
                        PipelineStage.STAGE_4_ONSET_SNAP
                    } else {
                        PipelineStage.STAGE_3_ALIGNMENT
                    }
                    val overall = 0.52f + 0.45f * alignFrac
                    updateState(
                        runId = runId,
                        startTimeMs = startTimeMs,
                        stage = activeStage,
                        detail = detail,
                        progress = overall
                    )
                }
                val alignmentWarnings = aligner.lastAlignmentDiagnostics
                val heuristicWordCount = alignedLines.sumOf { line ->
                    line.words.orEmpty().count { it.needsReview && (it.confidence ?: 1f) <= 0.45f }
                }
                val warningDetail = (listOfNotNull(ctcProvisioningWarning) + alignmentWarnings).distinct()
                    .take(2)
                    .joinToString(" ")
                val allPipelineWarnings = listOfNotNull(separationWarning, warningDetail)
                    .filter { it.isNotBlank() }
                    .joinToString(" ")
                val alignmentModeSummary = if (aligner.lastAlignmentUsedHeuristicFallback) {
                    "Neural CTC was unavailable or not used for some or all words; acoustic fallback was used for at least $heuristicWordCount word(s), marked for review. $allPipelineWarnings"
                } else {
                    val attemptWarning = if (alignmentWarnings.isNotEmpty()) {
                        "Neural CTC completed, but an initialization/inference attempt failed; timings actually produced by fallback are marked for review."
                    } else ""
                    "Neural CTC alignment completed for the selected script(s). $attemptWarning $allPipelineWarnings"
                }

                val vocalOnsets = leadOnsetAnalysis.onsetsSeconds

                updateState(
                    runId = runId,
                    startTimeMs = startTimeMs,
                    stage = PipelineStage.STAGE_4_ONSET_SNAP,
                    detail = "Serializing TTML and checking XML well-formedness and root element…",
                    progress = 0.98f
                )

                val referencedIds = alignedLines.map { it.agentId }.toSet()
                val mergedAgents = (request.agents + Agent.AGENT_PRESETS.filter { referencedIds.contains(it.id) })
                    .distinctBy { it.id }

                val ttmlXml = TtmlSerializer.generateTTML(
                    TTMLOptions(
                        metadata = updatedMetadata,
                        agents = mergedAgents,
                        lines = alignedLines,
                        duration = songDurationSec
                    )
                )
                val validation = TtmlValidatorAndParser.validateTtml(ttmlXml)

                val elapsed = System.currentTimeMillis() - startTimeMs
                runOwnership.runIfCurrent(runId) {
                    _pipelineState.value = PipelineState(
                        stage = PipelineStage.COMPLETED,
                        detailMessage = "Generated ${alignedLines.size} lines (${alignedLines.sumOf { it.words?.size ?: 0 }} timed spans) in ${elapsed / 1000}s. $alignmentModeSummary Instrumental export is unavailable; XML check is not schema validation.",
                        overallProgress = 1.0f,
                        elapsedMillis = elapsed,
                        resultLines = alignedLines,
                        resultMetadata = updatedMetadata,
                        generatedTtmlXml = ttmlXml,
                        validationStatus = validation,
                        vocalsWavFile = vocalsWav,
                        instrumentalWavFile = null,
                        vocalOnsetSeconds = vocalOnsets,
                        primingSamplesStripped = primingStripped
                    )
                    updateNotification(
                        title = if (aligner.lastAlignmentUsedHeuristicFallback) "Alignment Complete — Review Timings" else "Alignment Complete",
                        detail = alignmentModeSummary,
                        progressPercent = 100,
                        ongoing = false
                    )
                }
            } catch (ce: CancellationException) {
                runOwnership.runIfCurrent(runId) {
                    _pipelineState.value = _pipelineState.value.copy(
                        stage = PipelineStage.CANCELLED,
                        detailMessage = "Alignment pipeline cancelled by user."
                    )
                }
            } catch (t: Throwable) {
                runOwnership.runIfCurrent(runId) {
                    val message = "Alignment failed: ${t.message ?: t.javaClass.simpleName}"
                    _pipelineState.value = _pipelineState.value.copy(
                        stage = PipelineStage.FAILED,
                        detailMessage = message
                    )
                    updateNotification(
                        title = "Alignment failed",
                        detail = message,
                        progressPercent = 0,
                        ongoing = false
                    )
                }
            } finally {
                finishOwnedRun(runId) { stopForeground(STOP_FOREGROUND_DETACH) }
            }
                }
                currentJob = runJob
                currentJobOwnerRunId = runId
                runJob.start()
            }
        }
    }

    fun cancelPipeline() {
        synchronized(lifecycleGuard) {
            val runId = runOwnership.currentRunId() ?: return
            if (currentJobOwnerRunId == runId) currentJob?.cancel()
            finishOwnedRun(runId) {
                _pipelineState.value = _pipelineState.value.copy(
                    stage = PipelineStage.CANCELLED,
                    detailMessage = "Alignment pipeline cancelled by user."
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
            }
        }
    }

    private fun updateState(
        runId: Long,
        startTimeMs: Long,
        stage: PipelineStage,
        detail: String,
        progress: Float
    ) {
        runOwnership.runIfCurrent(runId) {
            val elapsed = System.currentTimeMillis() - startTimeMs
            _pipelineState.value = _pipelineState.value.copy(
                stage = stage,
                detailMessage = detail,
                overallProgress = progress.coerceIn(0f, 1f),
                elapsedMillis = elapsed
            )
            updateNotification(
                title = stage.title,
                detail = detail,
                progressPercent = (progress * 100f).toInt().coerceIn(0, 100),
                ongoing = true
            )
        }
    }

    private fun acquireWakeLock(runId: Long) {
        synchronized(lifecycleGuard) {
            if (!runOwnership.isCurrent(runId)) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock?.isHeld != true) {
                wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "BetterLyrics::AlignmentWakeLock"
                ).apply {
                    acquire(60 * 60 * 1000L)
                }
            }
            wakeLockOwnerRunId = runId
        }
    }

    private fun finishOwnedRun(runId: Long, onFinish: () -> Unit = {}): Boolean = synchronized(lifecycleGuard) {
        if (!runOwnership.finishRun(runId)) return@synchronized false
        if (currentJobOwnerRunId == runId) {
            currentJob = null
            currentJobOwnerRunId = null
        }
        if (wakeLockOwnerRunId == runId) {
            runCatching {
                if (wakeLock?.isHeld == true) wakeLock?.release()
            }
            wakeLock = null
            wakeLockOwnerRunId = null
        }
        onFinish()
        true
    }

    private fun failStartupRun(runId: Long, message: String): Boolean = synchronized(lifecycleGuard) {
        runOwnership.failRun(runId) {
            if (wakeLockOwnerRunId == runId) {
                runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
                wakeLock = null
                wakeLockOwnerRunId = null
            }
            _pipelineState.value = _pipelineState.value.copy(
                stage = PipelineStage.FAILED,
                detailMessage = message,
                overallProgress = 0f
            )
            updateNotification(
                title = "Could not start alignment",
                detail = message,
                progressPercent = 0,
                ongoing = false
            )
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        }
    }

    private fun releaseWakeLock() {
        synchronized(lifecycleGuard) {
            runCatching {
                if (wakeLock?.isHeld == true) wakeLock?.release()
            }
            wakeLock = null
            wakeLockOwnerRunId = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Better Lyrics Audio DSP & AI Alignment",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live progress for offline HTDemucs vocal isolation and forced alignment"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildProgressNotification(
        title: String,
        detail: String,
        progressPercent: Int,
        ongoing: Boolean = true
    ): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(this, AlignmentForegroundService::class.java).apply {
            action = ACTION_CANCEL_PIPELINE
        }
        val cancelPending = PendingIntent.getService(
            this,
            1,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setProgress(100, progressPercent, false)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPending)
            .apply {
                if (ongoing) {
                    addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelPending)
                }
            }
            .build()
    }

    private fun updateNotification(
        title: String,
        detail: String,
        progressPercent: Int,
        ongoing: Boolean
    ) {
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildProgressNotification(title, detail, progressPercent, ongoing))
        }
    }

    override fun onDestroy() {
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }
}
