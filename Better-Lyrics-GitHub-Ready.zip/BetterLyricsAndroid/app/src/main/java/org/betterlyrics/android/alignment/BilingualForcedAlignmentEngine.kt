package org.betterlyrics.android.alignment

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.betterlyrics.android.domain.ttml.LyricLine
import org.betterlyrics.android.domain.ttml.TtmlConstants
import org.betterlyrics.android.domain.ttml.WordSpacesAndSyllables
import org.betterlyrics.android.domain.ttml.WordTiming
import org.betterlyrics.android.dsp.AudioCodec
import org.betterlyrics.android.dsp.SpectralFluxAnalysis
import org.betterlyrics.android.dsp.SpectralOnsetDetector
import org.betterlyrics.android.dsp.StftProcessor
import org.betterlyrics.android.dsp.VocalOnsetSnapper
import java.io.File
import java.nio.FloatBuffer
import java.util.Locale
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.ln1p
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

// ================================================================================================
// 1. SCRIPT DETECTION & ARABIC / ENGLISH PHONEME-GRAPHEME NORMALIZER
// ================================================================================================

enum class WordScript {
    ARABIC,
    LATIN_ENGLISH,
    NEUTRAL
}

enum class PhonemeMannerClass {
    VOWEL_LONG_MADD,    // Sustained Arabic Madd (ا، آ، و، ي، ى) or English diphthong/long vowel
    VOWEL_SHORT,        // Short vowels (a, e, i, o, u, y)
    NASAL_LIQUID,       // Sonorant nasals & liquids (m, n, l, r, w, م، ن، ل، ر)
    FRICATIVE_SIBILANT, // High-frequency fricatives/sibilants (s, z, f, v, sh, س، ش، ص، ف، ث، خ، ح، ز، ذ، ه)
    PLOSIVE_STOP        // Transient stops/plosives (p, t, k, b, d, g, q, ب، ت، ط، د، ض، ك، ق، ء، ج، ع، غ)
}

object BilingualScriptAndNormalizer {

    private val ARABIC_CHAR_REGEX = Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\u08A0-\\u08FF\\uFB50-\\uFDFF\\uFE70-\\uFEFF]")
    private const val TATWEEL = '\u0640'
    private const val SHADDA = '\u0651'

    private val ARABIC_MADD_LETTERS = setOf('ا', 'آ', 'و', 'ي', 'ى')
    private val ARABIC_FRICATIVES = setOf('س', 'ش', 'ص', 'ض', 'ف', 'ث', 'ذ', 'ز', 'خ', 'ح', 'ه', 'ظ')
    private val ARABIC_NASAL_LIQUIDS = setOf('م', 'ن', 'ل', 'ر')

    private val ENGLISH_VOWELS = setOf('a', 'e', 'i', 'o', 'u', 'y')
    private val ENGLISH_FRICATIVES = setOf('s', 'z', 'f', 'v', 'h', 'c', 'x')
    private val ENGLISH_NASAL_LIQUIDS = setOf('m', 'n', 'l', 'r', 'w')

    fun detectNonLatinLanguage(text: String): String? {
        if (ARABIC_CHAR_REGEX.containsMatchIn(text)) return "ar"
        if (Regex("[\\u3040-\\u30FF]").containsMatchIn(text)) return "ja"
        if (Regex("[\\uAC00-\\uD7AF]").containsMatchIn(text)) return "ko"
        if (Regex("[\\u4E00-\\u9FFF]").containsMatchIn(text)) return "zh"
        if (Regex("[\\u0400-\\u04FF]").containsMatchIn(text)) return "ru"
        if (Regex("[\\u0900-\\u097F]").containsMatchIn(text)) return "hi"
        if (Regex("[\\u0590-\\u05FF]").containsMatchIn(text)) return "he"
        return null
    }

    fun isArabicWord(text: String): Boolean = ARABIC_CHAR_REGEX.containsMatchIn(text)

    /**
     * Identifies the script of an individual word token (`ARABIC`, `LATIN_ENGLISH`, or `NEUTRAL`)
     * so intra-line mixed lyrics such as `"أنا feel alive لما you call me"` route Arabic words
     * to the Arabic CTC model + vocabulary and English words to the English CTC model + vocabulary.
     */
    fun classifyWordScript(rawWord: String): WordScript {
        var arCount = 0
        var latCount = 0
        for (ch in rawWord) {
            if (ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' || ch in '\u08A0'..'\u08FF' || ch in '\uFB50'..'\uFEFF') {
                arCount++
            } else if (ch in 'a'..'z' || ch in 'A'..'Z') {
                latCount++
            }
        }
        return when {
            arCount > 0 && arCount >= latCount -> WordScript.ARABIC
            latCount > 0 -> WordScript.LATIN_ENGLISH
            else -> WordScript.NEUTRAL
        }
    }

    fun detectDominantLanguage(lines: List<LyricLine>): String {
        var arabicCount = 0
        var totalWords = 0
        for (line in lines) {
            val tokens = line.text.split(Regex("\\s+")).filter { it.isNotEmpty() }
            for (t in tokens) {
                totalWords++
                if (isArabicWord(t)) arabicCount++
            }
        }
        return if (totalWords > 0 && arabicCount * 2 >= totalWords) "ar" else "en"
    }

    /**
     * Normalizes an Arabic or English word *internally* for the neural CTC vocabulary lookup
     * while the caller strictly preserves the original orthographic surface (including all
     * Tashkeel, Hamzas, Alef variants, and punctuation) for the final TTML `<span>`.
     */
    fun normalizeForNeuralCtc(rawWord: String): String {
        val sb = StringBuilder(rawWord.length)
        for (ch in rawWord) {
            when (ch) {
                TATWEEL -> continue
                in '\u064B'..'\u065F', '\u0670' -> continue
                'ٱ' -> sb.append('ا')
                'ک' -> sb.append('ك')
                'ی', 'ے' -> sb.append('ي')
                'ۀ' -> sb.append('ه')
                '’', '‘', '`' -> sb.append('\'')
                else -> {
                    // Preserve exact Arabic letters (أ, إ, آ, ة, ى, ؤ, ئ, ء) so vocab.json matches them directly
                    if (Character.isLetterOrDigit(ch) || ch == '\'' || ch in '\u0621'..'\u064A') {
                        sb.append(ch.lowercaseChar())
                    }
                }
            }
        }
        return sb.toString().ifEmpty { "a" }
    }

    /**
     * Canonical grapheme normalization for acoustic unit weighting & cross-script matching.
     * Normalizes Alef/Hamza/Teh-Marbuta/Yeh variants and strips Tashkeel without inserting
     * guessed Latin vowels that could distort syllable counts or overpower acoustic evidence.
     */
    fun normalizeForAcousticModel(rawWord: String): String {
        val rawNorm = StringBuilder(rawWord.length)
        for (ch in rawWord) {
            when (ch) {
                TATWEEL -> continue
                in '\u064B'..'\u065F', '\u0670' -> continue
                'أ', 'إ', 'آ', 'ٱ' -> rawNorm.append('ا')
                'ى', 'ی', 'ے', 'ئ' -> rawNorm.append('ي')
                'ة', 'ۀ' -> sbAppendTehMarbuta(rawNorm)
                'ؤ' -> rawNorm.append('و')
                'ک' -> rawNorm.append('ك')
                '’', '‘', '`' -> rawNorm.append('\'')
                else -> {
                    if (Character.isLetterOrDigit(ch) || ch == '\'' || ch in '\u0621'..'\u064A') {
                        rawNorm.append(ch.lowercaseChar())
                    }
                }
            }
        }
        return rawNorm.toString().ifEmpty { "a" }
    }

    private fun sbAppendTehMarbuta(sb: StringBuilder) {
        sb.append('ه')
    }

    fun hasArabicMaddOrMelisma(rawWord: String): Boolean {
        if (!isArabicWord(rawWord)) return false
        if (rawWord.contains(TATWEEL) || rawWord.contains('آ')) return true
        for (i in 1 until rawWord.length) {
            if (ARABIC_MADD_LETTERS.contains(rawWord[i])) return true
        }
        return false
    }

    fun classifyPhonemeManner(rawWord: String, units: String): Array<PhonemeMannerClass> {
        val isAr = isArabicWord(rawWord)
        return Array(units.length.coerceAtLeast(1)) { idx ->
            val ch = units.getOrNull(idx) ?: 'a'
            if (isAr) {
                when {
                    idx > 0 && ARABIC_MADD_LETTERS.contains(ch) -> PhonemeMannerClass.VOWEL_LONG_MADD
                    ch == 'a' || ch == 'u' || ch == 'i' || (idx == 0 && ch == 'ا') -> PhonemeMannerClass.VOWEL_SHORT
                    ARABIC_FRICATIVES.contains(ch) -> PhonemeMannerClass.FRICATIVE_SIBILANT
                    ARABIC_NASAL_LIQUIDS.contains(ch) -> PhonemeMannerClass.NASAL_LIQUID
                    else -> PhonemeMannerClass.PLOSIVE_STOP
                }
            } else {
                val nextCh = units.getOrNull(idx + 1)
                when {
                    ENGLISH_VOWELS.contains(ch) && (nextCh != null && (ENGLISH_VOWELS.contains(nextCh) || nextCh == 'w' || nextCh == 'y')) ->
                        PhonemeMannerClass.VOWEL_LONG_MADD
                    ENGLISH_VOWELS.contains(ch) -> PhonemeMannerClass.VOWEL_SHORT
                    ENGLISH_FRICATIVES.contains(ch) -> PhonemeMannerClass.FRICATIVE_SIBILANT
                    ENGLISH_NASAL_LIQUIDS.contains(ch) -> PhonemeMannerClass.NASAL_LIQUID
                    else -> PhonemeMannerClass.PLOSIVE_STOP
                }
            }
        }
    }

    fun computeAcousticUnitWeights(rawWord: String, manners: Array<PhonemeMannerClass>): FloatArray {
        val hasShadda = rawWord.contains(SHADDA)
        val norm = normalizeForAcousticModel(rawWord)
        // Silent Otiose Alef (الألف الفارقة) in Arabic plural verbs ending in "وا" (e.g., قالوا, نسوا, راحوا)
        val hasSilentFinalAlefAfterWaw = norm.length >= 3 && norm.endsWith("وا")
        return FloatArray(manners.size) { idx ->
            if (hasSilentFinalAlefAfterWaw && idx == manners.lastIndex) {
                0.15f
            } else {
                val base = when (manners[idx]) {
                    PhonemeMannerClass.VOWEL_LONG_MADD -> 2.4f
                    PhonemeMannerClass.VOWEL_SHORT -> 1.55f
                    PhonemeMannerClass.NASAL_LIQUID -> 1.15f
                    PhonemeMannerClass.FRICATIVE_SIBILANT -> 0.90f
                    PhonemeMannerClass.PLOSIVE_STOP -> 0.65f
                }
                if (hasShadda && idx == manners.size / 2) base * 1.35f else base
            }
        }
    }
}

// ================================================================================================
// 2. DYNAMIC HUGGINGFACE CTC VOCABULARY MAPPER (Reads exact vocab.json for Arabic & English ONNX)
// ================================================================================================

class CtcVocab(
    private val tokenToId: Map<String, Int>,
    explicitBlankId: Int? = null,
    explicitDelimiterId: Int? = null
) {
    val size: Int = (tokenToId.values.maxOrNull() ?: 32) + 1

    val blankId: Int = explicitBlankId
        ?: tokenToId["<pad>"]
        ?: tokenToId["<blank>"]
        ?: tokenToId["<eps>"]
        ?: tokenToId["<s>"]
        ?: 0

    val wordDelimiterId: Int = explicitDelimiterId
        ?: tokenToId["|"]
        ?: tokenToId[" "]
        ?: tokenToId["▁"]
        ?: tokenToId["<unk>"]
        ?: blankId

    fun lookupCharIdOrNull(ch: Char): Int? {
        val s = ch.toString()
        tokenToId[s]?.let { return it }
        tokenToId[s.uppercase(Locale.ROOT)]?.let { return it }
        tokenToId[s.lowercase(Locale.ROOT)]?.let { return it }
        return when (ch) {
            'أ', 'إ', 'آ', 'ٱ' -> tokenToId["ا"] ?: tokenToId["أ"] ?: tokenToId["إ"] ?: tokenToId["آ"]
            'ا' -> tokenToId["أ"] ?: tokenToId["إ"] ?: tokenToId["آ"]
            'ة', 'ۀ' -> tokenToId["ه"] ?: tokenToId["ت"]
            'ه' -> tokenToId["ة"]
            'ى', 'ی', 'ے' -> tokenToId["ي"] ?: tokenToId["ئ"]
            'ي' -> tokenToId["ى"] ?: tokenToId["ئ"]
            'ؤ' -> tokenToId["و"] ?: tokenToId["ء"]
            'ئ' -> tokenToId["ي"] ?: tokenToId["ى"] ?: tokenToId["ء"]
            'ک' -> tokenToId["ك"]
            else -> null
        }
    }

    /**
     * Soft secondary phonetic variant lookup for Egyptian Arabic (ar-EG) & singing realizations:
     * Allows the CTC trellis to score colloquial Egyptian realizations without rewriting the user's
     * written text or penalizing standard MSA pronunciation:
     *   - 'ق' -> glottal stop ('ء' / 'أ' / 'ا') or Cairo voiced velar ('ج')
     *   - 'ث' -> alveolar ('س' / 'ت')
     *   - 'ذ' -> alveolar ('ز' / 'د')
     *   - 'ظ' -> emphatic alveolar ('ز' / 'ض')
     *   - 'ة' -> construct state ('ت') vs pausal ('ه' / 'ا')
     *   - 'ى' -> long open vowel ('ا' / 'ي')
     */
    fun lookupSecondaryCharIdOrNull(ch: Char): Int? {
        return when (ch) {
            'ق' -> tokenToId["ء"] ?: tokenToId["أ"] ?: tokenToId["ا"] ?: tokenToId["ج"]
            'ث' -> tokenToId["س"] ?: tokenToId["ت"]
            'ذ' -> tokenToId["ز"] ?: tokenToId["د"]
            'ظ' -> tokenToId["ز"] ?: tokenToId["ض"]
            'ة', 'ۀ' -> tokenToId["ت"] ?: tokenToId["ه"] ?: tokenToId["ا"]
            'ه' -> tokenToId["ة"] ?: tokenToId["ا"]
            'ى' -> tokenToId["ا"] ?: tokenToId["ي"]
            'ؤ' -> tokenToId["ء"] ?: tokenToId["و"]
            'ئ' -> tokenToId["ء"] ?: tokenToId["ي"]
            'ج' -> tokenToId["گ"] ?: tokenToId["ك"]
            else -> null
        }
    }

    fun lookupCharId(ch: Char): Int = lookupCharIdOrNull(ch) ?: tokenToId["<unk>"] ?: blankId

    companion object {
        fun fromJsonFile(vocabFile: File?, isArabic: Boolean, metaFile: File? = null): CtcVocab {
            val map = mutableMapOf<String, Int>()
            var explicitBlank: Int? = null
            var explicitDelim: Int? = null

            fun parseJsonElementToMap(el: kotlinx.serialization.json.JsonElement) {
                when (el) {
                    is JsonObject -> {
                        // Check if it is {"token": 0} or {"0": "token"}
                        val firstVal = el.values.firstOrNull()
                        if (firstVal is JsonPrimitive && firstVal.isString && el.keys.firstOrNull()?.toIntOrNull() != null) {
                            for ((k, v) in el) {
                                val id = k.toIntOrNull() ?: continue
                                val tok = (v as? JsonPrimitive)?.content ?: continue
                                map[tok] = id
                            }
                        } else {
                            for ((k, v) in el) {
                                val id = (v as? JsonPrimitive)?.content?.toIntOrNull() ?: continue
                                map[k] = id
                            }
                        }
                    }
                    is kotlinx.serialization.json.JsonArray -> {
                        el.forEachIndexed { idx, item ->
                            val tok = (item as? JsonPrimitive)?.content
                            if (tok != null) map[tok] = idx
                        }
                    }
                    else -> {}
                }
            }

            // 1. Read meta.json if present (e.g. Download/TTML-models/aligner-ar/meta.json)
            val resolvedMeta = metaFile ?: vocabFile?.parentFile?.let { File(it, "meta.json") }
            if (resolvedMeta != null && resolvedMeta.exists() && resolvedMeta.length() > 10L) {
                runCatching {
                    val root = Json.parseToJsonElement(resolvedMeta.readText(Charsets.UTF_8)) as? JsonObject
                    if (root != null) {
                        root["vocab"]?.let { parseJsonElementToMap(it) }
                        root["tokens"]?.let { parseJsonElementToMap(it) }
                        explicitBlank = (root["blank_id"] as? JsonPrimitive)?.content?.toIntOrNull()
                            ?: (root["pad_token_id"] as? JsonPrimitive)?.content?.toIntOrNull()
                        val delimToken = (root["word_delimiter_token"] as? JsonPrimitive)?.content
                            ?: (root["delimiter"] as? JsonPrimitive)?.content
                        if (delimToken != null && map.containsKey(delimToken)) {
                            explicitDelim = map[delimToken]
                        }
                    }
                }
            }

            // 2. Read vocab.json if present (e.g. Download/TTML-models/aligner-ar/vocab.json)
            if (vocabFile != null && vocabFile.exists() && vocabFile.length() > 10L) {
                runCatching {
                    val root = Json.parseToJsonElement(vocabFile.readText(Charsets.UTF_8))
                    if (root is JsonObject && root.containsKey("vocab") && root["vocab"] is JsonObject) {
                        parseJsonElementToMap(root["vocab"]!!)
                    } else {
                        parseJsonElementToMap(root)
                    }
                }
            }

            if (map.isNotEmpty()) {
                return CtcVocab(map, explicitBlank, explicitDelim)
            }

            // Fallback default Wav2Vec2 vocabularies if vocab.json is not yet extracted
            val fallback = mutableMapOf<String, Int>()
            if (isArabic) {
                fallback["<pad>"] = 0
                fallback["<s>"] = 1
                fallback["</s>"] = 2
                fallback["<unk>"] = 3
                fallback["|"] = 4
                val arChars = listOf(
                    "ء", "آ", "أ", "ؤ", "إ", "ئ", "ا", "ب", "ة", "ت", "ث", "ج", "ح", "خ",
                    "د", "ذ", "ر", "ز", "س", "ش", "ص", "ض", "ط", "ظ", "ع", "غ", "ف", "ق",
                    "ك", "ل", "م", "ن", "ه", "و", "ى", "ي"
                )
                arChars.forEachIndexed { idx, c -> fallback[c] = idx + 5 }
            } else {
                fallback["<pad>"] = 0
                fallback["<s>"] = 1
                fallback["</s>"] = 2
                fallback["<unk>"] = 3
                fallback["|"] = 4
                fallback["'"] = 5
                ('A'..'Z').forEachIndexed { idx, c -> fallback[c.toString()] = idx + 6 }
            }
            return CtcVocab(fallback, explicitBlank, explicitDelim)
        }
    }
}

// ================================================================================================
// 3. BILINGUAL SYLLABLE SPLITTER (Compatible with src/utils/single-word-syllable-split.ts)
// ================================================================================================

object BilingualSyllabifier {
    private val EN_VOWELS = setOf('a', 'e', 'i', 'o', 'u', 'y')
    private val AR_LONG_VOWELS = setOf('ا', 'آ', 'و', 'ي', 'ى')
    private val AR_SHORT_VOWEL_HARAKAT = setOf('\u064E', '\u064F', '\u0650')

    fun findSyllableSplitPoints(wordText: String): List<Int> {
        val core = wordText.trimEnd()
        if (core.length < 5) return emptyList()
        return if (BilingualScriptAndNormalizer.isArabicWord(core)) {
            findArabicSyllableSplits(core)
        } else {
            findEnglishSyllableSplits(core)
        }
    }

    private fun findArabicSyllableSplits(core: String): List<Int> {
        val splits = mutableListOf<Int>()
        var i = 0
        var lastSplit = 0
        while (i < core.length) {
            val ch = core[i]
            val isMadd = i > lastSplit && AR_LONG_VOWELS.contains(ch)
            val isHarakat = AR_SHORT_VOWEL_HARAKAT.contains(ch)
            if (isMadd || isHarakat) {
                var splitCandidate = i + 1
                while (splitCandidate < core.length && core[splitCandidate] in '\u064B'..'\u065F') {
                    splitCandidate++
                }
                if (splitCandidate - lastSplit >= 2 && core.length - splitCandidate >= 2) {
                    splits.add(splitCandidate)
                    lastSplit = splitCandidate
                    i = splitCandidate
                    continue
                }
            }
            i++
        }
        return splits
    }

    private fun findEnglishSyllableSplits(core: String): List<Int> {
        val lower = core.lowercase(Locale.ROOT)
        if (lower.contains('\'') && lower.length <= 6) return emptyList()

        val splits = mutableListOf<Int>()
        var i = 1
        var lastSplit = 0
        while (i < lower.length - 2) {
            val prevVowel = EN_VOWELS.contains(lower[i - 1])
            val curVowel = EN_VOWELS.contains(lower[i])
            val nextVowel = EN_VOWELS.contains(lower[i + 1])
            val nextNextVowel = EN_VOWELS.contains(lower[i + 2])

            if (prevVowel && !curVowel && nextVowel && i + 1 < lower.length - 1) {
                if (i - lastSplit >= 2) {
                    splits.add(i)
                    lastSplit = i
                }
            } else if (prevVowel && !curVowel && !nextVowel && nextNextVowel) {
                val splitAt = i + 1
                if (splitAt - lastSplit >= 2 && lower.length - splitAt >= 2) {
                    splits.add(splitAt)
                    lastSplit = splitAt
                    i = splitAt
                }
            }
            i++
        }
        return splits
    }
}

// ================================================================================================
// 4. STAGE 3: MULTI-PASS JOINT DECODER (NEURAL CTC + 10ms SPECTRAL-PHONETIC + 5ms POLISH)
//    Ported from ttml_lyrics_generator-4.ipynb (ttmlgen Joint Decoder & LRC Offset Corrector)
// ================================================================================================

enum class ArabicAlignmentBackend(val title: String) {
    AUTO_CALIBRATED("Auto (Calibrated Parseh XLSR-53 / Wav2Vec2 Base)"),
    PARSEH_ALIGNER_AR("Parseh Aligner-AR (XLSR-53 24-Layer INT8)"),
    WAV2VEC2_BASE_AR("Wav2Vec2 Base Arabic (12-Layer INT8)")
}

enum class AlignmentAudioSource(val label: String) {
    ORIGINAL_MIX("Original Stereo Mixture (Consonant Reference)"),
    DEMUCS_VOCAL_STEM("Separated Vocal Stem (Lead + Backing)"),
    ISOLATED_LEAD_STEM("Stage-2 Isolated Lead Vocals (v1)"),
    ISOLATED_BACKING_STEM("Stage-2 Isolated Backing Vocals (v2 / x-bg)")
}

data class ForcedAlignmentConfig(
    val lrcWindowPaddingSeconds: Double = 1.20,
    val enableSyllableSplitting: Boolean = false,
    val minSyllableSplitDurationSec: Double = 0.55,
    val extractAndAlignBackgroundVocals: Boolean = true,
    val snapToSpectralOnsets: Boolean = true,
    val autoCorrectLrcGlobalOffset: Boolean = true,
    val arabicBackend: ArabicAlignmentBackend = ArabicAlignmentBackend.AUTO_CALIBRATED,
    val enableChorusMultiSourceComparison: Boolean = true,
    val enableSustainedEndRefinement: Boolean = true,
    val maxSustainedWordExtensionSec: Double = 2.60,
    val enableCrossLineCoupledAlignment: Boolean = true,
    // v5: measured regression (scrambled word order on refrains), so off by default.
    val enableNeighborContextAlignment: Boolean = false,
    // v5: hard cap for the duration of a line's final word after the Stage 4 snapper. Hand-timed references hold
    // last words ~1.0-1.8 s; the snapper's sustained-voice follower otherwise runs them to the 2.6 s ceiling.
    val maxFinalWordDurationSec: Double = 1.80
)

/**
 * Diagnostic report for a single lyric-line transition (`line[i] -> line[i+1]`),
 * explaining how the previous word end and the next line first word start were resolved.
 */
data class LineTransitionDiagnostic(
    val transitionIndex: Int,
    val fromLineId: String,
    val toLineId: String,
    val agentId: String,
    val nextAgentId: String,
    val prevWordText: String,
    val prevWordInitialEndSec: Double,
    val prevWordRefinedEndSec: Double,
    val nextLineNominalLrcSec: Double,
    val nextWordText: String,
    val nextWordInitialBeginSec: Double,
    val nextWordRefinedBeginSec: Double,
    val nextWordRefinedEndSec: Double,
    val searchWindowBeginSec: Double,
    val searchWindowEndSec: Double,
    val appliedConstraint: String,
    val carriedAcrossLineBreak: Boolean,
    val leftEdgeClippedAndRealigned: Boolean,
    val transitionConfidence: Float
)

class BilingualForcedAlignmentEngine(
    explicitOrtEnv: OrtEnvironment? = null
) {
    private val ortEnv: OrtEnvironment by lazy {
        explicitOrtEnv ?: OrtEnvironment.getEnvironment()
    }

    @Volatile
    var lastTransitionDiagnostics: List<LineTransitionDiagnostic> = emptyList()
        private set

    @Volatile
    var lastAlignmentDiagnostics: List<String> = emptyList()
        private set

    @Volatile
    var lastAlignmentUsedHeuristicFallback: Boolean = false
        private set

    private val alignmentWarnings = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    private fun noteAlignmentWarning(reason: String) {
        alignmentWarnings.add(reason)
    }

    private fun noteHeuristicFallback(reason: String) {
        lastAlignmentUsedHeuristicFallback = true
        noteAlignmentWarning(reason)
    }

    private fun snapshotAlignmentDiagnostics(): List<String> =
        synchronized(alignmentWarnings) { alignmentWarnings.toList() }
    companion object {
        const val CTC_SAMPLE_RATE = 16_000
        const val FRAME_HOP_SAMPLES = 160 // 10ms high-resolution frame step (100 fps)
        const val FFT_SIZE = 512          // 32ms window @ 16kHz
    }

    private val hann512: FloatArray by lazy {
        FloatArray(FFT_SIZE) { i ->
            (0.5 * (1.0 - cos((2.0 * PI * i.toDouble()) / FFT_SIZE.toDouble()))).toFloat()
        }
    }

    /**
     * Executes the TTML Studio 2.0 Chorus-Aware, Multi-Source Forced Alignment Pipeline:
     * - Compares up to 4 audio sources where available:
     *     (A) `originalMono16k` (Original stereo mixture — preserves unvoiced plosives & sibilants)
     *     (B) `vocalMono16k` (Combined Demucs vocal stem)
     *     (C) `leadVocalMono16k` (Stage-2B isolated lead vocal stem for `v1`)
     *     (D) `backingVocalMono16k` (Stage-2B isolated backing vocal stem for `v2` / `x-bg`)
     * - Supports selectable Arabic CTC backends (`WAV2VEC2_BASE_AR`, `PARSEH_ALIGNER_AR`, or `AUTO_CALIBRATED`).
     * - Aligns repeated chorus occurrences independently within their own audio regions and distinguishes
     *   unison doubling, delayed vocal doubles, harmonies with different words, and inseparable choirs.
     */
    suspend fun alignLyricsToVocalStem(
        lines: List<LyricLine>,
        vocalChannels44k: Array<FloatArray>,
        songDurationSeconds: Double,
        ctcModelFile: File?,
        config: ForcedAlignmentConfig = ForcedAlignmentConfig(),
        arabicCtcModelFile: File? = ctcModelFile,
        arabicVocabFile: File? = null,
        englishCtcModelFile: File? = ctcModelFile,
        englishVocabFile: File? = null,
        originalMono16k: FloatArray? = null,
        leadVocalChannels44k: Array<FloatArray>? = null,
        backingVocalChannels44k: Array<FloatArray>? = null,
        leadBackingSeparationConfidence: Float = 0f,
        parsehArabicCtcModelFile: File? = null,
        parsehArabicVocabFile: File? = null,
        parsehArabicMetaFile: File? = null,
        precomputedVocalMono16k: FloatArray? = null,
        precomputedLeadVocalMono16k: FloatArray? = null,
        precomputedBackingVocalMono16k: FloatArray? = null,
        precomputedOnsetAnalysis: SpectralFluxAnalysis? = null,
        precomputedBackingOnsetAnalysis: SpectralFluxAnalysis? = null,
        onProgress: suspend (stageDetail: String, fraction: Float) -> Unit = { _, _ -> }
    ): List<LyricLine> = withContext(Dispatchers.Default) {
        if (lines.isEmpty()) return@withContext emptyList()
        alignmentWarnings.clear()
        lastAlignmentUsedHeuristicFallback = false
        lastAlignmentDiagnostics = emptyList()

        // Zero-44.1kHz-Allocation Stem Preparation:
        // Uses precomputed 16 kHz mono stems & spectral flux analyses when provided by the service
        // (so 0 bytes of 44.1 kHz audio remain in RAM during Stage 3), or streams directly via
        // `SpectralOnsetDetector.analyzeVocalChannels` and `AudioCodec.mixAndResampleToMono` without
        // ever allocating intermediate 69 MB 44.1 kHz mono arrays!
        onProgress("Mixing vocal stems & computing lead/backing spectral flux envelopes…", 0.04f)
        val onsetAnalysis = precomputedOnsetAnalysis
            ?: SpectralOnsetDetector.analyzeVocalChannels(leadVocalChannels44k ?: vocalChannels44k)
        val backingOnsetAnalysis = precomputedBackingOnsetAnalysis
            ?: if (backingVocalChannels44k != null && leadBackingSeparationConfidence >= 0.18f) {
                SpectralOnsetDetector.analyzeVocalChannels(backingVocalChannels44k)
            } else null

        onProgress("Resampling vocal, lead, and backing stems to 16 kHz…", 0.10f)
        val vocalMono16k = precomputedVocalMono16k ?: AudioCodec.mixAndResampleToMono(
            vocalChannels44k,
            fromRate = AudioCodec.TARGET_SAMPLE_RATE,
            toRate = CTC_SAMPLE_RATE
        )
        val leadVocalMono16k = precomputedLeadVocalMono16k
            ?: if (leadVocalChannels44k != null && leadVocalChannels44k !== vocalChannels44k) {
                AudioCodec.mixAndResampleToMono(
                    leadVocalChannels44k,
                    fromRate = AudioCodec.TARGET_SAMPLE_RATE,
                    toRate = CTC_SAMPLE_RATE
                )
            } else null
        val backingVocalMono16k = precomputedBackingVocalMono16k
            ?: if (backingVocalChannels44k != null && leadBackingSeparationConfidence >= 0.18f) {
                AudioCodec.mixAndResampleToMono(
                    backingVocalChannels44k,
                    fromRate = AudioCodec.TARGET_SAMPLE_RATE,
                    toRate = CTC_SAMPLE_RATE
                )
            } else null

        // Resolve Arabic model(s): supports wav2vec2-base-arabic and parseh/aligner-ar (XLSR-53 INT8)
        val hasParsehFile = parsehArabicCtcModelFile != null && parsehArabicCtcModelFile.exists() && parsehArabicCtcModelFile.length() > 1024L
        val primaryArFile = when (config.arabicBackend) {
            ArabicAlignmentBackend.PARSEH_ALIGNER_AR -> if (hasParsehFile) parsehArabicCtcModelFile else arabicCtcModelFile
            ArabicAlignmentBackend.WAV2VEC2_BASE_AR -> arabicCtcModelFile
            ArabicAlignmentBackend.AUTO_CALIBRATED -> if (hasParsehFile) parsehArabicCtcModelFile else arabicCtcModelFile
        }
        val primaryArVocabFile = if (primaryArFile == parsehArabicCtcModelFile && parsehArabicVocabFile?.exists() == true) {
            parsehArabicVocabFile
        } else {
            arabicVocabFile ?: primaryArFile?.parentFile?.let { File(it, "vocab_ar.json") }
        }
        val primaryArMetaFile = if (primaryArFile == parsehArabicCtcModelFile && parsehArabicMetaFile?.exists() == true) {
            parsehArabicMetaFile
        } else {
            primaryArFile?.parentFile?.let { File(it, "meta_ar.json") }
        }

        val arVocab = CtcVocab.fromJsonFile(
            vocabFile = primaryArVocabFile,
            isArabic = true,
            metaFile = primaryArMetaFile
        )
        val enVocab = CtcVocab.fromJsonFile(
            vocabFile = englishVocabFile ?: englishCtcModelFile?.parentFile?.let { File(it, "vocab_en.json") },
            isArabic = false,
            metaFile = englishCtcModelFile?.parentFile?.let { File(it, "meta_en.json") }
        )

        fun createSessionIfValid(f: File?): OrtSession? {
            if (f == null || !f.exists() || f.length() < 1024L) return null
            return runCatching {
                val opts = OrtSession.SessionOptions().apply {
                    setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT)
                    setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
                    setInterOpNumThreads(1)
                    setMemoryPatternOptimization(false)
                    setCPUArenaAllocator(false)
                }
                try {
                    ortEnv.createSession(f.absolutePath, opts)
                } finally {
                    runCatching { opts.close() }
                }
            }.onFailure {
                noteAlignmentWarning("Neural CTC model initialization failed: ${it.message ?: it.javaClass.simpleName}")
            }.getOrNull()
        }

        // Phase 2 Word-Level Script Audit across all main and background lyrics:
        var hasArabicWords = false
        var hasEnglishWords = false
        for (line in lines) {
            val combinedText = if (line.backgroundText.isNullOrBlank()) line.text else "${line.text} ${line.backgroundText}"
            for (tok in combinedText.split(Regex("\\s+"))) {
                when (BilingualScriptAndNormalizer.classifyWordScript(tok)) {
                    WordScript.ARABIC -> hasArabicWords = true
                    WordScript.LATIN_ENGLISH -> hasEnglishWords = true
                    WordScript.NEUTRAL -> {}
                }
            }
        }

        // Memory-safe Dual-Language Session Provisioning:
        // Load both Arabic and English ONNX CTC sessions when both scripts appear in the song.
        // If both models are large (> 260 MB combined) and JVM/native heap is constrained,
        // `enSession` is still created or opened sequentially per window without ever substituting `arSession` for English text.
        val arSession = if (hasArabicWords) createSessionIfValid(primaryArFile) else null
        val enSession = if (hasEnglishWords && englishCtcModelFile != null) {
            if (englishCtcModelFile.absolutePath == primaryArFile?.absolutePath && arSession != null) {
                arSession
            } else {
                createSessionIfValid(englishCtcModelFile)
            }
        } else null
        if (hasArabicWords && arSession == null) {
            noteHeuristicFallback("Arabic CTC model unavailable; Arabic timings use acoustic heuristics.")
        }
        if (hasEnglishWords && enSession == null) {
            noteHeuristicFallback("English CTC model unavailable; English timings use acoustic heuristics.")
        }

        val alignedLines: List<LyricLine> = try {
            val hasLrcAnchors = lines.count { it.isLineTimed } >= (lines.size / 2).coerceAtLeast(1)
            if (hasLrcAnchors) {
                val offsetCorrectedLines = if (config.autoCorrectLrcGlobalOffset) {
                    onProgress("Pass 0: Detecting & correcting global LRC offset against lead vocal stem…", 0.13f)
                    detectAndCorrectGlobalLrcOffset(lines, onsetAnalysis, songDurationSeconds)
                } else lines

                alignLrcAnchoredWindows(
                    lines = offsetCorrectedLines,
                    vocalMono16k = vocalMono16k,
                    originalMono16k = originalMono16k,
                    leadVocalMono16k = leadVocalMono16k,
                    backingVocalMono16k = backingVocalMono16k,
                    leadBackingSeparationConfidence = leadBackingSeparationConfidence,
                    songDurationSeconds = songDurationSeconds,
                    arSession = arSession,
                    arVocab = arVocab,
                    enSession = enSession,
                    enVocab = enVocab,
                    config = config,
                    onProgress = onProgress
                )
            } else {
                alignUnanchoredFullSong(
                    lines = lines,
                    vocalMono16k = vocalMono16k,
                    originalMono16k = originalMono16k,
                    leadVocalMono16k = leadVocalMono16k,
                    backingVocalMono16k = backingVocalMono16k,
                    leadBackingSeparationConfidence = leadBackingSeparationConfidence,
                    songDurationSeconds = songDurationSeconds,
                    arSession = arSession,
                    arVocab = arVocab,
                    enSession = enSession,
                    enVocab = enVocab,
                    config = config,
                    onProgress = onProgress
                )
            }
        } finally {
            runCatching { arSession?.close() }
            if (enSession !== arSession) {
                runCatching { enSession?.close() }
            }
        }

        val snappedLines = if (config.snapToSpectralOnsets) {
            onProgress("Stage 4: Locking per-singer (v1/v2/x-bg) boundaries to 5ms transients…", 0.95f)
            VocalOnsetSnapper.snapAndClampLines(
                lines = alignedLines,
                analysis = onsetAnalysis,
                sampleRate = AudioCodec.TARGET_SAMPLE_RATE,
                backingAnalysis = backingOnsetAnalysis,
                hasArabicMaddPredicate = BilingualScriptAndNormalizer::hasArabicMaddOrMelisma
            )
        } else {
            alignedLines
        }
        val finalLines = snappedLines.map { line ->
            // v5: the snapper (not the aligner) is what stretches final words and re-creates the "crushed first
            // words / huge last word" shape, so the guards must run after it.
            var words = line.words
            val lastW = words?.lastOrNull()
            if (words != null && words.size >= 2 && lastW != null &&
                lastW.syllableGroupId == null &&
                lastW.end - lastW.begin > config.maxFinalWordDurationSec
            ) {
                words = words.dropLast(1) + lastW.copy(end = lastW.begin + config.maxFinalWordDurationSec)
            }
            val fixed = redistributeCrushedWords(words)
            val finalWords = fixed ?: words
            if (finalWords !== line.words && finalWords != null) line.copy(words = finalWords).reconcile() else line
        }

        onProgress("Alignment complete.", 1.0f)
        lastAlignmentDiagnostics = snapshotAlignmentDiagnostics()
        finalLines
    }

    // --------------------------------------------------------------------------------------------
    // PASS 0: Automatic Global LRC Offset Detection & Correction (from ttml_lyrics_generator-4.ipynb)
    // --------------------------------------------------------------------------------------------

    /**
     * Port of the constant LRC offset detector described in `ttml_lyrics_generator-4.ipynb`:
     * Cross-correlates LRC line start timestamps against the isolated vocal stem's RMS + spectral
     * onset novelty curve across candidate shifts `[-2.50s .. +2.50s]` in 20ms increments.
     * Finds the shift `deltaSec` where LRC line starts best coincide with a breath-to-vocal attack.
     */
    private fun detectAndCorrectGlobalLrcOffset(
        lines: List<LyricLine>,
        analysis: SpectralFluxAnalysis,
        songDurationSeconds: Double
    ): List<LyricLine> {
        val rms = analysis.rms
        val novelty = analysis.novelty
        if (rms.size < 20) return lines

        val frameSec = StftProcessor.HOP_LENGTH.toDouble() / AudioCodec.TARGET_SAMPLE_RATE.toDouble()
        val timedStarts = lines.mapNotNull { it.effectiveBounds()?.begin }
        if (timedStarts.size < 3) return lines

        var bestShiftSec = 0.0
        var bestScore = -1e9
        var zeroShiftScore = -1e9

        // Search [-2.40s .. +2.40s] in 20ms steps
        for (step in -120..120) {
            val shiftSec = step * 0.020
            // Small Gaussian prior favoring shifts near 0 unless acoustic evidence is clearly stronger
            var score = -0.02 * (shiftSec * shiftSec)

            for (t0 in timedStarts) {
                val shifted = t0 + shiftSec
                if (shifted <= 0.30 || shifted >= songDurationSeconds - 0.60) continue

                val attackFrame = (shifted / frameSec).roundToInt().coerceIn(4, (rms.lastIndex - 12).coerceAtLeast(4))
                // Pre-line breath window: [-180ms .. -40ms] before line start
                var preRms = 0.0
                for (f in (attackFrame - 8)..(attackFrame - 2)) {
                    preRms += rms[f.coerceIn(0, rms.lastIndex)]
                }
                preRms /= 7.0

                // Post-attack vocal window: [0ms .. +450ms] after line start
                var postRms = 0.0
                for (f in attackFrame..(attackFrame + 18)) {
                    postRms += rms[f.coerceIn(0, rms.lastIndex)]
                }
                postRms /= 19.0

                // Onset novelty around attack: [-45ms .. +65ms]
                var peakNovelty = 0.0f
                for (f in (attackFrame - 2)..(attackFrame + 3)) {
                    val n = novelty[f.coerceIn(0, novelty.lastIndex)]
                    if (n > peakNovelty) peakNovelty = n
                }

                score += (postRms - 0.65 * preRms) * 12.0 + peakNovelty * 0.45
            }

            if (step == 0) zeroShiftScore = score
            if (score > bestScore) {
                bestScore = score
                bestShiftSec = shiftSec
            }
        }

        // Only apply global shift if it meaningfully improves vocal attack correlation (> 5%) and is >= 40ms
        if (abs(bestShiftSec) < 0.040 || bestScore <= zeroShiftScore * 1.05) {
            return lines
        }

        return lines.map { line ->
            val b = line.begin?.let { (it + bestShiftSec).coerceIn(0.0, songDurationSeconds) }
            val e = line.end?.let { (it + bestShiftSec).coerceIn((b ?: 0.0) + 0.15, songDurationSeconds) }
            val shiftedWords = line.words?.map { w ->
                val wb = (w.begin + bestShiftSec).coerceIn(0.0, songDurationSeconds)
                val we = (w.end + bestShiftSec).coerceIn(wb + 0.05, songDurationSeconds)
                w.copy(begin = wb, end = we)
            }
            line.copy(begin = b, end = e, words = shiftedWords).reconcile()
        }
    }

    // --------------------------------------------------------------------------------------------
    // MODE A: Multi-Pass LRC-Anchored Windowed Alignment
    // --------------------------------------------------------------------------------------------

    /**
     * Identifies chorus lines that repeat >= 2 times across the song by their normalized text
     * so each chorus repetition is aligned independently within its own local audio window
     * and evaluated against lead vs. backing stems.
     */
    internal fun detectRepeatedChorusLineIndices(lines: List<LyricLine>): Set<Int> {
        val counts = mutableMapOf<String, MutableList<Int>>()
        lines.forEachIndexed { idx, line ->
            val key = line.text.trim().split(Regex("\\s+"))
                .filter { it.isNotEmpty() }
                .joinToString(" ") { BilingualScriptAndNormalizer.normalizeForAcousticModel(it) }
            if (key.length >= 5) {
                counts.getOrPut(key) { mutableListOf() }.add(idx)
            }
        }
        val repeated = mutableSetOf<Int>()
        for ((_, indices) in counts) {
            if (indices.size >= 2) repeated.addAll(indices)
        }
        return repeated
    }

    private suspend fun alignLrcAnchoredWindows(
        lines: List<LyricLine>,
        vocalMono16k: FloatArray,
        originalMono16k: FloatArray?,
        leadVocalMono16k: FloatArray?,
        backingVocalMono16k: FloatArray?,
        leadBackingSeparationConfidence: Float,
        songDurationSeconds: Double,
        arSession: OrtSession?,
        arVocab: CtcVocab,
        enSession: OrtSession?,
        enVocab: CtcVocab,
        config: ForcedAlignmentConfig,
        onProgress: suspend (String, Float) -> Unit
    ): List<LyricLine> {
        val result = ArrayList<LyricLine>(lines.size)
        val repeatedChorusIndices = detectRepeatedChorusLineIndices(lines)

        for (i in lines.indices) {
            coroutineContext.ensureActive()
            val line = lines[i]
            val progress = 0.15f + 0.78f * (i.toFloat() / lines.size.coerceAtLeast(1).toFloat())
            val rawMainTokens = tokenizePreservingOrthography(line.text)
            val hasArTokens = rawMainTokens.any { it.script == WordScript.ARABIC }
            val hasEnTokens = rawMainTokens.any { it.script == WordScript.LATIN_ENGLISH }
            val isMixedBilingualLine = hasArTokens && hasEnTokens
            val isRepeatedChorus = repeatedChorusIndices.contains(i)
            val requiredNeuralModelsAvailable =
                (!hasArTokens || arSession != null) && (!hasEnTokens || enSession != null)
            val hasOverlappingNextVoice = lines.getOrNull(i + 1)?.let { next ->
                val nb = next.effectiveBounds()?.begin
                val curEnd = line.effectiveBounds()?.end
                next.agentId != line.agentId && nb != null && curEnd != null && nb < curEnd - 0.10
            } ?: false
            val isMultiLayerLine = isRepeatedChorus || !line.backgroundText.isNullOrBlank() || hasOverlappingNextVoice || line.agentId != "v1"
            val modeLabel = when {
                !requiredNeuralModelsAvailable -> "Acoustic fallback (one or more CTC models unavailable)"
                isMixedBilingualLine -> "Bilingual AR+EN Dual-CTC + Sustain Refiner"
                isMultiLayerLine -> "Chorus Multi-Stem CTC + Sustain Refiner"
                else -> "Neural CTC + Spectral Sustain Refiner"
            }

            onProgress("Aligning line ${i + 1}/${lines.size} ($modeLabel)…", progress)

            val bounds = line.effectiveBounds()
            if (bounds == null) {
                result.add(line)
                continue
            }

            // Preserve independent timing for different vocalists (v1, v2, v1000):
            // Only clamp a line's window against the previous and next line of the SAME singer (`agentId`)!
            val prevSameAgentEnd = (i - 1 downTo 0).firstNotNullOfOrNull { idx ->
                result.getOrNull(idx)?.takeIf { it.agentId == line.agentId }?.effectiveBounds()?.end
            } ?: 0.0
            val rawNextSameAgentBegin = ((i + 1) until lines.size).firstNotNullOfOrNull { idx ->
                lines[idx].takeIf { it.agentId == line.agentId }?.effectiveBounds()?.begin
            } ?: songDurationSeconds
            val nextAnyLineBegin = lines.getOrNull(i + 1)?.effectiveBounds()?.begin ?: songDurationSeconds
            val rawLrcNextBegin = if (lines.getOrNull(i + 1)?.agentId == line.agentId) {
                nextAnyLineBegin
            } else {
                max(rawNextSameAgentBegin, bounds.begin + 4.5).coerceAtMost(songDurationSeconds)
            }

            // Phase 3 Premature-End Fix: Do NOT allow an early/imperfect next LRC timestamp to automatically
            // truncate a sustained note! Check where the next line's vocal pause/attack actually occurs on the stem.
            val preferredMainStem = when {
                line.agentId == "v2" && backingVocalMono16k != null && leadBackingSeparationConfidence >= 0.32f && hasOverlappingNextVoice ->
                    backingVocalMono16k
                leadVocalMono16k != null -> leadVocalMono16k
                else -> vocalMono16k
            }
            val verifiedNextVocalBegin = findVerifiedNextLineVocalCeiling(
                stemMono16k = preferredMainStem,
                currentLineBeginSec = bounds.begin,
                nominalNextLineBeginSec = rawLrcNextBegin,
                songDurationSeconds = songDurationSeconds,
                maxExtensionSec = config.maxSustainedWordExtensionSec
            )

            // Critical Rule (Part B.6 & B.9):
            // 1. If the previous line of the same singer carried a sustained vowel across `bounds.begin`
            //    (`prevSameAgentEnd > bounds.begin + 0.02`), shift the effective anchor start to after
            //    that carried vowel so this line's first word never absorbs the previous word's tail!
            // 2. Conversely, if the previous line ended earlier (`prevSameAgentEnd < bounds.begin - 0.15`),
            //    provide up to 0.75s of pre-line audio context so a fast transition with a late LRC timestamp
            //    never clips the first word at the left edge of the window!
            val effectiveAnchorBegin = if (prevSameAgentEnd > bounds.begin + 0.02) {
                min(prevSameAgentEnd + 0.02, max(bounds.end - 0.20, bounds.begin + 1.80))
            } else {
                bounds.begin
            }
            val nextLineBegin = min(verifiedNextVocalBegin, max(bounds.end + 3.6, effectiveAnchorBegin + 16.0))
                .coerceAtLeast(effectiveAnchorBegin + 0.35)
            val naturalEnd = max(min(bounds.end, nextLineBegin), min(nextLineBegin, bounds.end + 0.85))
                .coerceAtLeast(effectiveAnchorBegin + 0.35)

            val preLookbackSec = if (prevSameAgentEnd > bounds.begin - 0.08) 0.12 else 0.75
            val winStartSec = max(prevSameAgentEnd, max(0.0, effectiveAnchorBegin - preLookbackSec))
            val winEndSec = min(
                songDurationSeconds,
                min(winStartSec + 18.0, max(nextLineBegin + 0.35, naturalEnd + config.lrcWindowPaddingSeconds))
            ).coerceAtLeast(winStartSec + 0.35)

            val suppressBleedStem = if (line.agentId == "v1" && (!line.backgroundText.isNullOrBlank() || hasOverlappingNextVoice) && leadBackingSeparationConfidence >= 0.22f) {
                backingVocalMono16k
            } else null

            var alignedMainWords = if (rawMainTokens.isNotEmpty()) {
                val primaryCandidate = alignTokensInWindow(
                    tokens = rawMainTokens,
                    vocalMono16k = preferredMainStem,
                    originalMono16k = originalMono16k,
                    winStartSec = winStartSec,
                    winEndSec = winEndSec,
                    anchorBeginSec = effectiveAnchorBegin,
                    anchorEndSec = naturalEnd,
                    hardMaxEndSec = verifiedNextVocalBegin,
                    arSession = arSession,
                    arVocab = arVocab,
                    enSession = enSession,
                    enVocab = enVocab,
                    config = config,
                    suppressBackingMono16k = suppressBleedStem
                )
                val primaryScore = primaryCandidate.mapNotNull { it.confidence }.average().toFloat()
                if (config.enableChorusMultiSourceComparison && preferredMainStem !== vocalMono16k && (isMultiLayerLine || primaryScore < 0.62f)) {
                    val combinedCandidate = alignTokensInWindow(
                        tokens = rawMainTokens,
                        vocalMono16k = vocalMono16k,
                        originalMono16k = originalMono16k,
                        winStartSec = winStartSec,
                        winEndSec = winEndSec,
                        anchorBeginSec = effectiveAnchorBegin,
                        anchorEndSec = naturalEnd,
                        hardMaxEndSec = verifiedNextVocalBegin,
                        arSession = arSession,
                        arVocab = arVocab,
                        enSession = enSession,
                        enVocab = enVocab,
                        config = config,
                        suppressBackingMono16k = suppressBleedStem
                    )
                    val combinedScore = combinedCandidate.mapNotNull { it.confidence }.average().toFloat()
                    if (combinedScore > primaryScore + 0.04f) {
                        combinedCandidate
                    } else {
                        primaryCandidate
                    }
                } else {
                    primaryCandidate
                }
            } else emptyList()

            if (alignedMainWords.isNotEmpty()) {
                val firstWordBegin = alignedMainWords.first().begin
                // Requirement 9: Detect if the first word was clipped at the left edge of the audio window
                val earliestAllowedByPrev = (i - 1 downTo 0).firstNotNullOfOrNull { idx ->
                    val prevLine = result.getOrNull(idx)?.takeIf { it.agentId == line.agentId }
                    val pWords = prevLine?.words
                    if (pWords != null && pWords.size >= 2) {
                        pWords[pWords.size - 2].end + 0.08
                    } else {
                        prevLine?.effectiveBounds()?.begin?.let { it + 0.20 }
                    }
                } ?: 0.0
                val isLeftEdgeClipped = (firstWordBegin <= winStartSec + 0.045) && (winStartSec > earliestAllowedByPrev + 0.06)

                val initialMeanConf = alignedMainWords.mapNotNull { it.confidence }.average().toFloat()
                val hasWeakWord = alignedMainWords.any { (it.confidence ?: 1.0f) < 0.45f }
                if (isLeftEdgeClipped || initialMeanConf < 0.52f || hasWeakWord) {
                    val widerStart = if (isLeftEdgeClipped) {
                        max(earliestAllowedByPrev, max(0.0, winStartSec - 0.65))
                    } else {
                        max(prevSameAgentEnd, max(0.0, winStartSec - 0.35))
                    }
                    val widerAnchorBegin = if (isLeftEdgeClipped) {
                        max(widerStart + 0.05, effectiveAnchorBegin - 0.45)
                    } else {
                        effectiveAnchorBegin
                    }
                    val widerEnd = min(songDurationSeconds, max(widerStart + 0.45, winEndSec + 0.35))
                    val retryWords = alignTokensInWindow(
                        tokens = rawMainTokens,
                        vocalMono16k = preferredMainStem,
                        originalMono16k = originalMono16k,
                        winStartSec = widerStart,
                        winEndSec = widerEnd,
                        anchorBeginSec = widerAnchorBegin,
                        anchorEndSec = naturalEnd,
                        hardMaxEndSec = max(verifiedNextVocalBegin, widerEnd),
                        arSession = arSession,
                        arVocab = arVocab,
                        enSession = enSession,
                        enVocab = enVocab,
                        config = config,
                        blendOriginalMixRatio = if (hasWeakWord) 0.25f else 0.10f,
                        suppressBackingMono16k = suppressBleedStem
                    )
                    val retryMeanConf = retryWords.mapNotNull { it.confidence }.average().toFloat()
                    if (isLeftEdgeClipped || retryMeanConf > initialMeanConf + 0.02f) {
                        alignedMainWords = retryWords
                    }
                }
            }

            val alignedBgWords = if (!line.backgroundText.isNullOrBlank()) {
                val bgTokens = tokenizePreservingOrthography(line.backgroundText)
                if (bgTokens.isNotEmpty()) {
                    alignBackgroundOrDoubledVocal(
                        bgTokens = bgTokens,
                        alignedMainWords = alignedMainWords,
                        lineBoundsBegin = bounds.begin,
                        naturalEnd = naturalEnd,
                        nextSameAgentBegin = verifiedNextVocalBegin,
                        songDurationSeconds = songDurationSeconds,
                        vocalMono16k = vocalMono16k,
                        backingVocalMono16k = backingVocalMono16k,
                        originalMono16k = originalMono16k,
                        leadBackingSeparationConfidence = leadBackingSeparationConfidence,
                        arSession = arSession,
                        arVocab = arVocab,
                        enSession = enSession,
                        enVocab = enVocab,
                        config = config
                    )
                } else null
            } else line.backgroundWords

            result.add(
                line.copy(
                    words = alignedMainWords.takeIf { it.isNotEmpty() },
                    backgroundWords = alignedBgWords?.takeIf { it.isNotEmpty() }
                ).reconcile()
            )
            // Yield 10ms between lines so Android UI and HyperOS watchdog stay completely smooth
            kotlinx.coroutines.delay(10)
        }

        val repairStem = leadVocalMono16k ?: vocalMono16k

        // Post pass 1: a first word must not swallow an instrumental gap (trim the silent lead-in).
        for (idx in result.indices) {
            val trimmedWords = trimSilentLeadIn(repairStem, result[idx].words)
            if (trimmedWords != null) {
                result[idx] = result[idx].copy(words = trimmedWords).reconcile()
            }
        }

        // Post pass 2: lines that were squeezed into a too short LRC slot while the singer keeps singing.
        repairUnassignedVocalGaps(
            result = result,
            stemMono16k = repairStem,
            originalMono16k = originalMono16k,
            songDurationSeconds = songDurationSeconds,
            arSession = arSession,
            arVocab = arVocab,
            enSession = enSession,
            enVocab = enVocab,
            config = config
        )

        // Post pass 3: align every line again together with its previous and next line, so a held word or an
        // early next line is explained by its own text instead of being forced into the wrong line.
        if (config.enableNeighborContextAlignment) {
            refineWithNeighborContext(
                result = result,
                stemMono16k = repairStem,
                originalMono16k = originalMono16k,
                songDurationSeconds = songDurationSeconds,
                arSession = arSession,
                arVocab = arVocab,
                enSession = enSession,
                enVocab = enVocab,
                config = config,
                onProgress = onProgress
            )
        }

        // Post pass 4: last safety net for the "first words crushed, last word absorbs the line" pattern.
        for (idx in result.indices) {
            val fixedWords = redistributeCrushedWords(result[idx].words)
            if (fixedWords != null) {
                result[idx] = result[idx].copy(words = fixedWords).reconcile()
            }
        }

        return if (config.enableCrossLineCoupledAlignment && result.size >= 2) {
            val (reconciled, diagnostics) = reconcileCrossLineTransitionsAndBuildDiagnostics(
                initialAlignedLines = result,
                originalInputLines = lines,
                vocalMono16k = leadVocalMono16k ?: vocalMono16k,
                originalMono16k = originalMono16k,
                songDurationSeconds = songDurationSeconds,
                config = config
            )
            lastTransitionDiagnostics = diagnostics
            reconciled
        } else {
            lastTransitionDiagnostics = emptyList()
            result
        }
    }

    /**
     * Accuracy fix 5 (first word swallows an instrumental gap).
     *
     * When the first word of a line lasts >= 1.2 s but starts with >= 0.6 s of true silence on the vocal stem
     * (RMS below 4% of the word's own 95th-percentile RMS, i.e. about -28 dB), its begin is moved to the end of that
     * silence. Soft but real singing is never that quiet relative to the same word's peak, so it is left alone.
     * Returns null when nothing has to change.
     */
    private fun trimSilentLeadIn(stem: FloatArray, words: List<WordTiming>?): List<WordTiming>? {
        if (words.isNullOrEmpty() || stem.isEmpty()) return null
        val first = words.first()
        if (first.end - first.begin < 1.2) return null
        val frame = 320 // 20 ms @ 16 kHz
        val f0 = ((first.begin * CTC_SAMPLE_RATE) / frame).toInt().coerceAtLeast(0)
        val f1 = ((first.end * CTC_SAMPLE_RATE) / frame).toInt().coerceAtMost(stem.size / frame - 1)
        if (f1 <= f0 + 10) return null
        val rms = DoubleArray(f1 - f0 + 1)
        for (idx in rms.indices) {
            val base = (f0 + idx) * frame
            var acc = 0.0
            for (k in 0 until frame) {
                val v = stem[base + k].toDouble()
                acc += v * v
            }
            rms[idx] = sqrt(acc / frame)
        }
        val sorted = rms.sortedArray()
        val p95 = sorted[((sorted.size - 1) * 0.95).toInt()]
        val silentThreshold = max(0.0015, p95 * 0.04)
        var run = 0
        while (run < rms.size && rms[run] < silentThreshold) run++
        val silentSec = run.toDouble() * frame / CTC_SAMPLE_RATE.toDouble()
        if (silentSec < 0.6) return null
        val newBegin = first.begin + silentSec - 0.04
        if (newBegin > first.end - 0.25) return null
        return listOf(first.copy(begin = newBegin)) + words.drop(1)
    }

    /**
     * Accuracy fix 6 (neighbour-context alignment).
     *
     * A line aligned in isolation has to explain EVERY frame of its window with its own words. When the previous
     * line's last word is still held, when the next line starts early, or when an LRC stamp is several seconds off,
     * those frames are forced onto the wrong words. Here the line is aligned again in one CTC window together with the
     * previous and next line of the same singer (falling back to a pair when the triple would be longer than 22 s):
     * the neighbours' text takes the frames that belong to them and only the middle line's words are kept.
     *
     * The new timing replaces the old one when its CTC confidence is not worse (suspicious lines) or clearly better
     * (lines that already looked fine); changes below 40 ms are ignored as noise.
     */
    private suspend fun refineWithNeighborContext(
        result: MutableList<LyricLine>,
        stemMono16k: FloatArray,
        originalMono16k: FloatArray?,
        songDurationSeconds: Double,
        arSession: OrtSession?,
        arVocab: CtcVocab,
        enSession: OrtSession?,
        enVocab: CtcVocab,
        config: ForcedAlignmentConfig,
        onProgress: suspend (String, Float) -> Unit
    ) {
        if (stemMono16k.isEmpty() || result.size < 2) return
        val noSplitConfig = config.copy(enableSyllableSplitting = false)
        val maxContextSec = 22.0

        for (i in result.indices) {
            coroutineContext.ensureActive()
            val cur = result[i]
            if (cur.agentId != "v1" || !cur.backgroundText.isNullOrBlank()) continue
            val curWords = cur.words
            if (curWords.isNullOrEmpty()) continue

            val prev = result.getOrNull(i - 1)?.takeIf {
                it.agentId == cur.agentId && it.backgroundText.isNullOrBlank() && !it.words.isNullOrEmpty()
            }
            val next = result.getOrNull(i + 1)?.takeIf {
                it.agentId == cur.agentId && it.backgroundText.isNullOrBlank() && !it.words.isNullOrEmpty()
            }
            if (prev == null && next == null) continue

            val choices = ArrayList<List<LyricLine>>(3)
            if (prev != null && next != null) choices.add(listOf(prev, cur, next))
            if (next != null) choices.add(listOf(cur, next))
            if (prev != null) choices.add(listOf(prev, cur))

            var context: List<LyricLine>? = null
            var winStartSec = 0.0
            var winEndSec = 0.0
            for (choice in choices) {
                val s = max(0.0, choice.first().words.orEmpty().first().begin - 0.6)
                val e = min(songDurationSeconds, choice.last().words.orEmpty().last().end + 1.2)
                if (e - s <= maxContextSec && e > s + 0.5) {
                    context = choice
                    winStartSec = s
                    winEndSec = e
                    break
                }
            }
            if (context == null) continue

            val tokenLists = context.map { tokenizePreservingOrthography(it.text) }
            if (tokenLists.any { it.isEmpty() }) continue
            val allTokens = tokenLists.flatten()
            if (allTokens.size < 2) continue
            val needsAr = allTokens.any { it.script == WordScript.ARABIC }
            val needsEn = allTokens.any { it.script == WordScript.LATIN_ENGLISH }
            if ((needsAr && arSession == null) || (needsEn && enSession == null)) continue

            onProgress(
                "Neighbour-context refinement, line ${i + 1}/${result.size}…",
                0.90f + 0.02f * (i.toFloat() / result.size.toFloat())
            )

            val joint = alignTokensInWindow(
                tokens = allTokens,
                vocalMono16k = stemMono16k,
                originalMono16k = originalMono16k,
                winStartSec = winStartSec,
                winEndSec = winEndSec,
                anchorBeginSec = context.first().words.orEmpty().first().begin,
                anchorEndSec = context.last().words.orEmpty().last().end,
                hardMaxEndSec = winEndSec,
                arSession = arSession,
                arVocab = arVocab,
                enSession = enSession,
                enVocab = enVocab,
                config = noSplitConfig,
                maxPhraseSec = (winEndSec - winStartSec) + 1.0
            )
            if (joint.size != allTokens.size) continue

            val curPos = context.indexOfFirst { it === cur }
            if (curPos < 0) continue
            val offset = tokenLists.take(curPos).sumOf { it.size }
            val curTokens = tokenLists[curPos]
            val sliced = WordSpacesAndSyllables.trimTrailingSpaceFromLast(
                joint.subList(offset, offset + curTokens.size)
            )
            if (sliced.size != curTokens.size) continue

            val oldScore = curWords.map { (it.confidence ?: 0.5f).toDouble() }.average()
            val newScore = sliced.map { (it.confidence ?: 0.5f).toDouble() }.average()
            val longestWord = sliced.maxOf { it.end - it.begin }
            val plausible = longestWord <= config.maxSustainedWordExtensionSec + 0.60 &&
                sliced.first().begin >= winStartSec && sliced.last().end <= winEndSec + 0.01

            val oldDurations = curWords.map { it.end - it.begin }
            val oldSpan = curWords.last().end - curWords.first().begin
            val suspicious = (oldDurations.maxOrNull() ?: 0.0) >= config.maxSustainedWordExtensionSec - 0.30 ||
                (oldDurations.firstOrNull() ?: 0.0) >= 2.0 ||
                oldScore < 0.55 ||
                (next != null && next.words.orEmpty().first().begin - curWords.last().end >= 1.0) ||
                (curWords.size >= 3 && oldSpan > 0.0 && oldDurations.last() >= 0.55 * oldSpan)

            val accept = plausible && if (suspicious) newScore >= oldScore - 0.03 else newScore >= oldScore + 0.02
            if (!accept) continue

            if (curWords.size == sliced.size) {
                var maxDelta = 0.0
                for (k in sliced.indices) {
                    maxDelta = max(maxDelta, abs(sliced[k].begin - curWords[k].begin))
                    maxDelta = max(maxDelta, abs(sliced[k].end - curWords[k].end))
                }
                if (maxDelta < 0.04) continue
            }

            val finalWords = if (config.enableSyllableSplitting) {
                val out = ArrayList<WordTiming>(sliced.size * 2)
                for (k in sliced.indices) {
                    val w = sliced[k]
                    val splits = if (w.end - w.begin >= config.minSyllableSplitDurationSec) {
                        BilingualSyllabifier.findSyllableSplitPoints(curTokens[k].displaySurface)
                    } else emptyList()
                    if (splits.isNotEmpty()) out.addAll(WordSpacesAndSyllables.splitWordIntoSyllables(w, splits)) else out.add(w)
                }
                out
            } else sliced

            result[i] = cur.copy(words = finalWords).reconcile()
        }
    }

    /** Number of letters in a word (diacritics, punctuation and spaces ignored); at least 1. */
    private fun letterWeight(text: String): Int {
        var n = 0
        for (ch in text) {
            if (ch.isLetterOrDigit() && ch !in '\u064B'..'\u065F') n++
        }
        return n.coerceAtLeast(1)
    }

    /**
     * Accuracy fix 4 ("crushed line" guard).
     *
     * On sung refrains such as "بناديك تعالى، بناديك تعالى" the CTC path packs the first words of a line into a few
     * hundred milliseconds and lets the LAST word absorb the rest of the line (benchmark: lines 15, 16, 17, 21: first
     * three words ~0.7 s, last word ~2.6 s, while the hand-timed words are all about 1 s). That shape is implausible
     * for sung text, so for exactly that pattern the words are laid out proportionally to their letter count over the
     * line's existing span. First begin and last end are kept. Lines that do not show the pattern are not touched.
     * Returns null when nothing has to change.
     */
    private fun redistributeCrushedWords(words: List<WordTiming>?): List<WordTiming>? {
        if (words == null || words.size < 3) return null
        if (words.any { it.syllableGroupId != null }) return null
        val n = words.size
        val spanBegin = words.first().begin
        val spanEnd = words.last().end
        val span = spanEnd - spanBegin
        if (span < 1.2) return null

        val weights = IntArray(n) { letterWeight(words[it].text) }
        val totalWeight = weights.sum().toDouble()
        val ratios = DoubleArray(n) { i ->
            (words[i].end - words[i].begin) / (span * weights[i].toDouble() / totalWeight)
        }
        var otherSum = 0.0
        for (i in 0 until n - 1) otherSum += ratios[i]
        val otherMean = otherSum / (n - 1).toDouble()
        if (ratios[n - 1] < 3.0 || otherMean >= 0.5) return null

        val begins = DoubleArray(n)
        var cumulative = 0.0
        for (i in 0 until n) {
            begins[i] = spanBegin + span * cumulative / totalWeight
            cumulative += weights[i].toDouble()
        }
        return List(n) { i ->
            val w = words[i]
            val newEnd = if (i < n - 1) begins[i + 1] else spanEnd
            w.copy(
                begin = begins[i],
                end = newEnd,
                confidence = min(w.confidence ?: 0.45f, 0.45f),
                needsReview = true
            )
        }
    }

    /**
     * Fraction of 20 ms frames in `[gapStartSec, gapEndSec]` whose RMS on [stem] is at least 10% of the
     * 95th-percentile RMS seen in `[refStartSec, gapEndSec]` (and above a small absolute floor).
     * Used to tell "the singer is still singing" from "instrumental break".
     */
    private fun vocalActivityFraction(
        stem: FloatArray,
        refStartSec: Double,
        gapStartSec: Double,
        gapEndSec: Double
    ): Double {
        val frame = 320 // 20 ms @ 16 kHz
        val firstFrame = ((refStartSec * CTC_SAMPLE_RATE) / frame).toInt().coerceAtLeast(0)
        val lastFrame = ((gapEndSec * CTC_SAMPLE_RATE) / frame).toInt().coerceAtMost(stem.size / frame - 1)
        if (lastFrame <= firstFrame + 2) return 0.0
        val rms = DoubleArray(lastFrame - firstFrame + 1)
        for (idx in rms.indices) {
            val base = (firstFrame + idx) * frame
            var acc = 0.0
            for (k in 0 until frame) {
                val v = stem[base + k].toDouble()
                acc += v * v
            }
            rms[idx] = sqrt(acc / frame)
        }
        val sorted = rms.sortedArray()
        val p95 = sorted[((sorted.size - 1) * 0.95).toInt()]
        val threshold = max(0.003, p95 * 0.10)
        val gapFirst = (((gapStartSec * CTC_SAMPLE_RATE) / frame).toInt() - firstFrame).coerceIn(0, rms.size - 1)
        val gapLast = (((gapEndSec * CTC_SAMPLE_RATE) / frame).toInt() - firstFrame).coerceIn(gapFirst, rms.size - 1)
        var active = 0
        for (idx in gapFirst..gapLast) {
            if (rms[idx] >= threshold) active++
        }
        return active.toDouble() / (gapLast - gapFirst + 1).toDouble()
    }

    /**
     * Accuracy fix 3 (unassigned vocal gap repair).
     *
     * LRC stamps are often several seconds too early for the NEXT line (a long line gets a short slot), and the
     * per-line window then forces all words of the current line into the short slot. Symptom after the first pass:
     * there is a gap >= 1.5 s between the last word of line i and the first word of line i + 1 although the vocal
     * stem is still clearly active in that gap. The next line's first word onset is reliable (it comes from CTC),
     * so line i is aligned again with its window extended up to that onset. The new result is only kept when it
     * actually uses the gap, has plausible word lengths and a CTC confidence that is not worse than before.
     */
    private suspend fun repairUnassignedVocalGaps(
        result: MutableList<LyricLine>,
        stemMono16k: FloatArray,
        originalMono16k: FloatArray?,
        songDurationSeconds: Double,
        arSession: OrtSession?,
        arVocab: CtcVocab,
        enSession: OrtSession?,
        enVocab: CtcVocab,
        config: ForcedAlignmentConfig
    ) {
        if (stemMono16k.isEmpty() || result.size < 2) return
        val noSplitConfig = config.copy(enableSyllableSplitting = false)

        for (i in 0 until result.size - 1) {
            coroutineContext.ensureActive()
            val cur = result[i]
            val next = result[i + 1]
            if (cur.agentId != next.agentId) continue
            if (!cur.backgroundText.isNullOrBlank()) continue
            val curWords = cur.words
            val nextWords = next.words
            if (curWords.isNullOrEmpty() || nextWords.isNullOrEmpty()) continue

            val tokens = tokenizePreservingOrthography(cur.text)
            if (tokens.size < 2 || tokens.size != curWords.size) continue
            val needsAr = tokens.any { it.script == WordScript.ARABIC }
            val needsEn = tokens.any { it.script == WordScript.LATIN_ENGLISH }
            if ((needsAr && arSession == null) || (needsEn && enSession == null)) continue

            val lastWord = curWords.last()
            val gapStartSec = lastWord.end
            val gapEndSec = nextWords.first().begin
            if (gapEndSec - gapStartSec < 1.5) continue

            val activity = vocalActivityFraction(
                stem = stemMono16k,
                refStartSec = curWords.first().begin,
                gapStartSec = gapStartSec,
                gapEndSec = gapEndSec
            )
            if (activity < 0.70) continue

            val prevEndSec = (i - 1 downTo 0).firstNotNullOfOrNull { idx ->
                result[idx].takeIf { it.agentId == cur.agentId }?.words?.lastOrNull()?.end
            } ?: 0.0
            val winStartSec = max(prevEndSec, max(0.0, curWords.first().begin - 0.75))
            val hardMaxSec = (gapEndSec - 0.02).coerceAtMost(songDurationSeconds)
            val winEndSec = min(songDurationSeconds, hardMaxSec + 0.35)
            if (winEndSec - winStartSec > 22.0 || hardMaxSec <= winStartSec + 0.50) continue

            val retry = alignTokensInWindow(
                tokens = tokens,
                vocalMono16k = stemMono16k,
                originalMono16k = originalMono16k,
                winStartSec = winStartSec,
                winEndSec = winEndSec,
                anchorBeginSec = curWords.first().begin,
                anchorEndSec = hardMaxSec,
                hardMaxEndSec = hardMaxSec,
                arSession = arSession,
                arVocab = arVocab,
                enSession = enSession,
                enVocab = enVocab,
                config = noSplitConfig,
                maxPhraseSec = (winEndSec - winStartSec) + 1.0
            )
            if (retry.size != tokens.size) continue

            val oldScore = curWords.map { (it.confidence ?: 0.5f).toDouble() }.average()
            val newScore = retry.map { (it.confidence ?: 0.5f).toDouble() }.average()
            val usesGap = retry.last().end >= lastWord.end + 0.80
            val longestWord = retry.maxOf { it.end - it.begin }
            val avgWord = (retry.last().end - retry.first().begin) / tokens.size.toDouble()
            val plausible = longestWord <= config.maxSustainedWordExtensionSec + 0.60 && avgWord <= 2.0
            if (usesGap && plausible && newScore >= oldScore - 0.02) {
                result[i] = cur.copy(words = retry).reconcile()
                noteAlignmentWarning(
                    "Line ${i + 1}: re-aligned across a ${"%.1f".format(gapEndSec - gapStartSec)} s unassigned vocal gap " +
                        "(confidence ${"%.2f".format(oldScore)} -> ${"%.2f".format(newScore)})."
                )
            }
        }
    }

    /**
     * Aligns background vocals (`ttm:role="x-bg"`) or delayed vocal doubles by comparing:
     *   - Candidate 1 (Delayed Echo / Call-and-Response Window): starting near the midpoint/tail of the lead phrase
     *   - Candidate 2 (Simultaneous Unison / Harmony Window): spanning the full phrase window on the isolated backing stem
     * If `leadBackingSeparationConfidence < 0.22f`, flags backing words with `needsReview = true` rather than
     * presenting inseparable choir estimates as high-confidence measurements.
     */
    /**
     * Inspects the vocal stem around `nominalNextLineBeginSec` so an imperfect or early LRC timestamp
     * on line `i + 1` does not automatically truncate a sustained vowel at the end of line `i`.
     * Searches up to `min(songDurationSeconds, nominalNextLineBeginSec + 0.85)` to find the true
     * inter-line breath dip or consonant attack of the next phrase.
     */
    internal fun findVerifiedNextLineVocalCeiling(
        stemMono16k: FloatArray,
        currentLineBeginSec: Double,
        nominalNextLineBeginSec: Double,
        songDurationSeconds: Double,
        maxExtensionSec: Double
    ): Double {
        if (nominalNextLineBeginSec >= songDurationSeconds - 0.05 || stemMono16k.isEmpty()) return songDurationSeconds
        val winHop = 160 // 10ms @ 16kHz
        val totalFrames = (stemMono16k.size / winHop).coerceAtLeast(1)
        val searchStartSec = max(currentLineBeginSec + 0.25, nominalNextLineBeginSec - 0.15)
        val searchEndSec = min(songDurationSeconds, nominalNextLineBeginSec + maxExtensionSec.coerceIn(0.85, 2.40))
        if (searchEndSec <= searchStartSec + 0.05) return nominalNextLineBeginSec

        val startFrame = ((searchStartSec * CTC_SAMPLE_RATE) / winHop).toInt().coerceIn(0, totalFrames - 1)
        val nominalFrame = ((nominalNextLineBeginSec * CTC_SAMPLE_RATE) / winHop).toInt().coerceIn(startFrame, totalFrames - 1)
        val endFrame = ((searchEndSec * CTC_SAMPLE_RATE) / winHop).toInt().coerceIn(nominalFrame, totalFrames - 1)
        if (endFrame <= startFrame + 3) return nominalNextLineBeginSec

        // Measure peak vocal RMS across the current line core [currentLineBeginSec .. nominalNextLineBeginSec]
        val coreStartFrame = ((currentLineBeginSec * CTC_SAMPLE_RATE) / winHop).toInt().coerceIn(0, startFrame)
        var linePeakRms = 0.01
        for (f in coreStartFrame..nominalFrame) {
            val base = f * winHop
            var acc = 0.0
            for (k in 0 until winHop) {
                val s = stemMono16k.getOrElse(base + k) { 0f }.toDouble()
                acc += s * s
            }
            val r = sqrt(acc / winHop)
            if (r > linePeakRms) linePeakRms = r
        }

        val numSearch = endFrame - startFrame + 1
        val rmsArr = DoubleArray(numSearch)
        val hfFluxArr = DoubleArray(numSearch)
        for (idx in 0 until numSearch) {
            val f = startFrame + idx
            val base = f * winHop
            var acc = 0.0
            var diffAcc = 0.0
            for (k in 0 until winHop) {
                val s = stemMono16k.getOrElse(base + k) { 0f }.toDouble()
                val prevS = stemMono16k.getOrElse(base + k - 1) { 0f }.toDouble()
                acc += s * s
                val d = s - prevS
                diffAcc += d * d
            }
            rmsArr[idx] = sqrt(acc / winHop)
            hfFluxArr[idx] = sqrt(diffAcc / winHop)
        }

        val nominalIdx = (nominalFrame - startFrame).coerceIn(0, numSearch - 1)
        val rmsAtNominal = rmsArr[nominalIdx]
        val isCarriedAcrossNominal = rmsAtNominal >= linePeakRms * 0.20

        if (isCarriedAcrossNominal) {
            // The singer is still holding the current line's final word across `nominalNextLineBeginSec`!
            // Follow the sustained note until EITHER:
            //   (a) a genuine breath/release dip (< 18% of linePeakRms for >= 3 frames), OR
            //   (b) a clear consonant re-articulation spike (hfFlux jump + amplitude step) after at least +80ms.
            val sustainFloor = max(0.004, linePeakRms * 0.18)
            var dipStartIdx = -1
            var consecBelow = 0
            for (idx in nominalIdx until numSearch) {
                if (rmsArr[idx] < sustainFloor) {
                    if (consecBelow == 0) dipStartIdx = idx
                    consecBelow++
                    if (consecBelow >= 3) break
                } else {
                    consecBelow = 0
                    if (idx > nominalIdx + 10 && idx + 1 < numSearch) {
                        val prevR = rmsArr[idx - 1]
                        val curR = rmsArr[idx]
                        val curHf = hfFluxArr[idx]
                        val prevHf = hfFluxArr[idx - 1].coerceAtLeast(1e-4)
                        if (curHf >= prevHf * 2.2 && curHf >= linePeakRms * 0.35 && curR >= prevR * 1.35) {
                            val attackSec = ((startFrame + idx) * winHop).toDouble() / CTC_SAMPLE_RATE.toDouble()
                            return attackSec.coerceIn(nominalNextLineBeginSec, songDurationSeconds)
                        }
                    }
                }
            }
            if (dipStartIdx >= 0) {
                var minDipRms = rmsArr[dipStartIdx]
                var attackIdx = (dipStartIdx + consecBelow).coerceAtMost(numSearch - 1)
                for (idx in dipStartIdx until numSearch) {
                    if (rmsArr[idx] < minDipRms) minDipRms = rmsArr[idx]
                    if (idx > dipStartIdx + 1 && rmsArr[idx] >= max(0.006, max(minDipRms * 2.0, linePeakRms * 0.16))) {
                        attackIdx = idx
                        break
                    }
                    attackIdx = idx
                }
                val ceilingSec = ((startFrame + attackIdx) * winHop).toDouble() / CTC_SAMPLE_RATE.toDouble()
                return max(nominalNextLineBeginSec, ceilingSec).coerceIn(currentLineBeginSec + 0.35, songDurationSeconds)
            }
            return searchEndSec.coerceIn(nominalNextLineBeginSec, songDurationSeconds)
        }

        // Standard case: find the local minimum around nominalNextLineBeginSec and the subsequent attack
        var minRms = Double.MAX_VALUE
        var minIdx = 0
        for (idx in 0 until numSearch) {
            if (rmsArr[idx] < minRms) {
                minRms = rmsArr[idx]
                minIdx = idx
            }
        }
        var nextOnsetIdx = minIdx
        val attackFloor = max(0.006, minRms * 2.0)
        for (idx in minIdx until numSearch) {
            if (rmsArr[idx] >= attackFloor) {
                nextOnsetIdx = idx
                break
            }
        }
        val detectedSec = ((startFrame + nextOnsetIdx) * winHop).toDouble() / CTC_SAMPLE_RATE.toDouble()
        return max(nominalNextLineBeginSec, detectedSec).coerceIn(currentLineBeginSec + 0.35, songDurationSeconds)
    }

    /**
     * Part B (Requirements 6, 7, 8, 9): Cross-Line Coupled Transition Reconciler & Diagnostic Generator.
     * Inspects every transition `(line[i] -> line[i+1])` using shared acoustic context across the line boundary:
     *   1. Allows `line[i]`'s final word to continue past `line[i+1]`'s nominal LRC timestamp when the singer
     *      carries the note across the line break (`Failure A` fix).
     *   2. Aligns `line[i+1]`'s first word to its genuine consonant/vowel onset rather than absorbing `line[i]`'s
     *      carried vowel or being clipped by an inaccurate LRC timestamp (`Failure B` fix).
     *   3. Preserves independent overlapping intervals when `line[i]` and `line[i+1]` belong to different singers (`v1` vs `v2`).
     *   4. Produces a structured `LineTransitionDiagnostic` entry for every transition.
     */
    internal fun reconcileCrossLineTransitionsAndBuildDiagnostics(
        initialAlignedLines: List<LyricLine>,
        originalInputLines: List<LyricLine>,
        vocalMono16k: FloatArray,
        originalMono16k: FloatArray? = null,
        songDurationSeconds: Double,
        config: ForcedAlignmentConfig = ForcedAlignmentConfig()
    ): Pair<List<LyricLine>, List<LineTransitionDiagnostic>> {
        if (initialAlignedLines.size < 2) return initialAlignedLines to emptyList()
        val mutableLines = initialAlignedLines.toMutableList()
        val diagnostics = ArrayList<LineTransitionDiagnostic>(initialAlignedLines.size - 1)
        val frameDurSec = FRAME_HOP_SAMPLES.toDouble() / CTC_SAMPLE_RATE.toDouble() // 10.0ms

        for (i in 0 until mutableLines.size - 1) {
            val prevLine = mutableLines[i]
            val nextLine = mutableLines[i + 1]
            val prevWords = prevLine.words?.toMutableList()
            val nextWords = nextLine.words?.toMutableList()
            if (prevWords.isNullOrEmpty() || nextWords.isNullOrEmpty()) continue

            val prevLastIdx = prevWords.lastIndex
            val prevLastWord = prevWords[prevLastIdx]
            val nextFirstWord = nextWords[0]

            val nominalNextLrcSec = originalInputLines.getOrNull(i + 1)?.effectiveBounds()?.begin
                ?: nextFirstWord.begin
            val initialPrevEnd = prevLastWord.end
            val initialNextBegin = nextFirstWord.begin

            val searchWinStart = max(0.0, min(prevLastWord.begin, nominalNextLrcSec - 0.60) - 0.10)
            val maxLookahead = if (nextWords.size >= 2) {
                max(nextWords[1].end + 0.20, nominalNextLrcSec + 1.80)
            } else {
                max(nextFirstWord.end + 0.35, nominalNextLrcSec + 1.80)
            }
            val searchWinEnd = min(songDurationSeconds, maxLookahead).coerceAtLeast(searchWinStart + 0.40)

            // Different singers (e.g., v1 lead and v2 duet): keep timelines independent and allow true vocal overlap!
            if (prevLine.agentId != nextLine.agentId) {
                diagnostics.add(
                    LineTransitionDiagnostic(
                        transitionIndex = i,
                        fromLineId = prevLine.id,
                        toLineId = nextLine.id,
                        agentId = prevLine.agentId,
                        nextAgentId = nextLine.agentId,
                        prevWordText = prevLastWord.text.trim(),
                        prevWordInitialEndSec = initialPrevEnd,
                        prevWordRefinedEndSec = prevLastWord.end,
                        nextLineNominalLrcSec = nominalNextLrcSec,
                        nextWordText = nextFirstWord.text.trim(),
                        nextWordInitialBeginSec = initialNextBegin,
                        nextWordRefinedBeginSec = nextFirstWord.begin,
                        nextWordRefinedEndSec = nextFirstWord.end,
                        searchWindowBeginSec = searchWinStart,
                        searchWindowEndSec = searchWinEnd,
                        appliedConstraint = "INDEPENDENT_MULTI_AGENT_OVERLAP",
                        carriedAcrossLineBreak = prevLastWord.end > nextFirstWord.begin + 0.02,
                        leftEdgeClippedAndRealigned = false,
                        transitionConfidence = min(prevLastWord.confidence ?: 0.88f, nextFirstWord.confidence ?: 0.88f)
                    )
                )
                continue
            }

            // Same singer transition (`v1 -> v1` or `v2 -> v2`):
            val startSample = (searchWinStart * CTC_SAMPLE_RATE).roundToInt().coerceIn(0, vocalMono16k.size)
            val endSample = (searchWinEnd * CTC_SAMPLE_RATE).roundToInt().coerceIn(startSample, vocalMono16k.size)
            if (endSample - startSample < FFT_SIZE + FRAME_HOP_SAMPLES * 6) {
                continue
            }
            val vocalSlice = vocalMono16k.copyOfRange(startSample, endSample)
            val origSlice = if (originalMono16k != null && endSample <= originalMono16k.size) {
                originalMono16k.copyOfRange(startSample, endSample)
            } else null

            val features = extract10msSpectralFeatures(vocalSlice, origSlice)
            val nFrames = features.numFrames
            if (nFrames < 8) continue

            fun secToLocalFrame(sec: Double): Int =
                (((sec - searchWinStart) / frameDurSec).roundToInt()).coerceIn(0, nFrames - 1)
            fun localFrameToSec(f: Int): Double =
                (searchWinStart + f * frameDurSec).coerceIn(0.0, songDurationSeconds)

            val prevStartF = secToLocalFrame(prevLastWord.begin + 0.08)
            val prevInitEndF = secToLocalFrame(prevLastWord.end)
            val nextSecondStartSec = nextWords.getOrNull(1)?.begin ?: nextFirstWord.end
            val maxTransitionF = secToLocalFrame(max(nextSecondStartSec - 0.08, prevLastWord.end + 0.25))
                .coerceAtLeast(prevStartF + 4)

            var prevPeakV = 0.18f
            var prevPeakF = 0.18f
            for (f in prevStartF..min(nFrames - 1, max(prevInitEndF, prevStartF + 8))) {
                if (features.voicingScore[f] > prevPeakV) prevPeakV = features.voicingScore[f]
                if (features.formantScore[f] > prevPeakF) prevPeakF = features.formantScore[f]
            }

            val vFloor = max(0.12f, prevPeakV * 0.16f)
            val fFloor = max(0.13f, prevPeakF * 0.17f)

            var truePrevEndF = prevInitEndF
            var dipStartF = -1
            var silentRun = 0
            var rearticulationF = -1

            for (f in prevStartF..maxTransitionF) {
                val v = features.voicingScore[f]
                val fm = features.formantScore[f]
                val s = features.fricativeScore[f]
                val o = features.onsetFluxScore[f]
                val cj = features.spectralCentroidJump[f]
                val vNext2 = features.voicingScore[min(nFrames - 1, f + 2)]
                val vPrev2 = features.voicingScore[max(0, f - 2)]

                val nominalNextF = secToLocalFrame(nominalNextLrcSec)
                if (silentRun == 0 && f >= max(prevStartF + 12, nominalNextF - 15) &&
                    o >= 0.58f && (cj >= 0.42f || s >= 0.48f) &&
                    vNext2 >= 0.35f && vNext2 >= vPrev2 * 1.15f
                ) {
                    rearticulationF = f
                    break
                }

                val isActive = v >= vFloor || fm >= fFloor || (silentRun == 0 && v >= 0.08f && s >= 0.22f)
                if (isActive) {
                    silentRun = 0
                    dipStartF = -1
                    truePrevEndF = f
                } else {
                    if (silentRun == 0) dipStartF = f
                    silentRun++
                    if (silentRun >= 2) break
                }
            }

            var refinedPrevEndSec = (localFrameToSec(truePrevEndF) + frameDurSec)
                .coerceIn(prevLastWord.begin + 0.10, songDurationSeconds)

            val nextSearchStartF = when {
                rearticulationF >= 0 -> rearticulationF.coerceAtLeast(truePrevEndF)
                dipStartF >= 0 -> dipStartF
                else -> (truePrevEndF + 1).coerceAtMost(nFrames - 1)
            }
            val nextSearchEndF = min(nFrames - 1, max(secToLocalFrame(nextFirstWord.end) + 10, nextSearchStartF + 60))

            var scanStartF = nextSearchStartF
            while (scanStartF < nextSearchEndF && features.voicingScore[scanStartF] < 0.18f && features.formantScore[scanStartF] < 0.18f) {
                scanStartF++
            }

            var detectedNextStartF = scanStartF
            for (f in scanStartF..nextSearchEndF) {
                val v = features.voicingScore[f]
                val fm = features.formantScore[f]
                val s = features.fricativeScore[f]
                val o = features.onsetFluxScore[f]
                if (v >= 0.20f || fm >= 0.22f || (o >= 0.34f && (v >= 0.12f || s >= 0.32f))) {
                    detectedNextStartF = f
                    break
                }
            }

            val coarseNextBeginSec = localFrameToSec(detectedNextStartF)
            var refinedNextBeginSec = refine5msAttack(
                windowSamples = vocalSlice,
                origWindowSamples = origSlice,
                winStartSec = searchWinStart,
                coarseTimeSec = coarseNextBeginSec
            ).coerceIn(prevLastWord.begin + 0.12, songDurationSeconds - 0.08)

            if (refinedPrevEndSec > refinedNextBeginSec) {
                refinedPrevEndSec = (refinedNextBeginSec - 0.008).coerceAtLeast(prevLastWord.begin + 0.08)
            }

            // Accuracy fix 1: the CTC word end of the previous line is trustworthy; the stem-energy scan above
            // can run through instrument bleed or the next line's first words. Never let the "carried vowel"
            // extension grow the previous word by more than 0.60 s, nor beyond the CTC onset of the next line.
            val carryCeilingSec = min(prevLastWord.end + 0.60, max(prevLastWord.end, initialNextBegin - 0.010))
            if (refinedPrevEndSec > carryCeilingSec) {
                refinedPrevEndSec = carryCeilingSec.coerceAtLeast(prevLastWord.begin + 0.08)
            }

            val carriedAcrossBreak = refinedPrevEndSec > nominalNextLrcSec + 0.04
            val leftEdgeAdjusted = initialNextBegin > nominalNextLrcSec - 0.22 && refinedNextBeginSec < nominalNextLrcSec - 0.15

            // Accuracy fix 2: the energy scan starts at the previous line's end, so with instrumental gaps or bleed it
            // locks onto the end of the previous line instead of the real vocal onset (first word swallows the gap).
            // The CTC onset is accurate, so the scan may only move the first word EARLIER by 120 ms, unless the
            // LRC stamp clipped the left window edge (`leftEdgeAdjusted`).
            if (!leftEdgeAdjusted && refinedNextBeginSec < initialNextBegin - 0.12) {
                refinedNextBeginSec = initialNextBegin - 0.12
            }

            if (carriedAcrossBreak && refinedPrevEndSec > prevLastWord.end + 0.015) {
                prevWords[prevLastIdx] = prevLastWord.copy(end = refinedPrevEndSec)
                mutableLines[i] = prevLine.copy(words = prevWords).reconcile()
            }

            val finalPrevEnd = prevWords[prevLastIdx].end
            if (refinedNextBeginSec < finalPrevEnd) {
                // Real singing overlaps: the previous line's last word is often still held while the next line
                // starts (hand-timed references overlap by 0.07-0.41 s on ~40% of transitions). When the next onset
                // is the CTC onset and the overlap is short, keep that onset and trim the held word to it instead
                // of pushing the next line's first word late.
                val overlapSec = finalPrevEnd - refinedNextBeginSec
                if (overlapSec <= 0.45 && refinedNextBeginSec >= initialNextBegin - 0.02) {
                    val trimmedEnd = (refinedNextBeginSec - 0.010).coerceAtLeast(prevWords[prevLastIdx].begin + 0.08)
                    prevWords[prevLastIdx] = prevWords[prevLastIdx].copy(end = trimmedEnd)
                    mutableLines[i] = mutableLines[i].copy(words = prevWords).reconcile()
                } else {
                    refinedNextBeginSec = finalPrevEnd + 0.010
                }
            }

            if (carriedAcrossBreak || abs(refinedNextBeginSec - nextFirstWord.begin) >= 0.025) {
                val minFirstDur = 0.10
                val updatedFirstEnd = max(nextFirstWord.end, refinedNextBeginSec + minFirstDur)
                nextWords[0] = nextFirstWord.copy(begin = refinedNextBeginSec, end = updatedFirstEnd)
                if (nextWords.size >= 2 && nextWords[1].begin < updatedFirstEnd) {
                    val w1 = nextWords[1]
                    val pushedBegin = min(w1.end - 0.08, updatedFirstEnd)
                    nextWords[1] = w1.copy(begin = pushedBegin, end = max(pushedBegin + 0.08, w1.end))
                }
                mutableLines[i + 1] = nextLine.copy(words = nextWords).reconcile()
            }

            val appliedRule = when {
                carriedAcrossBreak -> "CROSS_LINE_VOWEL_CARRY_RECONCILED"
                leftEdgeAdjusted -> "LATE_LRC_LEFT_WINDOW_EXPANDED"
                else -> "ACOUSTIC_DIP_AND_CONSONANT_ATTACK"
            }

            val transConf = (0.5f * (prevWords[prevLastIdx].confidence ?: 0.85f) +
                0.5f * (nextWords[0].confidence ?: 0.85f)).coerceIn(0.15f, 0.99f)

            diagnostics.add(
                LineTransitionDiagnostic(
                    transitionIndex = i,
                    fromLineId = prevLine.id,
                    toLineId = nextLine.id,
                    agentId = prevLine.agentId,
                    nextAgentId = nextLine.agentId,
                    prevWordText = prevLastWord.text.trim(),
                    prevWordInitialEndSec = initialPrevEnd,
                    prevWordRefinedEndSec = prevWords[prevLastIdx].end,
                    nextLineNominalLrcSec = nominalNextLrcSec,
                    nextWordText = nextFirstWord.text.trim(),
                    nextWordInitialBeginSec = initialNextBegin,
                    nextWordRefinedBeginSec = nextWords[0].begin,
                    nextWordRefinedEndSec = nextWords[0].end,
                    searchWindowBeginSec = searchWinStart,
                    searchWindowEndSec = searchWinEnd,
                    appliedConstraint = appliedRule,
                    carriedAcrossLineBreak = carriedAcrossBreak,
                    leftEdgeClippedAndRealigned = leftEdgeAdjusted,
                    transitionConfidence = transConf
                )
            )
        }

        return mutableLines to diagnostics
    }

    private fun alignBackgroundOrDoubledVocal(
        bgTokens: List<OrthographicToken>,
        alignedMainWords: List<WordTiming>,
        lineBoundsBegin: Double,
        naturalEnd: Double,
        nextSameAgentBegin: Double,
        songDurationSeconds: Double,
        vocalMono16k: FloatArray,
        backingVocalMono16k: FloatArray?,
        originalMono16k: FloatArray?,
        leadBackingSeparationConfidence: Float,
        arSession: OrtSession?,
        arVocab: CtcVocab,
        enSession: OrtSession?,
        enVocab: CtcVocab,
        config: ForcedAlignmentConfig
    ): List<WordTiming> {
        val hasSeparatedBacking = backingVocalMono16k != null && leadBackingSeparationConfidence >= 0.22f
        val targetStem = if (hasSeparatedBacking) backingVocalMono16k!! else vocalMono16k

        val leadStart = alignedMainWords.firstOrNull()?.begin ?: lineBoundsBegin
        val leadEnd = alignedMainWords.lastOrNull()?.end ?: naturalEnd
        val leadMidpoint = (leadStart + 0.55 * (leadEnd - leadStart)).coerceAtLeast(leadStart + 0.25)
        val hardMaxEnd = min(songDurationSeconds, max(naturalEnd + 0.45, nextSameAgentBegin))

        // Measure backing stem RMS energy in the early half [leadStart..leadMidpoint] vs delayed tail [leadMidpoint..hardMaxEnd]
        fun windowRms(samples: FloatArray, sSec: Double, eSec: Double): Double {
            val i0 = (sSec * CTC_SAMPLE_RATE).roundToInt().coerceIn(0, samples.size)
            val i1 = (eSec * CTC_SAMPLE_RATE).roundToInt().coerceIn(i0, samples.size)
            if (i1 <= i0) return 0.0
            var acc = 0.0
            for (k in i0 until i1) {
                val v = samples[k].toDouble()
                acc += v * v
            }
            return sqrt(acc / (i1 - i0).toDouble())
        }

        val earlyRms = windowRms(targetStem, leadStart, leadMidpoint)
        val delayedRms = windowRms(targetStem, leadMidpoint, hardMaxEnd)
        val isLikelyDelayedEcho = delayedRms >= earlyRms * 0.82 || !hasSeparatedBacking

        val delayedAnchorStart = if (alignedMainWords.size >= 2) {
            alignedMainWords[alignedMainWords.size / 2].begin
        } else leadMidpoint
        val delayedAnchorEnd = max(leadEnd + 0.35, min(hardMaxEnd, nextSameAgentBegin)).coerceAtLeast(delayedAnchorStart + 0.40)

        val delayedCandidate = alignTokensInWindow(
            tokens = bgTokens,
            vocalMono16k = targetStem,
            originalMono16k = originalMono16k,
            winStartSec = max(0.0, delayedAnchorStart - 0.15),
            winEndSec = min(songDurationSeconds, delayedAnchorEnd + 0.30).coerceAtLeast(delayedAnchorStart + 0.35),
            anchorBeginSec = delayedAnchorStart,
            anchorEndSec = delayedAnchorEnd,
            hardMaxEndSec = hardMaxEnd,
            arSession = arSession,
            arVocab = arVocab,
            enSession = enSession,
            enVocab = enVocab,
            config = config
        )

        val chosenWords = if (hasSeparatedBacking && !isLikelyDelayedEcho) {
            val unisonCandidate = alignTokensInWindow(
                tokens = bgTokens,
                vocalMono16k = targetStem,
                originalMono16k = originalMono16k,
                winStartSec = max(0.0, leadStart - 0.15),
                winEndSec = min(songDurationSeconds, hardMaxEnd).coerceAtLeast(leadStart + 0.35),
                anchorBeginSec = leadStart,
                anchorEndSec = max(leadEnd, naturalEnd),
                hardMaxEndSec = hardMaxEnd,
                arSession = arSession,
                arVocab = arVocab,
                enSession = enSession,
                enVocab = enVocab,
                config = config
            )
            val uConf = unisonCandidate.mapNotNull { it.confidence }.average().toFloat()
            val dConf = delayedCandidate.mapNotNull { it.confidence }.average().toFloat()
            if (uConf >= dConf) unisonCandidate else delayedCandidate
        } else {
            delayedCandidate
        }

        // Phase 5 Safeguard: If lead and backing voices could not be separated confidently,
        // flag the backing words for manual review instead of claiming verified accuracy.
        return if (!hasSeparatedBacking) {
            chosenWords.map { w ->
                val cappedConf = min(w.confidence ?: 0.42f, 0.45f)
                w.copy(confidence = cappedConf, needsReview = true)
            }
        } else {
            chosenWords
        }
    }

    // --------------------------------------------------------------------------------------------
    // MODE B: Unanchored Full-Song Alignment (VAD Islands + Wide-Window Joint Decoder)
    // --------------------------------------------------------------------------------------------

    private data class VadSegment(val startSec: Double, val endSec: Double)

    private suspend fun alignUnanchoredFullSong(
        lines: List<LyricLine>,
        vocalMono16k: FloatArray,
        originalMono16k: FloatArray?,
        leadVocalMono16k: FloatArray?,
        backingVocalMono16k: FloatArray?,
        leadBackingSeparationConfidence: Float,
        songDurationSeconds: Double,
        arSession: OrtSession?,
        arVocab: CtcVocab,
        enSession: OrtSession?,
        enVocab: CtcVocab,
        config: ForcedAlignmentConfig,
        onProgress: suspend (String, Float) -> Unit
    ): List<LyricLine> {
        onProgress("Running Voice Activity Detection (VAD) across isolated vocal stem…", 0.16f)
        val vadSegments = detectActiveVocalIslands(leadVocalMono16k ?: vocalMono16k, songDurationSeconds)

        val lineWeights = lines.map { line ->
            val norm = BilingualScriptAndNormalizer.normalizeForAcousticModel(line.text)
            norm.length.coerceAtLeast(4).toDouble()
        }
        val totalWeight = lineWeights.sum().coerceAtLeast(1.0)
        val totalActiveDuration = vadSegments.sumOf { it.endSec - it.startSec }.coerceAtLeast(1.0)

        fun activeTimeToSongTime(activeOffset: Double): Double {
            var remaining = activeOffset.coerceIn(0.0, totalActiveDuration)
            for (seg in vadSegments) {
                val segLen = seg.endSec - seg.startSec
                if (remaining <= segLen) return seg.startSec + remaining
                remaining -= segLen
            }
            return vadSegments.lastOrNull()?.endSec ?: songDurationSeconds
        }

        var cumulativeWeight = 0.0
        val anchoredLines = lines.mapIndexed { idx, line ->
            val startActive = (cumulativeWeight / totalWeight) * totalActiveDuration
            cumulativeWeight += lineWeights[idx]
            val endActive = (cumulativeWeight / totalWeight) * totalActiveDuration
            val beginSec = activeTimeToSongTime(startActive)
            val endSec = activeTimeToSongTime(endActive).coerceAtLeast(beginSec + 0.50)
            line.copy(begin = beginSec, end = endSec)
        }

        return alignLrcAnchoredWindows(
            lines = anchoredLines,
            vocalMono16k = vocalMono16k,
            originalMono16k = originalMono16k,
            leadVocalMono16k = leadVocalMono16k,
            backingVocalMono16k = backingVocalMono16k,
            leadBackingSeparationConfidence = leadBackingSeparationConfidence,
            songDurationSeconds = songDurationSeconds,
            arSession = arSession,
            arVocab = arVocab,
            enSession = enSession,
            enVocab = enVocab,
            config = config.copy(lrcWindowPaddingSeconds = 0.90, autoCorrectLrcGlobalOffset = false),
            onProgress = onProgress
        )
    }

    private fun detectActiveVocalIslands(vocalMono16k: FloatArray, songDurationSeconds: Double): List<VadSegment> {
        val frameSamples = 480 // 30ms @ 16kHz
        val numFrames = vocalMono16k.size / frameSamples
        if (numFrames == 0) return listOf(VadSegment(0.0, songDurationSeconds))

        val rmsFrames = FloatArray(numFrames)
        var maxRms = 0f
        for (f in 0 until numFrames) {
            var sumSq = 0.0
            val base = f * frameSamples
            for (i in 0 until frameSamples) {
                val s = vocalMono16k[base + i].toDouble()
                sumSq += s * s
            }
            val r = sqrt(sumSq / frameSamples.toDouble()).toFloat()
            rmsFrames[f] = r
            if (r > maxRms) maxRms = r
        }

        val threshold = max(0.004f, maxRms * 0.05f)
        val segments = mutableListOf<VadSegment>()
        var inSpeech = false
        var segStartFrame = 0
        var silenceRun = 0
        val hangoverFrames = 14

        for (f in 0 until numFrames) {
            if (rmsFrames[f] >= threshold) {
                if (!inSpeech) {
                    inSpeech = true
                    segStartFrame = max(0, f - 2)
                }
                silenceRun = 0
            } else if (inSpeech) {
                silenceRun++
                if (silenceRun >= hangoverFrames) {
                    val endFrame = f - silenceRun + 2
                    segments.add(
                        VadSegment(
                            startSec = (segStartFrame * frameSamples).toDouble() / CTC_SAMPLE_RATE,
                            endSec = (endFrame * frameSamples).toDouble() / CTC_SAMPLE_RATE
                        )
                    )
                    inSpeech = false
                }
            }
        }
        if (inSpeech) {
            segments.add(
                VadSegment(
                    startSec = (segStartFrame * frameSamples).toDouble() / CTC_SAMPLE_RATE,
                    endSec = songDurationSeconds
                )
            )
        }
        return segments.ifEmpty { listOf(VadSegment(0.0, songDurationSeconds)) }
    }

    // --------------------------------------------------------------------------------------------
    // PASS 1, PASS 2 & PASS 3: CALIBRATED MONOTONIC CTC FORCED ALIGNER + DUAL-SOURCE CONSONANTS
    // --------------------------------------------------------------------------------------------

    internal data class OrthographicToken(
        val displaySurface: String,
        val trailingSpace: Boolean,
        val script: WordScript,
        val ctcChars: String,
        val acousticUnits: String,
        val manners: Array<PhonemeMannerClass>,
        val charWeights: FloatArray,
        val totalAcousticWeight: Float
    )

    internal fun tokenizeLinePreservingOrthography(lineText: String): List<OrthographicToken> =
        tokenizePreservingOrthography(lineText)

    private fun tokenizePreservingOrthography(lineText: String): List<OrthographicToken> {
        val rawTokens = lineText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val rawScripts = rawTokens.map { BilingualScriptAndNormalizer.classifyWordScript(it) }
        val dominantLineScript = if (rawScripts.count { it == WordScript.ARABIC } >= rawScripts.count { it == WordScript.LATIN_ENGLISH }) {
            WordScript.ARABIC
        } else {
            WordScript.LATIN_ENGLISH
        }

        return rawTokens.mapIndexed { idx, token ->
            val resolvedScript = when (val s = rawScripts[idx]) {
                WordScript.ARABIC, WordScript.LATIN_ENGLISH -> s
                WordScript.NEUTRAL -> {
                    // Inherit script from nearest neighboring word for pure numbers/punctuation
                    rawScripts.getOrNull(idx - 1)?.takeIf { it != WordScript.NEUTRAL }
                        ?: rawScripts.getOrNull(idx + 1)?.takeIf { it != WordScript.NEUTRAL }
                        ?: dominantLineScript
                }
            }
            val ctcChars = BilingualScriptAndNormalizer.normalizeForNeuralCtc(token)
            val acousticUnits = BilingualScriptAndNormalizer.normalizeForAcousticModel(token)
            val manners = BilingualScriptAndNormalizer.classifyPhonemeManner(token, ctcChars)
            val weights = BilingualScriptAndNormalizer.computeAcousticUnitWeights(token, manners)
            val sumW = weights.sum().coerceAtLeast(1.0f)
            OrthographicToken(
                displaySurface = token,
                trailingSpace = idx < rawTokens.lastIndex,
                script = resolvedScript,
                ctcChars = ctcChars,
                acousticUnits = acousticUnits,
                manners = manners,
                charWeights = weights,
                totalAcousticWeight = sumW
            )
        }
    }

    private class SpectralFrameFeatures(
        val voicingScore: FloatArray,
        val formantScore: FloatArray,
        val fricativeScore: FloatArray,
        val onsetFluxScore: FloatArray,
        val spectralCentroidJump: FloatArray,
        val numFrames: Int
    )

    /**
     * Extracts 10ms (100 fps) 5-band spectral features from the isolated vocal stem, optionally
     * fusing high-frequency consonant transients (3.2–7.5 kHz) from the original mix when vocal
     * isolation attenuated unvoiced plosives or sibilants.
     */
    private fun extract10msSpectralFeatures(
        windowSamples: FloatArray,
        origWindowSamples: FloatArray? = null
    ): SpectralFrameFeatures {
        val numFrames = max(8, (windowSamples.size - FFT_SIZE) / FRAME_HOP_SAMPLES + 1)
        val rawRmsDb = FloatArray(numFrames)
        val rawFormant = FloatArray(numFrames)
        val rawFricative = FloatArray(numFrames)
        val rawFlux = FloatArray(numFrames)
        val centroid = FloatArray(numFrames)

        val numBins = FFT_SIZE / 2 + 1
        val real = FloatArray(FFT_SIZE)
        val imag = FloatArray(FFT_SIZE)
        val origReal = if (origWindowSamples != null) FloatArray(FFT_SIZE) else null
        val origImag = if (origWindowSamples != null) FloatArray(FFT_SIZE) else null
        val prevBandMag = FloatArray(32)

        val minFormantBin = (280.0 * FFT_SIZE / CTC_SAMPLE_RATE).toInt().coerceAtLeast(1)
        val maxFormantBin = (3400.0 * FFT_SIZE / CTC_SAMPLE_RATE).toInt().coerceAtMost(numBins - 1)
        val minFricBin = (3200.0 * FFT_SIZE / CTC_SAMPLE_RATE).toInt().coerceAtLeast(1)
        val maxFricBin = (7600.0 * FFT_SIZE / CTC_SAMPLE_RATE).toInt().coerceAtMost(numBins - 1)

        for (f in 0 until numFrames) {
            val base = f * FRAME_HOP_SAMPLES
            var sumSq = 0.0
            for (i in 0 until FFT_SIZE) {
                val s = windowSamples.getOrElse(base + i) { 0f }
                sumSq += (s * s).toDouble()
                real[i] = s * hann512[i]
                imag[i] = 0f
                if (origWindowSamples != null && origReal != null && origImag != null) {
                    val os = origWindowSamples.getOrElse(base + i) { 0f }
                    origReal[i] = os * hann512[i]
                    origImag[i] = 0f
                }
            }
            val rms = sqrt(sumSq / FFT_SIZE.toDouble()).toFloat()
            rawRmsDb[f] = (20.0 * log10(rms.toDouble().coerceAtLeast(1e-6))).toFloat()

            StftProcessor.fftRadix2(real, imag)
            if (origReal != null && origImag != null) {
                StftProcessor.fftRadix2(origReal, origImag)
            }

            var formantAcc = 0.0
            var weightedFreq = 0.0
            var totalMag = 1e-6
            for (b in minFormantBin..maxFormantBin) {
                val mag = hypot(real[b].toDouble(), imag[b].toDouble())
                formantAcc += mag
                weightedFreq += b * mag
                totalMag += mag
            }
            rawFormant[f] = ln1p(formantAcc * 40.0).toFloat()

            var fricAcc = 0.0
            var origFricAcc = 0.0
            for (b in minFricBin..maxFricBin) {
                val mag = hypot(real[b].toDouble(), imag[b].toDouble())
                fricAcc += mag
                weightedFreq += b * mag
                totalMag += mag
                if (origReal != null && origImag != null) {
                    origFricAcc += hypot(origReal[b].toDouble(), origImag[b].toDouble())
                }
            }
            // Recover high-frequency consonant energy from original mix if vocal separation attenuated it
            val effectiveFric = max(fricAcc, origFricAcc * 0.42)
            rawFricative[f] = ln1p(effectiveFric * 80.0).toFloat()
            centroid[f] = (weightedFreq / totalMag).toFloat()

            var fluxAcc = 0f
            for (band in 0 until 32) {
                val bStart = 4 + (band * 240) / 32
                val bEnd = 4 + ((band + 1) * 240) / 32
                var bandEnergy = 0.0
                for (b in bStart..bEnd.coerceAtMost(numBins - 1)) {
                    bandEnergy += hypot(real[b].toDouble(), imag[b].toDouble())
                }
                val logBand = ln1p(bandEnergy * 50.0).toFloat()
                val diff = logBand - prevBandMag[band]
                if (diff > 0f) fluxAcc += diff
                prevBandMag[band] = logBand
            }
            rawFlux[f] = if (f == 0) 0f else fluxAcc
        }

        val sortedDb = rawRmsDb.copyOf().apply { sort() }
        val rawP92Db = sortedDb[(numFrames * 0.92).toInt().coerceIn(0, numFrames - 1)]
        val p12Db = min(sortedDb[(numFrames * 0.08).toInt().coerceIn(0, numFrames - 1)], rawP92Db - 18.0f)
        val p92Db = rawP92Db.coerceAtLeast(p12Db + 6f)

        val sortedFormant = rawFormant.copyOf().apply { sort() }
        val rawP95Formant = sortedFormant[(numFrames * 0.95).toInt().coerceIn(0, numFrames - 1)]
        val p15Formant = min(sortedFormant[(numFrames * 0.10).toInt().coerceIn(0, numFrames - 1)], rawP95Formant - 2.2f)
        val p95Formant = rawP95Formant.coerceAtLeast(p15Formant + 0.5f)

        val sortedFric = rawFricative.copyOf().apply { sort() }
        val p20Fric = sortedFric[(numFrames * 0.20).toInt().coerceIn(0, numFrames - 1)]
        val p95Fric = sortedFric[(numFrames * 0.95).toInt().coerceIn(0, numFrames - 1)].coerceAtLeast(p20Fric + 0.5f)

        val smoothedFlux = FloatArray(numFrames) { f ->
            val prev = rawFlux[(f - 1).coerceAtLeast(0)]
            val cur = rawFlux[f]
            val next = rawFlux[(f + 1).coerceAtMost(numFrames - 1)]
            0.25f * prev + 0.50f * cur + 0.25f * next
        }
        val sortedFlux = smoothedFlux.copyOf().apply { sort() }
        val p95Flux = sortedFlux[(numFrames * 0.95).toInt().coerceIn(0, numFrames - 1)].coerceAtLeast(1e-4f)

        val centroidJump = FloatArray(numFrames) { f ->
            if (f == 0) 0f else abs(centroid[f] - centroid[f - 1])
        }
        val maxCentroidJump = centroidJump.maxOrNull()?.coerceAtLeast(1f) ?: 1f

        val voicingScore = FloatArray(numFrames)
        val formantScore = FloatArray(numFrames)
        val fricativeScore = FloatArray(numFrames)
        val onsetFluxScore = FloatArray(numFrames)
        val normCentroidJump = FloatArray(numFrames)

        for (f in 0 until numFrames) {
            voicingScore[f] = ((rawRmsDb[f] - p12Db) / (p92Db - p12Db)).coerceIn(0f, 1f)
            formantScore[f] = ((rawFormant[f] - p15Formant) / (p95Formant - p15Formant)).coerceIn(0f, 1f)
            fricativeScore[f] = ((rawFricative[f] - p20Fric) / (p95Fric - p20Fric)).coerceIn(0f, 1f)
            onsetFluxScore[f] = (smoothedFlux[f] / p95Flux).coerceIn(0f, 1.35f)
            normCentroidJump[f] = (centroidJump[f] / maxCentroidJump).coerceIn(0f, 1f)
        }

        return SpectralFrameFeatures(
            voicingScore = voicingScore,
            formantScore = formantScore,
            fricativeScore = fricativeScore,
            onsetFluxScore = onsetFluxScore,
            spectralCentroidJump = normCentroidJump,
            numFrames = numFrames
        )
    }

    private fun detectVocalPhraseFrameBounds(
        features: SpectralFrameFeatures,
        relAnchorStartFrame: Int,
        relAnchorEndFrame: Int,
        expectedMinSpeechFrames: Int
    ): Pair<Int, Int> {
        val n = features.numFrames.coerceAtLeast(2)
        val searchStart = (relAnchorStartFrame - 45).coerceIn(0, (n - 2).coerceAtLeast(0))
        // Phase 3 Fix: Search up to +160 frames (+1.60s) beyond an imperfect LRC line-end estimate
        // so sustained line-final vowels and melismas are never truncated at `relAnchorEndFrame + 6`!
        val extendedSearchEnd = (relAnchorEndFrame + 160).coerceIn((searchStart + 1).coerceAtMost(n - 1), n - 1)

        var firstVocalFrame = relAnchorStartFrame.coerceIn(0, n - 1)
        var sawPreAnchorSilenceOrDip = (searchStart == 0 && features.voicingScore[searchStart] < 0.16f)
        for (f in searchStart..extendedSearchEnd) {
            val v = features.voicingScore[f]
            val o = features.onsetFluxScore[f]
            val s = features.fricativeScore[f]
            if (v < 0.16f) {
                sawPreAnchorSilenceOrDip = true
            }
            val isGenuineStart = if (f < relAnchorStartFrame - 4 && !sawPreAnchorSilenceOrDip) {
                o >= 0.42f || (s >= 0.40f && o >= 0.28f)
            } else {
                v >= 0.20f || (v >= 0.13f && (o >= 0.32f || s >= 0.36f))
            }
            if (isGenuineStart) {
                firstVocalFrame = (f - 2).coerceAtLeast(searchStart)
                break
            }
        }

        var lastValidVocalFrame = (firstVocalFrame + expectedMinSpeechFrames).coerceAtMost(extendedSearchEnd)
        var currentVoicedRun = 0
        var silenceAfterAnchorEnd = 0
        for (f in firstVocalFrame..extendedSearchEnd) {
            val isVoiced = features.voicingScore[f] >= 0.16f || features.formantScore[f] >= 0.19f
            if (isVoiced) {
                currentVoicedRun++
                silenceAfterAnchorEnd = 0
                if (currentVoicedRun >= 5 || f <= relAnchorEndFrame + 15) {
                    lastValidVocalFrame = (f + 4).coerceAtMost(extendedSearchEnd)
                }
            } else {
                currentVoicedRun = 0
                if (f > relAnchorEndFrame + 10) {
                    silenceAfterAnchorEnd++
                    // Stop extending beyond the nominal LRC line end once >= 120ms of true silence is observed
                    if (silenceAfterAnchorEnd >= 12) break
                }
            }
        }

        if (lastValidVocalFrame <= firstVocalFrame + 8) {
            lastValidVocalFrame = (firstVocalFrame + expectedMinSpeechFrames.coerceAtLeast(16)).coerceAtMost(n - 1)
        }
        return firstVocalFrame to lastValidVocalFrame
    }

    /**
     * Pass 2 & Pass 3:
     * Calibrated Monotonic 2N+1 CTC Forced Aligner + Dual-Source Consonant Recovery +
     * Per-Word Acoustic Confidence & Review Flagging.
     */
    private fun alignTokensInWindow(
        tokens: List<OrthographicToken>,
        vocalMono16k: FloatArray,
        originalMono16k: FloatArray? = null,
        winStartSec: Double,
        winEndSec: Double,
        anchorBeginSec: Double,
        anchorEndSec: Double,
        hardMaxEndSec: Double,
        arSession: OrtSession?,
        arVocab: CtcVocab,
        enSession: OrtSession?,
        enVocab: CtcVocab,
        config: ForcedAlignmentConfig,
        blendOriginalMixRatio: Float = 0.0f,
        suppressBackingMono16k: FloatArray? = null,
        maxPhraseSec: Double = 12.0
    ): List<WordTiming> {
        val cappedWinEndSec = min(winEndSec, max(anchorEndSec + 3.0, winStartSec + 20.0))
        val startSample = (winStartSec * CTC_SAMPLE_RATE).roundToInt().coerceIn(0, vocalMono16k.size)
        val endSample = (cappedWinEndSec * CTC_SAMPLE_RATE).roundToInt().coerceIn(startSample, vocalMono16k.size)
        val rawVocalSlice = if (endSample - startSample >= FFT_SIZE + FRAME_HOP_SAMPLES * 4) {
            vocalMono16k.copyOfRange(startSample, endSample)
        } else {
            FloatArray(FFT_SIZE + FRAME_HOP_SAMPLES * 20)
        }

        val origSlice = if (originalMono16k != null && startSample < originalMono16k.size) {
            val oEnd = endSample.coerceIn(startSample, originalMono16k.size)
            if (oEnd - startSample == rawVocalSlice.size) {
                originalMono16k.copyOfRange(startSample, oEnd)
            } else null
        } else null

        val backSlice = if (suppressBackingMono16k != null && startSample < suppressBackingMono16k.size) {
            val bEnd = endSample.coerceIn(startSample, suppressBackingMono16k.size)
            if (bEnd - startSample == rawVocalSlice.size) {
                suppressBackingMono16k.copyOfRange(startSample, bEnd)
            } else null
        } else null

        val windowSamples = if (blendOriginalMixRatio > 0.0f && origSlice != null) {
            val vWeight = (1.0f - blendOriginalMixRatio).coerceIn(0.5f, 1.0f)
            FloatArray(rawVocalSlice.size) { idx ->
                vWeight * rawVocalSlice[idx] + blendOriginalMixRatio * origSlice[idx]
            }
        } else if (backSlice != null) {
            // Phase 3 & Phase 5 Fix: Never attenuate the lead vocal while the lead singer is still actively
            // sustaining a note alongside a backing vocal! Only attenuate pure backing-only echo tails where
            // local 20ms lead RMS has already dropped below 20% of the window's peak lead RMS AND backing RMS is > 1.8x lead RMS.
            val frameLen = 320
            val numBlocks = (rawVocalSlice.size / frameLen).coerceAtLeast(1)
            val blockLeadRms = FloatArray(numBlocks)
            val blockBackRms = FloatArray(numBlocks)
            var peakLeadRms = 1e-4f
            for (b in 0 until numBlocks) {
                var lSum = 0.0
                var bSum = 0.0
                val base = b * frameLen
                for (k in 0 until frameLen) {
                    val ls = rawVocalSlice[base + k].toDouble()
                    val bs = backSlice[base + k].toDouble()
                    lSum += ls * ls
                    bSum += bs * bs
                }
                val lr = sqrt(lSum / frameLen).toFloat()
                val br = sqrt(bSum / frameLen).toFloat()
                blockLeadRms[b] = lr
                blockBackRms[b] = br
                if (lr > peakLeadRms) peakLeadRms = lr
            }
            FloatArray(rawVocalSlice.size) { idx ->
                val blk = (idx / frameLen).coerceIn(0, numBlocks - 1)
                val lr = blockLeadRms[blk]
                val br = blockBackRms[blk]
                if (lr < peakLeadRms * 0.20f && br > lr * 1.80f) {
                    rawVocalSlice[idx] * 0.35f
                } else {
                    rawVocalSlice[idx]
                }
            }
        } else rawVocalSlice

        val features = extract10msSpectralFeatures(windowSamples, origSlice)
        val totalWinFrames = features.numFrames
        val winDurationSec = (winEndSec - winStartSec).coerceAtLeast(0.10)
        val frameDurSec = FRAME_HOP_SAMPLES.toDouble() / CTC_SAMPLE_RATE.toDouble() // Exact 10.0ms per frame

        val relAnchorStart = (((anchorBeginSec - winStartSec) / winDurationSec) * totalWinFrames)
            .roundToInt().coerceIn(0, (totalWinFrames - 2).coerceAtLeast(0))
        val relAnchorEnd = (((anchorEndSec - winStartSec) / winDurationSec) * totalWinFrames)
            .roundToInt().coerceIn((relAnchorStart + 1).coerceAtMost(totalWinFrames - 1), (totalWinFrames - 1).coerceAtLeast(0))

        val totalCharCount = tokens.sumOf { it.ctcChars.length.coerceAtLeast(1) }
        val expectedMinSpeechFrames = (totalCharCount * 5).coerceIn(14, 200)

        val (phraseStartFrame, phraseEndFrame) = detectVocalPhraseFrameBounds(
            features = features,
            relAnchorStartFrame = relAnchorStart,
            relAnchorEndFrame = relAnchorEnd,
            expectedMinSpeechFrames = expectedMinSpeechFrames
        )

        if (tokens.size == 1) {
            noteHeuristicFallback("Single-token line '${tokens[0].displaySurface}' uses acoustic-only timing; neural CTC is not run for this path.")
            val rawBegin = (winStartSec + phraseStartFrame * frameDurSec).coerceAtLeast(0.0)
            val wBegin = refine5msAttack(windowSamples, origSlice, winStartSec, rawBegin)
            val wEnd = (winStartSec + (phraseEndFrame + 1) * frameDurSec)
                .coerceIn(wBegin + 0.14, hardMaxEndSec.coerceAtLeast(wBegin + 0.14))
            var peakV = 0f
            for (f in phraseStartFrame..phraseEndFrame.coerceAtMost(totalWinFrames - 1)) {
                if (features.voicingScore[f] > peakV) peakV = features.voicingScore[f]
            }
            val conf = (0.45f + 0.50f * peakV).coerceIn(0.15f, 0.96f)
            val baseWord = WordTiming(
                text = tokens[0].displaySurface,
                begin = wBegin,
                end = wEnd,
                confidence = min(conf, 0.45f),
                needsReview = true
            )
            return if (config.enableSyllableSplitting && (wEnd - wBegin) >= config.minSyllableSplitDurationSec) {
                val splits = BilingualSyllabifier.findSyllableSplitPoints(tokens[0].displaySurface)
                if (splits.isNotEmpty()) WordSpacesAndSyllables.splitWordIntoSyllables(baseWord, splits)
                else listOf(baseWord)
            } else listOf(baseWord)
        }

        // Build the exact 2N + 1 Monotonic Bilingual CTC Lattice:
        // Each token is routed to its script-appropriate vocabulary (`arVocab` for ARABIC, `enVocab` for LATIN_ENGLISH).
        data class TrellisState(
            val isBlank: Boolean,
            val isInterWordOrEdgeBlank: Boolean,
            val tokenIndex: Int,
            val script: WordScript,
            val isWordStartChar: Boolean,
            val isWordEndChar: Boolean,
            val manner: PhonemeMannerClass,
            val vocabId: Int,
            val secondaryVocabId: Int? = null,
            val hasValidVocabToken: Boolean,
            val expectedRatio: Float
        )

        val firstTokenScript = tokens.firstOrNull()?.script ?: WordScript.ARABIC
        val firstVocab = if (firstTokenScript == WordScript.ARABIC) arVocab else enVocab
        val totalLexicalWeight = tokens.sumOf { it.totalAcousticWeight.toDouble() }.toFloat().coerceAtLeast(1f)
        var runningWeight = 0f
        val trellisStates = mutableListOf<TrellisState>()

        // State 0: Leading Blank
        trellisStates.add(
            TrellisState(
                isBlank = true,
                isInterWordOrEdgeBlank = true,
                tokenIndex = -1,
                script = firstTokenScript,
                isWordStartChar = false,
                isWordEndChar = false,
                manner = PhonemeMannerClass.PLOSIVE_STOP,
                vocabId = firstVocab.blankId,
                hasValidVocabToken = true,
                expectedRatio = 0f
            )
        )

        for (tIdx in tokens.indices) {
            val tok = tokens[tIdx]
            val tokScript = tok.script
            val tokVocab = if (tokScript == WordScript.ARABIC) arVocab else enVocab
            val chars = tok.ctcChars.ifEmpty { "a" }
            for (cIdx in chars.indices) {
                val w = tok.charWeights.getOrElse(cIdx) { 1.0f }
                val centerRatio = ((runningWeight + 0.5f * w) / totalLexicalWeight).coerceIn(0f, 1f)
                val manner = tok.manners.getOrElse(cIdx) { PhonemeMannerClass.VOWEL_SHORT }
                val resolvedId = tokVocab.lookupCharIdOrNull(chars[cIdx])
                val secondaryId = if (tokScript == WordScript.ARABIC) tokVocab.lookupSecondaryCharIdOrNull(chars[cIdx]) else null

                trellisStates.add(
                    TrellisState(
                        isBlank = false,
                        isInterWordOrEdgeBlank = false,
                        tokenIndex = tIdx,
                        script = tokScript,
                        isWordStartChar = (cIdx == 0),
                        isWordEndChar = (cIdx == chars.lastIndex),
                        manner = manner,
                        vocabId = resolvedId ?: secondaryId ?: tokVocab.blankId,
                        secondaryVocabId = secondaryId,
                        hasValidVocabToken = (resolvedId != null || secondaryId != null),
                        expectedRatio = centerRatio
                    )
                )
                runningWeight += w

                if (cIdx < chars.lastIndex) {
                    trellisStates.add(
                        TrellisState(
                            isBlank = true,
                            isInterWordOrEdgeBlank = false,
                            tokenIndex = tIdx,
                            script = tokScript,
                            isWordStartChar = false,
                            isWordEndChar = false,
                            manner = manner,
                            vocabId = tokVocab.blankId,
                            hasValidVocabToken = true,
                            expectedRatio = (runningWeight / totalLexicalWeight).coerceIn(0f, 1f)
                        )
                    )
                } else if (tIdx < tokens.lastIndex) {
                    trellisStates.add(
                        TrellisState(
                            isBlank = true,
                            isInterWordOrEdgeBlank = true,
                            tokenIndex = -1,
                            script = tokScript,
                            isWordStartChar = false,
                            isWordEndChar = false,
                            manner = PhonemeMannerClass.PLOSIVE_STOP,
                            vocabId = tokVocab.wordDelimiterId,
                            hasValidVocabToken = true,
                            expectedRatio = (runningWeight / totalLexicalWeight).coerceIn(0f, 1f)
                        )
                    )
                } else {
                    trellisStates.add(
                        TrellisState(
                            isBlank = true,
                            isInterWordOrEdgeBlank = true,
                            tokenIndex = -1,
                            script = tokScript,
                            isWordStartChar = false,
                            isWordEndChar = false,
                            manner = PhonemeMannerClass.PLOSIVE_STOP,
                            vocabId = tokVocab.blankId,
                            hasValidVocabToken = true,
                            expectedRatio = 1.0f
                        )
                    )
                }
            }
        }

        val ctcEndFrame = min(totalWinFrames - 1, max(phraseEndFrame + 25, min(relAnchorEnd + 160, phraseStartFrame + ((maxPhraseSec * 100.0).roundToInt() - 100).coerceAtLeast(1100))))
        val activePhraseFrames = (ctcEndFrame - phraseStartFrame + 1).coerceAtLeast(tokens.size * 6)
        val phraseStartSample = (phraseStartFrame * FRAME_HOP_SAMPLES).coerceIn(0, windowSamples.size - 1)
        val maxCtcSamples = (CTC_SAMPLE_RATE * maxPhraseSec.coerceIn(12.0, 24.0)).roundToInt() // 12s by default, longer only for gap repair
        val phraseEndSample = min(
            windowSamples.size,
            max(phraseStartSample + FFT_SIZE, (ctcEndFrame - phraseStartFrame) * FRAME_HOP_SAMPLES + FFT_SIZE)
        ).coerceAtMost(phraseStartSample + maxCtcSamples)

        val phraseSamples16k = if (phraseEndSample - phraseStartSample >= FFT_SIZE) {
            windowSamples.copyOfRange(phraseStartSample, phraseEndSample)
        } else windowSamples

        // Phase 2 Bilingual CTC Inference:
        // Evaluates Arabic states with `arSession` + `arVocab` and English states with `enSession` + `enVocab`
        // on the shared 10ms frame timeline (`0 until activePhraseFrames`), supporting intra-line code-switching!
        val needsArCtc = trellisStates.any { !it.isBlank && it.script == WordScript.ARABIC }
        val needsEnCtc = trellisStates.any { !it.isBlank && it.script == WordScript.LATIN_ENGLISH }

        val arCtcFrames = if (needsArCtc && arSession != null) {
            runOnnxCtcInference(
                session = arSession,
                samples16k = phraseSamples16k,
                targetFrames = activePhraseFrames,
                vocab = arVocab,
                stateVocabIds = trellisStates.map { if (it.script == WordScript.ARABIC) it.vocabId else arVocab.blankId },
                stateSecondaryVocabIds = trellisStates.map { if (it.script == WordScript.ARABIC) it.secondaryVocabId else null },
                stateIsEdgeOrInterWord = trellisStates.map { it.isInterWordOrEdgeBlank }
            )
        } else null

        val enCtcFrames = if (needsEnCtc && enSession != null) {
            runOnnxCtcInference(
                session = enSession,
                samples16k = phraseSamples16k,
                targetFrames = activePhraseFrames,
                vocab = enVocab,
                stateVocabIds = trellisStates.map { if (it.script == WordScript.LATIN_ENGLISH) it.vocabId else enVocab.blankId },
                stateSecondaryVocabIds = trellisStates.map { null },
                stateIsEdgeOrInterWord = trellisStates.map { it.isInterWordOrEdgeBlank }
            )
        } else null

        val ctcFramesResult: Array<FloatArray>? = when {
            arCtcFrames != null && enCtcFrames != null -> {
                Array(activePhraseFrames) { t ->
                    FloatArray(trellisStates.size) { s ->
                        val st = trellisStates[s]
                        if (st.script == WordScript.LATIN_ENGLISH) enCtcFrames[t][s] else arCtcFrames[t][s]
                    }
                }
            }
            arCtcFrames != null -> arCtcFrames
            enCtcFrames != null -> enCtcFrames
            else -> null
        }

        fun hasNeuralForScript(script: WordScript): Boolean = when (script) {
            WordScript.ARABIC -> arCtcFrames != null
            WordScript.LATIN_ENGLISH -> enCtcFrames != null
            WordScript.NEUTRAL -> false
        }
        val numStates = trellisStates.size
        val negInf = -1e9f
        val dp = Array(activePhraseFrames) { FloatArray(numStates) { negInf } }
        val backptr = Array(activePhraseFrames) { IntArray(numStates) { 0 } }

        for (localT in 0 until activePhraseFrames) {
            val globalFrame = (phraseStartFrame + localT).coerceIn(0, totalWinFrames - 1)
            val vScore = features.voicingScore[globalFrame]
            val fScore = features.formantScore[globalFrame]
            val sScore = features.fricativeScore[globalFrame]
            val oScore = features.onsetFluxScore[globalFrame]
            val cJump = features.spectralCentroidJump[globalFrame]
            val isVocalActive = vScore >= 0.22f || fScore >= 0.24f || (sScore >= 0.35f && oScore >= 0.28f)

            for (s in 0 until numStates) {
                val st = trellisStates[s]
                val isTrailingBlank = (s == numStates - 1)
                val isLeadingBlank = (s == 0)

                val mannerSpectralScore = when (st.manner) {
                    PhonemeMannerClass.VOWEL_LONG_MADD -> (0.65f * fScore + 0.55f * vScore) * 1.40f
                    PhonemeMannerClass.VOWEL_SHORT -> (0.60f * fScore + 0.50f * vScore) * 1.25f
                    PhonemeMannerClass.NASAL_LIQUID -> (0.55f * fScore + 0.45f * vScore) * 1.15f
                    PhonemeMannerClass.FRICATIVE_SIBILANT -> (0.68f * sScore + 0.45f * oScore + 0.25f * vScore) * 1.25f
                    PhonemeMannerClass.PLOSIVE_STOP -> (0.72f * oScore + 0.35f * vScore + 0.28f * sScore) * 1.20f
                }

                val emission: Float = if (
                    ctcFramesResult != null &&
                    st.hasValidVocabToken &&
                    hasNeuralForScript(st.script)
                ) {
                    val rawLogProb = ctcFramesResult[localT][s].coerceIn(-12.0f, 0.0f)
                    if (isTrailingBlank || isLeadingBlank) {
                        rawLogProb * 0.85f + (if (!isVocalActive) 1.30f * (1.0f - vScore) else 0.08f)
                    } else if (st.isInterWordOrEdgeBlank) {
                        if (!isVocalActive) {
                            rawLogProb * 0.85f + 1.35f * (1.0f - vScore)
                        } else {
                            rawLogProb * 0.80f - 0.15f * vScore + 0.22f * cJump
                        }
                    } else if (st.isBlank) {
                        if (!isVocalActive) {
                            rawLogProb - 1.90f
                        } else {
                            rawLogProb * 0.75f + 0.12f * vScore - 0.20f
                        }
                    } else {
                        val voiceGate = if (isVocalActive) (0.22f * vScore + 0.14f * fScore + 0.10f * mannerSpectralScore) else -1.95f
                        rawLogProb + voiceGate
                    }
                } else {
                    // Explicit fallback for OOV characters (e.g. cross-script code-switching) or when ONNX is unavailable
                    if (st.isInterWordOrEdgeBlank) {
                        if (!isVocalActive) {
                            +1.60f * (1.0f - vScore)
                        } else {
                            -0.45f * vScore + 0.40f * cJump
                        }
                    } else {
                        if (!isVocalActive) {
                            -2.10f
                        } else {
                            val blankDamp = if (st.isBlank) 0.70f else 1.0f
                            (0.50f + mannerSpectralScore) * blankDamp
                        }
                    }
                }

                if (localT == 0) {
                    if (s == 0) {
                        dp[0][0] = emission
                        backptr[0][0] = 0
                    } else if (s == 1) {
                        dp[0][1] = emission + 0.4f * oScore
                        backptr[0][1] = 1
                    }
                    continue
                }

                // Transition 1: Stay in state s (s -> s)
                val stayAdj = when {
                    isTrailingBlank -> if (!isVocalActive) +0.28f else +0.06f
                    isLeadingBlank -> if (!isVocalActive) +0.25f else -0.35f * vScore
                    st.isInterWordOrEdgeBlank -> if (!isVocalActive) +0.26f else -0.22f * vScore
                    st.isBlank -> -0.14f
                    st.manner == PhonemeMannerClass.VOWEL_LONG_MADD -> +0.14f * vScore
                    st.manner == PhonemeMannerClass.VOWEL_SHORT -> +0.08f * vScore
                    else -> +0.02f * vScore
                }
                var bestPrevScore = dp[localT - 1][s] + stayAdj
                var bestPrevState = s

                // Transition 2: Step from s - 1 (blank -> char, or char -> Inter-Word/Trailing blank)
                if (s > 0 && dp[localT - 1][s - 1] > negInf * 0.5f) {
                    val stepBonus = when {
                        st.isInterWordOrEdgeBlank -> if (!isVocalActive) +0.35f else +0.08f
                        st.isWordStartChar -> 0.60f * oScore + 0.28f * cJump
                        else -> 0.0f
                    }
                    val cand = dp[localT - 1][s - 1] + stepBonus
                    if (cand > bestPrevScore) {
                        bestPrevScore = cand
                        bestPrevState = s - 1
                    }
                }

                // Transition 3: Standard CTC skip-blank (s - 2 -> s)
                if (s >= 2 && !st.isBlank && dp[localT - 1][s - 2] > negInf * 0.5f) {
                    val prevCharState = trellisStates[s - 2]
                    val sameWordDistinctChar = !prevCharState.isBlank &&
                        prevCharState.tokenIndex == st.tokenIndex &&
                        prevCharState.vocabId != st.vocabId
                    val crossWordLegato = !prevCharState.isBlank &&
                        prevCharState.tokenIndex != st.tokenIndex &&
                        vScore >= 0.45f
                    if (sameWordDistinctChar || crossWordLegato) {
                        val legatoBonus = if (st.isWordStartChar) (0.45f * oScore + 0.22f * cJump) else 0.05f
                        val cand = dp[localT - 1][s - 2] + legatoBonus
                        if (cand > bestPrevScore) {
                            bestPrevScore = cand
                            bestPrevState = s - 2
                        }
                    }
                }

                if (bestPrevScore > negInf * 0.5f) {
                    dp[localT][s] = bestPrevScore + emission
                    backptr[localT][s] = bestPrevState
                }
            }
        }

        val stateAtLocalFrame = IntArray(activePhraseFrames)
        var curState = numStates - 1
        if (numStates >= 2 && dp[activePhraseFrames - 1][numStates - 2] > dp[activePhraseFrames - 1][numStates - 1]) {
            curState = numStates - 2
        }
        if (dp[activePhraseFrames - 1][curState] <= negInf * 0.5f) {
            var bestFinalS = numStates - 1
            var bestFinalVal = negInf
            for (s in max(0, numStates - 6) until numStates) {
                if (dp[activePhraseFrames - 1][s] > bestFinalVal) {
                    bestFinalVal = dp[activePhraseFrames - 1][s]
                    bestFinalS = s
                }
            }
            curState = bestFinalS
        }
        for (localT in activePhraseFrames - 1 downTo 0) {
            stateAtLocalFrame[localT] = curState
            curState = backptr[localT][curState]
        }

        val tokenFirstLocal = IntArray(tokens.size) { Int.MAX_VALUE }
        val tokenLastLocal = IntArray(tokens.size) { -1 }
        val tokenCtcProbSum = FloatArray(tokens.size)
        val tokenCtcFrameCount = IntArray(tokens.size)

        for (localT in 0 until activePhraseFrames) {
            val sIdx = stateAtLocalFrame[localT]
            val st = trellisStates[sIdx]
            if (st.tokenIndex >= 0) {
                if (localT < tokenFirstLocal[st.tokenIndex]) tokenFirstLocal[st.tokenIndex] = localT
                if (localT > tokenLastLocal[st.tokenIndex]) tokenLastLocal[st.tokenIndex] = localT
                if (!st.isBlank && ctcFramesResult != null && st.hasValidVocabToken &&
                    hasNeuralForScript(tokens[st.tokenIndex].script)
                ) {
                    val lp = ctcFramesResult[localT][sIdx].coerceIn(-10.0f, 0.0f)
                    tokenCtcProbSum[st.tokenIndex] += exp(lp.toDouble()).toFloat()
                    tokenCtcFrameCount[st.tokenIndex]++
                }
            }
        }

        val actualVocalSpanFrames = ((tokenLastLocal.maxOrNull() ?: (activePhraseFrames - 1)) -
            (tokenFirstLocal.minOrNull()?.takeIf { it < Int.MAX_VALUE } ?: 0) + 1).coerceAtLeast(tokens.size * 6)
        val maxLocalFrame = (activePhraseFrames - 1).coerceAtLeast(0)
        val maxStartFrame = (activePhraseFrames - 2).coerceAtLeast(0)
        var cursorLocal = tokenFirstLocal.firstOrNull()?.takeIf { it < Int.MAX_VALUE } ?: 0
        for (tIdx in tokens.indices) {
            if (tokenFirstLocal[tIdx] > tokenLastLocal[tIdx]) {
                val share = ((tokens[tIdx].totalAcousticWeight / totalLexicalWeight) * actualVocalSpanFrames)
                    .roundToInt().coerceAtLeast(6)
                tokenFirstLocal[tIdx] = cursorLocal.coerceIn(0, maxStartFrame)
                tokenLastLocal[tIdx] = (cursorLocal + share).coerceIn(tokenFirstLocal[tIdx], maxLocalFrame)
            } else {
                tokenFirstLocal[tIdx] = tokenFirstLocal[tIdx].coerceIn(0, maxLocalFrame)
                tokenLastLocal[tIdx] = tokenLastLocal[tIdx].coerceIn(tokenFirstLocal[tIdx], maxLocalFrame)
            }
            cursorLocal = (tokenLastLocal[tIdx] + 1).coerceAtMost(maxLocalFrame)
        }

        // Phase 3 Dedicated Word-End Sustain Refinement Stage:
        // Uses the CTC character alignment (`tokenFirstLocal`, `tokenLastLocal`) as the initial estimate,
        // then examines acoustic sustain evidence (voicing envelope, harmonic F1/F2 formant continuity,
        // vibrato tolerance, intra-word Shadda/stop bridging, and reverberation-decay discrimination)
        // to find the true end of each sung word without prematurely truncating held vowels.
        val avgFramesPerWord = activePhraseFrames.toFloat() / tokens.size.coerceAtLeast(1).toFloat()
        val isFastDelivery = avgFramesPerWord < 26.0f

        if (config.enableSustainedEndRefinement) {
            val maxExtFrames = (config.maxSustainedWordExtensionSec * 100.0).roundToInt().coerceIn(50, 600)
            for (i in tokens.indices) {
                val wStart = tokenFirstLocal[i].coerceIn(0, maxLocalFrame)
                val hardNextCeiling = if (i < tokens.lastIndex) {
                    val nextStart = tokenFirstLocal[i + 1].coerceIn(wStart, maxLocalFrame)
                    val minCeil = min(wStart + 5, maxLocalFrame)
                    (nextStart - 1).coerceIn(minCeil, maxLocalFrame)
                } else {
                    val minCeil = min(wStart + 8, maxLocalFrame)
                    max(phraseEndFrame - phraseStartFrame, tokenLastLocal[i] + 20).coerceIn(minCeil, maxLocalFrame)
                }

                val searchLimit = min(hardNextCeiling, wStart + maxExtFrames).coerceAtLeast(wStart)
                val charLen = tokens[i].ctcChars.length.coerceAtLeast(1)
                val minArticulationFrames = if (isFastDelivery) {
                    max(5, min(12, charLen * 2))
                } else {
                    max(9, min(18, charLen * 3))
                }
                val minArticulationLocal = min(searchLimit, wStart + minArticulationFrames).coerceAtLeast(wStart)
                val ctcEnd = tokenLastLocal[i].coerceIn(minArticulationLocal, searchLimit.coerceAtLeast(minArticulationLocal))

                // 1. Measure signal-adaptive per-word vocal reference from the word's core [wStart .. max(ctcEnd, minArticulationLocal + 8)]
                val coreProbeEnd = min(searchLimit, max(ctcEnd, minArticulationLocal + 12))
                var wordPeakVoicing = 0.18f
                var wordPeakFormant = 0.18f
                for (t in wStart..coreProbeEnd) {
                    val gf = (phraseStartFrame + t).coerceIn(0, totalWinFrames - 1)
                    if (features.voicingScore[gf] > wordPeakVoicing) wordPeakVoicing = features.voicingScore[gf]
                    if (features.formantScore[gf] > wordPeakFormant) wordPeakFormant = features.formantScore[gf]
                }

                // Adaptive sustain floors (tolerant to 5-6 Hz vibrato modulation dips down to 16% of peak)
                val sustainVoicingFloor = max(0.12f, wordPeakVoicing * 0.16f)
                val sustainFormantFloor = max(0.13f, wordPeakFormant * 0.17f)
                val requiredPauseFrames = if (isFastDelivery) 5 else 8 // 80ms of genuine pause required to end a normal/held word

                // 2. Start scanning from `max(minArticulationLocal, ctcEnd - 2)` so internal Shadda/stop closures
                //    earlier in the word (`[wStart .. ctcEnd - 3]`) NEVER prematurely terminate the word!
                val scanStartLocal = max(minArticulationLocal, (ctcEnd - 2).coerceAtLeast(wStart))
                var lastVoicedFrame = scanStartLocal
                var consecutiveSilentFrames = 0
                var monotonicDecayFrames = 0
                var prevCombinedEnv = 1.0f

                for (t in scanStartLocal..searchLimit) {
                    val gf = (phraseStartFrame + t).coerceIn(0, totalWinFrames - 1)
                    val v = features.voicingScore[gf]
                    val f = features.formantScore[gf]
                    val s = features.fricativeScore[gf]
                    val o = features.onsetFluxScore[gf]
                    val cJump = features.spectralCentroidJump[gf]

                    // Check if a sharp new consonant attack after `ctcEnd + 5` signals the onset of the next word
                    if (i < tokens.lastIndex && t > ctcEnd + 5 && o >= 0.62f && cJump >= 0.46f && t >= hardNextCeiling - 4) {
                        break
                    }

                    val combinedEnv = 0.52f * f + 0.48f * v
                    if (combinedEnv < prevCombinedEnv - 0.008f && v < wordPeakVoicing * 0.28f && f < wordPeakFormant * 0.25f) {
                        monotonicDecayFrames++
                    } else if (combinedEnv >= prevCombinedEnv) {
                        monotonicDecayFrames = 0
                    }
                    prevCombinedEnv = combinedEnv

                    // Distinguish reverberation tail from true sung sustain:
                    // If energy has been decaying monotonically for >= 90ms (9 frames) below 28% peak without formant re-excitation, stop at the release knee
                    val isReverbTailOnly = monotonicDecayFrames >= 9 && f < wordPeakFormant * 0.22f
                    val isFrameVoiced = !isReverbTailOnly && (v >= sustainVoicingFloor || f >= sustainFormantFloor || (t <= ctcEnd + 4 && s >= 0.32f))

                    if (isFrameVoiced) {
                        consecutiveSilentFrames = 0
                        lastVoicedFrame = t
                    } else {
                        consecutiveSilentFrames++
                        // Allow brief intra-word consonant closure up to 80ms if we haven't passed ctcEnd + 6 yet
                        val allowedDip = if (t <= ctcEnd + 6) max(requiredPauseFrames, 9) else requiredPauseFrames
                        if (consecutiveSilentFrames >= allowedDip) {
                            break
                        }
                    }
                }

                tokenLastLocal[i] = lastVoicedFrame.coerceIn(minArticulationLocal, searchLimit.coerceAtLeast(minArticulationLocal))
            }
        }

        val rawWords = ArrayList<WordTiming>(tokens.size * 2)
        for (tIdx in tokens.indices) {
            val tok = tokens[tIdx]
            val startGlobalFrame = phraseStartFrame + tokenFirstLocal[tIdx]
            val endGlobalFrame = phraseStartFrame + tokenLastLocal[tIdx]

            val wordBegin = refine5msAttack(
                windowSamples = windowSamples,
                origWindowSamples = origSlice,
                winStartSec = winStartSec,
                coarseTimeSec = (winStartSec + startGlobalFrame * frameDurSec).coerceAtLeast(0.0)
            )
            val minWordSec = if (isFastDelivery) 0.05 else 0.08
            val rawEnd = winStartSec + (max(startGlobalFrame + 5, endGlobalFrame) + 1) * frameDurSec
            val wordEnd = min(hardMaxEndSec, max(wordBegin + minWordSec, rawEnd))
            val surfaceWithSpace = if (tok.trailingSpace) "${tok.displaySurface} " else tok.displaySurface

            // Compute calibrated per-word confidence from real alignment evidence (Requirement 5)
            val wordConfidence = computeWordConfidence(
                startGlobalFrame = startGlobalFrame,
                endGlobalFrame = endGlobalFrame,
                features = features,
                hasNeuralCtc = hasNeuralForScript(tok.script),
                ctcProbSum = tokenCtcProbSum[tIdx],
                ctcFrameCount = tokenCtcFrameCount[tIdx]
            )
            val tokenHasNeuralCtc = hasNeuralForScript(tok.script)
            if (!tokenHasNeuralCtc) {
                noteHeuristicFallback("${tok.script} token '${tok.displaySurface}' was timed heuristically and marked for review.")
            }

            val baseWord = WordTiming(
                text = surfaceWithSpace,
                begin = wordBegin,
                end = wordEnd,
                confidence = if (tokenHasNeuralCtc) wordConfidence else min(wordConfidence, 0.45f),
                needsReview = !tokenHasNeuralCtc || wordConfidence < 0.48f
            )

            if (config.enableSyllableSplitting && (wordEnd - wordBegin) >= config.minSyllableSplitDurationSec) {
                val splits = BilingualSyllabifier.findSyllableSplitPoints(tok.displaySurface)
                if (splits.isNotEmpty()) {
                    rawWords.addAll(WordSpacesAndSyllables.splitWordIntoSyllables(baseWord, splits))
                    continue
                }
            }
            rawWords.add(baseWord)
        }

        return WordSpacesAndSyllables.resolveOverlapsForward(
            WordSpacesAndSyllables.trimTrailingSpaceFromLast(rawWords),
            duration = hardMaxEndSec.coerceAtLeast(winEndSec)
        )
    }

    /**
     * Calculates calibrated per-word acoustic & CTC alignment confidence in [0.05f, 0.99f]
     * from: (1) neural CTC posterior probability along the word's path, (2) in-span vocal SNR,
     * and (3) onset/offset boundary contrast.
     */
    private fun computeWordConfidence(
        startGlobalFrame: Int,
        endGlobalFrame: Int,
        features: SpectralFrameFeatures,
        hasNeuralCtc: Boolean,
        ctcProbSum: Float,
        ctcFrameCount: Int
    ): Float {
        val n = features.numFrames
        val sFrame = startGlobalFrame.coerceIn(0, n - 1)
        val eFrame = endGlobalFrame.coerceIn(sFrame, n - 1)
        val spanLen = (eFrame - sFrame + 1).coerceAtLeast(1)

        var sumPresence = 0f
        var peakPresence = 0f
        for (f in sFrame..eFrame) {
            val pres = max(features.voicingScore[f], max(features.formantScore[f], features.fricativeScore[f] * 0.85f))
            sumPresence += pres
            if (pres > peakPresence) peakPresence = pres
        }
        val meanPresence = (sumPresence / spanLen).coerceIn(0f, 1f)

        val onsetSharpness = max(
            features.onsetFluxScore[sFrame],
            max(
                features.onsetFluxScore[(sFrame - 1).coerceAtLeast(0)],
                features.onsetFluxScore[(sFrame + 1).coerceAtMost(n - 1)]
            )
        ).coerceIn(0f, 1f)

        val acousticConfidence = (0.50f * meanPresence + 0.30f * peakPresence + 0.20f * onsetSharpness).coerceIn(0.05f, 0.98f)
        return if (hasNeuralCtc && ctcFrameCount > 0) {
            val meanCtcProb = (ctcProbSum / ctcFrameCount.toFloat()).coerceIn(0.02f, 0.99f)
            (0.55f * sqrt(meanCtcProb.toDouble()).toFloat() + 0.45f * acousticConfidence).coerceIn(0.05f, 0.99f)
        } else {
            acousticConfidence
        }
    }

    /**
     * Pass 3 (5ms Sub-Frame Micro-Transient Attack Refiner with Dual-Source Consonant Recovery):
     * Inspects 5ms (`80`-sample @ 16kHz) energy derivative around `coarseTimeSec` (±35ms)
     * across both the isolated vocal stem and the original mix (when vocal separation attenuated
     * a plosive or sibilant onset), applying a 10ms consonant pre-roll.
     */
    private fun refine5msAttack(
        windowSamples: FloatArray,
        origWindowSamples: FloatArray? = null,
        winStartSec: Double,
        coarseTimeSec: Double
    ): Double {
        val relSec = (coarseTimeSec - winStartSec).coerceAtLeast(0.0)
        val centerSample = (relSec * CTC_SAMPLE_RATE).roundToInt().coerceIn(0, windowSamples.size - 1)
        val hop5ms = 80 // 5ms @ 16kHz
        val searchRadius = 7 // ±35ms
        if (centerSample - searchRadius * hop5ms < 0 || centerSample + (searchRadius + 1) * hop5ms >= windowSamples.size) {
            return coarseTimeSec
        }

        var bestStep = 0
        var maxRise = 0.0
        for (step in -searchRadius until searchRadius) {
            val s0 = centerSample + step * hop5ms
            val s1 = s0 + hop5ms
            var e0 = 0.0
            var e1 = 0.0
            var oe0 = 0.0
            var oe1 = 0.0
            for (i in 0 until hop5ms) {
                val v0 = windowSamples[s0 + i].toDouble()
                val v1 = windowSamples[s1 + i].toDouble()
                e0 += v0 * v0
                e1 += v1 * v1
                if (origWindowSamples != null && s1 + i < origWindowSamples.size) {
                    val ov0 = origWindowSamples[s0 + i].toDouble()
                    val ov1 = origWindowSamples[s1 + i].toDouble()
                    oe0 += ov0 * ov0
                    oe1 += ov1 * ov1
                }
            }
            val vocalRise = sqrt(e1 / hop5ms) - sqrt(e0 / hop5ms)
            val origRise = if (origWindowSamples != null) (sqrt(oe1 / hop5ms) - sqrt(oe0 / hop5ms)) * 0.35 else 0.0
            val rise = max(vocalRise, origRise)
            if (rise > maxRise) {
                maxRise = rise
                bestStep = step
            }
        }
        return if (maxRise > 0.006) {
            (coarseTimeSec + bestStep * 0.005 - 0.010).coerceAtLeast(winStartSec)
        } else coarseTimeSec
    }

    /**
     * Runs the ONNX CTC model (`aligner-ar/model.int8.onnx` or `aligner-en/model.int8.onnx` or bundled ONNX)
     * and maps the 20ms Wav2Vec2 convolutional output frames (receptive field = 400 samples, stride = 320 samples)
     * onto the 10ms STFT frames (window = 512 samples, hop = 160 samples) via exact sample-center linear
     * log-probability interpolation (`mExact = (160 * t + 256 - 200) / 320.0`).
     */
    private fun runOnnxCtcInference(
        session: OrtSession,
        samples16k: FloatArray,
        targetFrames: Int,
        vocab: CtcVocab,
        stateVocabIds: List<Int>,
        stateSecondaryVocabIds: List<Int?>,
        stateIsEdgeOrInterWord: List<Boolean>
    ): Array<FloatArray>? = runCatching {
        var mean = 0.0
        for (s in samples16k) mean += s
        mean /= samples16k.size.coerceAtLeast(1)
        var variance = 0.0
        for (s in samples16k) {
            val d = s - mean
            variance += d * d
        }
        val std = sqrt(variance / samples16k.size.coerceAtLeast(1) + 1e-7).toFloat()
        val normInput = FloatArray(samples16k.size) { i -> ((samples16k[i] - mean.toFloat()) / std) }

        val inputNames = session.inputNames.toList()
        val primaryName = inputNames.firstOrNull() ?: return@runCatching null
        val inputTensor = OnnxTensor.createTensor(
            ortEnv,
            FloatBuffer.wrap(normInput),
            longArrayOf(1L, normInput.size.toLong())
        )
        val maskName = inputNames.firstOrNull { it.contains("mask", ignoreCase = true) }
        val maskTensor = if (maskName != null) {
            val maskArr = LongArray(normInput.size) { 1L }
            OnnxTensor.createTensor(
                ortEnv,
                java.nio.LongBuffer.wrap(maskArr),
                longArrayOf(1L, normInput.size.toLong())
            )
        } else null

        val feeds = if (maskName != null && maskTensor != null) {
            mapOf(primaryName to inputTensor, maskName to maskTensor)
        } else {
            mapOf(primaryName to inputTensor)
        }

        try {
            session.run(feeds).use { result ->
                val outTensor = result.get(0) as? OnnxTensor ?: return@runCatching null
                val shape = outTensor.info.shape
                val modelFrames: Int
                val vocabSize: Int
                if (shape.size >= 3) {
                    modelFrames = shape[1].toInt().coerceAtLeast(1)
                    vocabSize = shape[2].toInt().coerceAtLeast(2)
                } else if (shape.size == 2) {
                    modelFrames = shape[0].toInt().coerceAtLeast(1)
                    vocabSize = shape[1].toInt().coerceAtLeast(2)
                } else {
                    return@runCatching null
                }

                val rawLogits = FloatArray(modelFrames * vocabSize)
                outTensor.floatBuffer.get(rawLogits)
                val bId = vocab.blankId.coerceIn(0, vocabSize - 1)
                val dId = vocab.wordDelimiterId.coerceIn(0, vocabSize - 1)

                // Normalize each 20ms model frame in-place inside `rawLogits` into exact log-probabilities
                for (m in 0 until modelFrames) {
                    val base = m * vocabSize
                    var maxLogit = -1e9f
                    for (v in 0 until vocabSize) {
                        if (rawLogits[base + v] > maxLogit) maxLogit = rawLogits[base + v]
                    }
                    var sumExp = 0.0
                    for (v in 0 until vocabSize) {
                        sumExp += exp((rawLogits[base + v] - maxLogit).toDouble())
                    }
                    val logDenom = maxLogit + ln(sumExp).toFloat()
                    for (v in 0 until vocabSize) {
                        rawLogits[base + v] -= logDenom
                    }
                }

                // Exact Wav2Vec2 convolutional receptive-field center mapping:
                // 10ms STFT frame `t` center sample = 160 * t + 256
                // 20ms Wav2Vec2 frame `m` center sample = 320 * m + 200
                // => mExact(t) = (160 * t + 56) / 320.0 = 0.5 * t + 0.175
                Array(targetFrames) { t ->
                    val mExact = ((t * FRAME_HOP_SAMPLES + (FFT_SIZE / 2) - 200).toDouble() / 320.0)
                        .coerceIn(0.0, (modelFrames - 1).coerceAtLeast(0).toDouble())
                    val m0 = mExact.toInt().coerceIn(0, modelFrames - 1)
                    val m1 = (m0 + 1).coerceIn(0, modelFrames - 1)
                    val alpha = (mExact - m0).toFloat().coerceIn(0f, 1f)
                    val oneMinusAlpha = 1.0f - alpha

                    val base0 = m0 * vocabSize
                    val base1 = m1 * vocabSize
                    val blankLp = oneMinusAlpha * rawLogits[base0 + bId] + alpha * rawLogits[base1 + bId]
                    val delimLp = oneMinusAlpha * rawLogits[base0 + dId] + alpha * rawLogits[base1 + dId]
                    val sepLp = max(blankLp, delimLp)

                    FloatArray(stateVocabIds.size) { u ->
                        if (stateIsEdgeOrInterWord[u]) {
                            sepLp
                        } else {
                            val vId = stateVocabIds[u].coerceIn(0, vocabSize - 1)
                            val primaryLp = oneMinusAlpha * rawLogits[base0 + vId] + alpha * rawLogits[base1 + vId]
                            val secId = stateSecondaryVocabIds[u]?.coerceIn(0, vocabSize - 1)
                            if (secId != null && secId != vId) {
                                val secLp = (oneMinusAlpha * rawLogits[base0 + secId] + alpha * rawLogits[base1 + secId]) - 0.35f
                                max(primaryLp, secLp)
                            } else {
                                primaryLp
                            }
                        }
                    }
                }
            }
        } finally {
            inputTensor.close()
            maskTensor?.close()
        }
    }.onFailure {
        noteAlignmentWarning("Neural CTC inference failed: ${it.message ?: it.javaClass.simpleName}; the affected script may use acoustic heuristics.")
    }.getOrNull()
}
