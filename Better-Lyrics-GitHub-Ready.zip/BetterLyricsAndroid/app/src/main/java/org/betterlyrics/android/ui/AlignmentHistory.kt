package org.betterlyrics.android.ui

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One saved alignment result. The TTML text itself lives in [fileName] inside the history folder. */
data class AlignmentHistoryEntry(
    val id: Long,
    val title: String,
    val artist: String,
    val language: String,
    val lineCount: Int,
    val wordCount: Int,
    val contentHash: Int,
    val fileName: String
)

/**
 * Keeps every finished alignment on the device so an earlier TTML can be opened or exported again.
 * Files: `<filesDir>/alignment_history/<id>.ttml` plus a tab separated `index.tsv`.
 */
object AlignmentHistoryStore {
    private const val DIR_NAME = "alignment_history"
    private const val INDEX_NAME = "index.tsv"
    private const val MAX_ENTRIES = 100

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    private fun clean(text: String): String =
        text.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim()

    @Synchronized
    fun load(context: Context): List<AlignmentHistoryEntry> = runCatching {
        val index = File(dir(context), INDEX_NAME)
        if (!index.exists()) return emptyList()
        index.readLines(Charsets.UTF_8).mapNotNull { row ->
            val p = row.split("\t")
            if (p.size < 8) return@mapNotNull null
            val id = p[0].toLongOrNull() ?: return@mapNotNull null
            AlignmentHistoryEntry(
                id = id,
                title = p[1],
                artist = p[2],
                language = p[3],
                lineCount = p[4].toIntOrNull() ?: 0,
                wordCount = p[5].toIntOrNull() ?: 0,
                contentHash = p[6].toIntOrNull() ?: 0,
                fileName = p[7]
            )
        }.filter { File(dir(context), it.fileName).exists() }.sortedByDescending { it.id }
    }.getOrDefault(emptyList())

    private fun writeIndex(context: Context, entries: List<AlignmentHistoryEntry>) {
        val text = entries.joinToString("\n") { e ->
            listOf(e.id, e.title, e.artist, e.language, e.lineCount, e.wordCount, e.contentHash, e.fileName)
                .joinToString("\t")
        }
        File(dir(context), INDEX_NAME).writeText(text, Charsets.UTF_8)
    }

    /** Saves a TTML result; returns the new entry, or null when the identical text was already saved last. */
    @Synchronized
    fun save(
        context: Context,
        title: String,
        artist: String,
        language: String,
        lineCount: Int,
        wordCount: Int,
        ttml: String
    ): AlignmentHistoryEntry? = runCatching {
        if (ttml.isBlank()) return null
        val hash = ttml.hashCode()
        val existing = load(context)
        if (existing.firstOrNull()?.contentHash == hash) return null

        val id = System.currentTimeMillis()
        val fileName = "$id.ttml"
        File(dir(context), fileName).writeText(ttml, Charsets.UTF_8)
        val entry = AlignmentHistoryEntry(
            id = id,
            title = clean(title).ifEmpty { "Untitled" },
            artist = clean(artist),
            language = clean(language).ifEmpty { "ar" },
            lineCount = lineCount,
            wordCount = wordCount,
            contentHash = hash,
            fileName = fileName
        )
        val all = listOf(entry) + existing
        val kept = all.take(MAX_ENTRIES)
        all.drop(MAX_ENTRIES).forEach { File(dir(context), it.fileName).delete() }
        writeIndex(context, kept)
        entry
    }.getOrNull()

    fun readTtml(context: Context, entry: AlignmentHistoryEntry): String? = runCatching {
        File(dir(context), entry.fileName).readText(Charsets.UTF_8)
    }.getOrNull()

    @Synchronized
    fun delete(context: Context, entry: AlignmentHistoryEntry) {
        runCatching {
            File(dir(context), entry.fileName).delete()
            writeIndex(context, load(context).filterNot { it.id == entry.id })
        }
    }

    fun formatTimestamp(epochMillis: Long): String = runCatching {
        SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(Date(epochMillis))
    }.getOrDefault("")
}
