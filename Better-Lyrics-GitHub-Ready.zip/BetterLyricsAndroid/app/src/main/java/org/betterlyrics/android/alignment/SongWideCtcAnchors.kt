package org.betterlyrics.android.alignment

import kotlin.math.abs
import kotlin.math.max

/**
 * v5.13 - song-wide CTC line placement.
 *
 * Why: the per-line aligner only looks in a window around each LRC stamp (about -0.75 s .. +next line). When a
 * stamp is more than ~1 s off (Birthday Sex: 13 of 44 stamps are 1.4-4.4 s late, Banadeek Taala L9/L10, ...) the
 * singer is simply not inside the window, every later step (probes, repairs) starts from a wrong place and the whole
 * line - and often its neighbours - end up misplaced.
 *
 * What: ONE monotonic CTC forced alignment of ALL lyric lines over the whole vocal stem, with a soft prior that keeps
 * every line's first character near its LRC stamp (so repeated lines such as "Birthday sex, birthday sex" cannot slide
 * onto the wrong repetition). A line is only moved when
 *   1. the song-wide position differs from the LRC stamp by at least [MIN_SHIFT_SEC], and
 *   2. the line's own CTC log-likelihood at the song-wide position beats its log-likelihood at the LRC position by
 *      [MIN_LOGLIK_GAIN] nats.
 * Offline validation with the shipped ONNX models (first-word error vs. hand-timed references, current output ->
 * after correction): Banadeek Taala 505 -> 201 ms, Beit Kebeer 222 -> 156 ms, Birthday Sex 998 -> 246 ms.
 *
 * Everything in this file is pure (no Android / ONNX types) so it can be unit tested on the JVM.
 */
internal class SongWideLine(
    /** CTC vocabulary ids of the line's characters, in order. Never empty. */
    val labels: IntArray,
    /** true when the label belongs to the Arabic model's vocabulary. */
    val isArabic: BooleanArray,
    /** LRC begin of the line (seconds). */
    val lrcBegin: Double,
    /** Begin of the next line (or the song end) - only used to size the search band. */
    val bandEnd: Double,
    /** Index into [labels] where each word starts (ascending, first entry 0). Empty = word spans not available. */
    val wordLabelStart: IntArray = IntArray(0)
)

/** Per-frame log-probabilities (20 ms grid). [frameTimes] are frame centres in seconds. */
internal class SongWideEmissions(
    val frameTimes: DoubleArray,
    val arLogp: Array<FloatArray>?,
    val enLogp: Array<FloatArray>?,
    val arBlank: Int,
    val enBlank: Int
)

internal class SongWideLineSpan(
    val startSec: Double,
    val endSec: Double,
    /** CTC spike time of the first / last character of every word (empty when [SongWideLine.wordLabelStart] is empty). */
    val wordSpikeBegin: DoubleArray = DoubleArray(0),
    val wordSpikeEnd: DoubleArray = DoubleArray(0)
)

internal class SongWidePlan(val spans: List<SongWideLineSpan>, val decisions: List<SongWideAnchorDecision>)

/** Outcome of comparing one line's current word timings with the song-wide ones. */
internal class SongWideArbitration(
    val useSongWide: Boolean,
    val logLikGain: Double,
    val meanBeginShift: Double,
    val begins: DoubleArray,
    val ends: DoubleArray
)

internal class SongWideAnchorDecision(
    val lineIndex: Int,
    val lrcBegin: Double,
    val songWideBegin: Double,
    val songWideEnd: Double,
    val logLikGain: Double,
    val moved: Boolean
)

/** What the song-wide pass leaves behind for the arbitration step. */
internal class SongWideContext(
    val emissions: SongWideEmissions,
    val specs: List<SongWideLine>,
    val spans: List<SongWideLineSpan>,
    /** index of the spec's line in the full line list */
    val specLineIdx: List<Int>,
    /** true when every token of the line has CTC labels, i.e. word spans map 1:1 onto the line's words */
    val arbitrable: BooleanArray,
    val tokenCounts: IntArray,
    val lineCount: Int
)

internal class SongWideHolder {
    @Volatile var context: SongWideContext? = null
}

internal object SongWideCtc {
    const val BAND_BEFORE_SEC = 30.0
    const val BAND_AFTER_SEC = 30.0
    const val PRIOR_LAMBDA_PER_SEC = 2.0
    const val PRIOR_TOLERANCE_SEC = 0.8
    const val MIN_SHIFT_SEC = 0.50
    const val MIN_LOGLIK_GAIN = 2.0
    const val SEGMENT_PAD_SEC = 0.50
    /** CTC spikes land ~0.1-0.2 s after the audible onset; the per-line window then still has its own look-back. */
    const val SPIKE_BIAS_SEC = 0.15
    /** Word-level spike delay (median 50-100 ms on the benchmark songs) removed from song-wide word starts. */
    const val SPIKE_BIAS_WORD_SEC = 0.08
    const val LAST_WORD_TAIL_SEC = 0.25
    const val WORD_PAD_SEC = 0.08
    const val ARBITRATION_MIN_LOGLIK_GAIN = 4.0
    const val ARBITRATION_MIN_MEAN_SHIFT_SEC = 0.15

    private const val NEG = -1.0e18

    private fun emission(e: SongWideEmissions, t: Int, ar: Boolean, id: Int): Double {
        val rows = (if (ar) e.arLogp else e.enLogp) ?: return -50.0
        return rows[t][id].toDouble()
    }

    /**
     * Banded, monotonic CTC Viterbi over all [lines] (concatenated label sequence, blank-separated).
     * Returns one span per line (first label frame .. last label frame) or null when no consistent path exists.
     */
    fun align(e: SongWideEmissions, lines: List<SongWideLine>): List<SongWideLineSpan>? {
        val frames = e.frameTimes.size
        if (frames < 8 || lines.isEmpty()) return null
        for (k in 1 until lines.size) if (lines[k].lrcBegin < lines[k - 1].lrcBegin - 1e-6) return null

        val total = lines.sumOf { it.labels.size }
        val ids = IntArray(total)
        val ar = BooleanArray(total)
        val firstLabel = IntArray(lines.size)
        val lastLabel = IntArray(lines.size)
        var p = 0
        for ((k, ln) in lines.withIndex()) {
            firstLabel[k] = p
            for (j in ln.labels.indices) { ids[p] = ln.labels[j]; ar[p] = ln.isArabic[j]; p++ }
            lastLabel[k] = p - 1
        }
        val states = 2 * total + 1
        val stateId = IntArray(states)
        val stateAr = BooleanArray(states)
        val entryLine = IntArray(states) { -1 }
        for (s in 0 until states) {
            if (s % 2 == 1) {
                val li = s / 2
                stateId[s] = ids[li]; stateAr[s] = ar[li]
            } else {
                val ref = if (s == 0) 0 else (s / 2 - 1)
                stateAr[s] = ar[ref]
                stateId[s] = if (ar[ref]) e.arBlank else e.enBlank
            }
        }
        for (k in lines.indices) entryLine[2 * firstLabel[k] + 1] = k
        val skipOk = BooleanArray(states)
        for (s in 3 until states step 2) skipOk[s] = ids[s / 2] != ids[s / 2 - 1]

        // Per-frame state band. Lines are ordered, so the allowed lines form a contiguous, monotone interval.
        val lo = IntArray(frames)
        val hi = IntArray(frames)
        var a = 0
        var b = -1
        for (t in 0 until frames) {
            val tt = e.frameTimes[t]
            while (a < lines.size && lines[a].bandEnd + BAND_AFTER_SEC < tt) a++
            while (b + 1 < lines.size && lines[b + 1].lrcBegin - BAND_BEFORE_SEC <= tt) b++
            lo[t] = if (a >= lines.size) states - 1 else 2 * firstLabel[a]
            hi[t] = if (b < 0) 0 else minOf(states - 1, 2 * lastLabel[b] + 2)
            if (hi[t] < lo[t]) hi[t] = lo[t]
        }
        // the path must be able to start in state 0/1 and end in the last two states
        lo[0] = 0
        hi[0] = max(hi[0], 1)
        hi[frames - 1] = states - 1
        lo[frames - 1] = minOf(lo[frames - 1], states - 2)

        val bp = arrayOfNulls<ByteArray>(frames)
        var prevLo = lo[0]
        var prevDp = DoubleArray(hi[0] - lo[0] + 1) { NEG }
        run {
            val l0 = lo[0]
            for (s in l0..hi[0]) {
                if (s <= 1) prevDp[s - l0] = emission(e, 0, stateAr[s], stateId[s])
            }
            bp[0] = ByteArray(hi[0] - lo[0] + 1)
        }
        for (t in 1 until frames) {
            val l = lo[t]
            val h = hi[t]
            val cur = DoubleArray(h - l + 1) { NEG }
            val back = ByteArray(h - l + 1)
            val prevHi = prevLo + prevDp.size - 1
            val tt = e.frameTimes[t]
            for (s in l..h) {
                var best = if (s in prevLo..prevHi) prevDp[s - prevLo] else NEG
                var arg = 0
                var pen = 0.0
                val el = entryLine[s]
                if (el >= 0) {
                    pen = PRIOR_LAMBDA_PER_SEC * max(0.0, abs(tt - lines[el].lrcBegin) - PRIOR_TOLERANCE_SEC)
                }
                if (s - 1 >= prevLo && s - 1 <= prevHi) {
                    val c = prevDp[s - 1 - prevLo] - pen
                    if (c > best) { best = c; arg = 1 }
                }
                if (s % 2 == 1 && skipOk[s] && s - 2 >= prevLo && s - 2 <= prevHi) {
                    val c = prevDp[s - 2 - prevLo] - pen
                    if (c > best) { best = c; arg = 2 }
                }
                cur[s - l] = if (best <= NEG / 2) NEG else best + emission(e, t, stateAr[s], stateId[s])
                back[s - l] = arg.toByte()
            }
            bp[t] = back
            prevLo = l
            prevDp = cur
        }
        // best terminal state
        val lastLo = prevLo
        val sA = states - 2
        val sB = states - 1
        val vA = if (sA - lastLo in prevDp.indices) prevDp[sA - lastLo] else NEG
        val vB = if (sB - lastLo in prevDp.indices) prevDp[sB - lastLo] else NEG
        if (max(vA, vB) <= NEG / 2) return null
        var s = if (vA > vB) sA else sB

        val labelFirst = IntArray(total) { -1 }
        val labelLast = IntArray(total) { -1 }
        for (t in frames - 1 downTo 0) {
            if (s % 2 == 1) {
                val li = s / 2
                labelFirst[li] = t
                if (labelLast[li] < 0) labelLast[li] = t
            }
            val arg = bp[t]!![s - lo[t]].toInt()
            s -= arg
            if (t > 0 && s < lo[t - 1]) return null
        }
        val out = ArrayList<SongWideLineSpan>(lines.size)
        for (k in lines.indices) {
            val f = labelFirst[firstLabel[k]]
            val l = labelLast[lastLabel[k]]
            if (f < 0 || l < 0) return null
            val ws = lines[k].wordLabelStart
            var wb = DoubleArray(0)
            var we = DoubleArray(0)
            if (ws.isNotEmpty()) {
                wb = DoubleArray(ws.size)
                we = DoubleArray(ws.size)
                for (w in ws.indices) {
                    val a0 = firstLabel[k] + ws[w]
                    val a1 = firstLabel[k] + (if (w + 1 < ws.size) ws[w + 1] else lines[k].labels.size) - 1
                    val ff = labelFirst[a0]
                    val ll = labelLast[a1]
                    if (ff < 0 || ll < 0) return null
                    wb[w] = e.frameTimes[ff]
                    we[w] = e.frameTimes[ll]
                }
            }
            out.add(SongWideLineSpan(e.frameTimes[f], e.frameTimes[l], wb, we))
        }
        return out
    }

    /** Best CTC path log-likelihood of one line's labels inside [t0, t1] (blank padded, no prior). */
    fun segmentLogLik(e: SongWideEmissions, line: SongWideLine, t0: Double, t1: Double): Double =
        segmentLogLik(e, line.labels, line.isArabic, t0, t1)

    fun segmentLogLik(e: SongWideEmissions, labels: IntArray, isArabic: BooleanArray, t0: Double, t1: Double): Double {
        val times = e.frameTimes
        var i0 = lowerBound(times, t0)
        var i1 = lowerBound(times, t1 + 1e-9) - 1
        if (i0 < 0) i0 = 0
        if (i1 >= times.size) i1 = times.size - 1
        val n = i1 - i0 + 1
        val total = labels.size
        if (n < total + 2) return -1.0e9
        val states = 2 * total + 1
        val stateId = IntArray(states)
        val stateAr = BooleanArray(states)
        for (s in 0 until states) {
            if (s % 2 == 1) { stateId[s] = labels[s / 2]; stateAr[s] = isArabic[s / 2] }
            else {
                val ref = if (s == 0) 0 else (s / 2 - 1)
                stateAr[s] = isArabic[ref]
                stateId[s] = if (isArabic[ref]) e.arBlank else e.enBlank
            }
        }
        var prev = DoubleArray(states) { NEG }
        prev[0] = emission(e, i0, stateAr[0], stateId[0])
        prev[1] = emission(e, i0, stateAr[1], stateId[1])
        for (t in i0 + 1..i1) {
            val cur = DoubleArray(states) { NEG }
            for (s in 0 until states) {
                var best = prev[s]
                if (s >= 1 && prev[s - 1] > best) best = prev[s - 1]
                if (s % 2 == 1 && s >= 3 && labels[s / 2] != labels[s / 2 - 1] && prev[s - 2] > best) best = prev[s - 2]
                if (best > NEG / 2) cur[s] = best + emission(e, t, stateAr[s], stateId[s])
            }
            prev = cur
        }
        return max(prev[states - 1], prev[states - 2])
    }

    /**
     * Sum over words of the best CTC log-likelihood of the word's characters inside its own [begin, end] interval
     * (padded by [WORD_PAD_SEC], and never narrower than 2 frames per label). A line whose words sit where the singer
     * really is scores higher than the same line shifted away.
     */
    fun wordsLogLik(e: SongWideEmissions, line: SongWideLine, begins: DoubleArray, ends: DoubleArray): Double {
        val ws = line.wordLabelStart
        if (ws.isEmpty() || begins.size != ws.size || ends.size != ws.size) return Double.NaN
        var total = 0.0
        for (w in ws.indices) {
            val a0 = ws[w]
            val a1 = if (w + 1 < ws.size) ws[w + 1] else line.labels.size
            val labels = line.labels.copyOfRange(a0, a1)
            val ar = line.isArabic.copyOfRange(a0, a1)
            val centre = (begins[w] + ends[w]) / 2.0
            val half = max((ends[w] - begins[w]) / 2.0 + WORD_PAD_SEC, (2 * labels.size + 3) * 0.02 / 2.0)
            total += segmentLogLik(e, labels, ar, centre - half, centre + half)
        }
        return total
    }

    /** Song-wide word timings as the final aligner should see them: spike - bias, contiguous inside the line. */
    fun songWideWordTimes(span: SongWideLineSpan): Pair<DoubleArray, DoubleArray> {
        val n = span.wordSpikeBegin.size
        val b = DoubleArray(n) { max(0.0, span.wordSpikeBegin[it] - SPIKE_BIAS_WORD_SEC) }
        val en = DoubleArray(n) { w -> if (w + 1 < n) b[w + 1] else span.wordSpikeEnd[w] + LAST_WORD_TAIL_SEC }
        return Pair(b, en)
    }

    /**
     * Decides whether a line's current word timings ([curBegins]/[curEnds]) should be replaced by the song-wide ones.
     * Both candidates are scored with the same CTC word log-likelihood (song-wide scored on its raw spike times).
     */
    fun arbitrate(
        e: SongWideEmissions,
        line: SongWideLine,
        span: SongWideLineSpan,
        curBegins: DoubleArray,
        curEnds: DoubleArray
    ): SongWideArbitration? {
        val n = line.wordLabelStart.size
        if (n == 0 || span.wordSpikeBegin.size != n || curBegins.size != n || curEnds.size != n) return null
        val (nb, ne) = songWideWordTimes(span)
        var shift = 0.0
        for (w in 0 until n) shift += abs(nb[w] - curBegins[w])
        shift /= n
        if (shift < ARBITRATION_MIN_MEAN_SHIFT_SEC) return SongWideArbitration(false, 0.0, shift, nb, ne)
        val scoreBegins = span.wordSpikeBegin
        val scoreEnds = DoubleArray(n) { w -> if (w + 1 < n) span.wordSpikeBegin[w + 1] else span.wordSpikeEnd[w] + 0.2 }
        val llSong = wordsLogLik(e, line, scoreBegins, scoreEnds)
        val llCur = wordsLogLik(e, line, curBegins, curEnds)
        if (llSong.isNaN() || llCur.isNaN()) return null
        val gain = llSong - llCur
        return SongWideArbitration(gain >= ARBITRATION_MIN_LOGLIK_GAIN, gain, shift, nb, ne)
    }

    private fun lowerBound(a: DoubleArray, x: Double): Int {
        var lo = 0
        var hi = a.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (a[mid] < x) lo = mid + 1 else hi = mid
        }
        return lo
    }

    /**
     * Runs the song-wide alignment and decides, per line, whether the LRC stamp should be replaced.
     * [lines] must be in LRC order; the returned list has one decision per input line.
     */
    fun planAnchorMoves(e: SongWideEmissions, lines: List<SongWideLine>): SongWidePlan? {
        val spans = align(e, lines) ?: return null
        val out = ArrayList<SongWideAnchorDecision>(lines.size)
        for ((k, ln) in lines.withIndex()) {
            val sp = spans[k]
            val shift = sp.startSec - ln.lrcBegin
            if (abs(shift) < MIN_SHIFT_SEC) {
                out.add(SongWideAnchorDecision(k, ln.lrcBegin, sp.startSec, sp.endSec, 0.0, false))
                continue
            }
            val dur = max(sp.endSec - sp.startSec, 0.5)
            val llSong = segmentLogLik(e, ln, sp.startSec - SEGMENT_PAD_SEC, sp.startSec + dur + SEGMENT_PAD_SEC)
            val llLrc = segmentLogLik(e, ln, ln.lrcBegin - SEGMENT_PAD_SEC, ln.lrcBegin + dur + SEGMENT_PAD_SEC)
            val gain = llSong - llLrc
            out.add(SongWideAnchorDecision(k, ln.lrcBegin, sp.startSec, sp.endSec, gain, gain >= MIN_LOGLIK_GAIN))
        }
        return SongWidePlan(spans, out)
    }
}
