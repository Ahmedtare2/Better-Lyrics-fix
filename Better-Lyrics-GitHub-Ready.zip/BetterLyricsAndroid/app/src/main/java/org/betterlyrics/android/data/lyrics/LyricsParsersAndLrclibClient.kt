package org.betterlyrics.android.data.lyrics

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.betterlyrics.android.domain.ttml.BackgroundVocalExtractor
import org.betterlyrics.android.domain.ttml.LyricLine
import org.betterlyrics.android.domain.ttml.NanoIdGenerator
import org.betterlyrics.android.domain.ttml.ParseIssue
import org.betterlyrics.android.domain.ttml.ParseResult
import org.betterlyrics.android.domain.ttml.ProjectMetadata
import org.betterlyrics.android.domain.ttml.TtmlConstants
import org.betterlyrics.android.domain.ttml.TtmlValidatorAndParser
import org.betterlyrics.android.domain.ttml.WordSpacesAndSyllables
import org.betterlyrics.android.domain.ttml.WordTiming
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToInt

// ================================================================================================
// 1. SYNC TYPE & DURATION MATCHING (Mirrors sync-type.ts & duration.ts)
// ================================================================================================

enum class SyncType(val label: String) {
    SYLLABLE("Syllable-Synced"),
    WORD("Word-Synced"),
    LINE("Line-Synced (LRC)"),
    UNSYNCED("Plain Text")
}

enum class DurationMatchBadge(val label: String, val deltaSeconds: Int) {
    EXACT("Exact Duration Match (±1s)", 0),
    CLOSE("Close Duration Match (±3s)", 2),
    OFFSET("Duration Offset (>3s)", 5),
    UNKNOWN("Duration Unknown", -1)
}

object SyncTypeDetector {
    private val LRC_LINE_TIMESTAMP_REGEX = Regex("\\[(\\d{1,2}):(\\d{1,2})(?:[.:](\\d{1,3}))?]")
    private val LRC_INLINE_WORD_TAG_REGEX = Regex("<(\\d{1,2}):(\\d{1,2})(?:[.:](\\d{1,3}))?>")
    private val METADATA_LINE_REGEX = Regex("^\\[[a-z]+:[^\\]]+]$", RegexOption.IGNORE_CASE)

    fun toUsableDurationSec(value: Double?): Int? {
        if (value == null || !value.isFinite() || value <= 0.0) return null
        val rounded = value.roundToInt()
        return if (rounded > 0) rounded else null
    }

    fun computeDurationBadge(candidateDurationSec: Int?, targetDurationSec: Double?): DurationMatchBadge {
        if (candidateDurationSec == null || targetDurationSec == null || targetDurationSec <= 0.0) {
            return DurationMatchBadge.UNKNOWN
        }
        val delta = abs(candidateDurationSec - targetDurationSec.roundToInt())
        return when {
            delta <= 1 -> DurationMatchBadge.EXACT
            delta <= 3 -> DurationMatchBadge.CLOSE
            else -> DurationMatchBadge.OFFSET
        }
    }

    fun detectLrcSyncType(content: String?): SyncType {
        if (content.isNullOrBlank()) return SyncType.UNSYNCED
        var sawLineTimestamp = false
        for (rawLine in content.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (LRC_INLINE_WORD_TAG_REGEX.containsMatchIn(line) && LRC_LINE_TIMESTAMP_REGEX.containsMatchIn(line)) {
                return SyncType.WORD
            }
            if (!sawLineTimestamp && LRC_LINE_TIMESTAMP_REGEX.containsMatchIn(line) && !METADATA_LINE_REGEX.matches(line)) {
                sawLineTimestamp = true
            }
        }
        return if (sawLineTimestamp) SyncType.LINE else SyncType.UNSYNCED
    }

    fun detectTtmlSyncType(xml: String?): SyncType {
        if (xml.isNullOrBlank()) return SyncType.UNSYNCED
        if (Regex("<span\\b[^>]*\\bbegin\\s*=").containsMatchIn(xml)) return SyncType.SYLLABLE
        if (Regex("<p\\b[^>]*\\bbegin\\s*=").containsMatchIn(xml)) return SyncType.LINE
        return SyncType.UNSYNCED
    }
}

// ================================================================================================
// 2. LRC / ENHANCED-LRC / TXT / SRT PARSER (Mirrors src/utils/lyrics-parsers/lrc.ts & txt.ts)
// ================================================================================================

object LrcAndTextParser {
    private const val CLOCK = "(\\d{1,2}):(\\d{2})(?:[.:](\\d{2,3}))?"
    private val LINE_TIMESTAMP_REGEX = Regex("\\[$CLOCK]")
    private val INLINE_WORD_TAG_REGEX = Regex("<$CLOCK>")
    private val LENGTH_REGEX = Regex("^$CLOCK$")
    private val LRC_METADATA_TAG_REGEX = Regex("^\\[([a-z]+):(.*)]$", RegexOption.IGNORE_CASE)
    private const val PENDING_WORD_END = -1.0
    private const val SECONDS_PER_MINUTE = 60.0

    fun parseLrcClock(minutes: String, seconds: String, fraction: String?): Double? {
        val s = seconds.toIntOrNull() ?: return null
        if (s >= 60) return null
        val m = minutes.toIntOrNull() ?: return null
        val milli = if (!fraction.isNullOrEmpty()) {
            fraction.padEnd(3, '0').take(3).toIntOrNull() ?: 0
        } else 0
        return m * SECONDS_PER_MINUTE + s + milli / 1000.0
    }

    private data class InlineWordParseResult(
        val cleanText: String,
        val words: List<WordTiming>
    )

    private data class Marker(val timestamp: Double, val matchStart: Int, val matchEnd: Int)

    private fun parseInlineWordTags(text: String, lineBegin: Double): Result<InlineWordParseResult?> {
        val markers = mutableListOf<Marker>()
        for (match in INLINE_WORD_TAG_REGEX.findAll(text)) {
            val ts = parseLrcClock(
                match.groupValues[1],
                match.groupValues[2],
                match.groupValues.getOrNull(3)?.takeIf { it.isNotEmpty() }
            ) ?: return Result.failure(IllegalArgumentException("invalid-timestamp"))
            markers.add(Marker(ts, match.range.first, match.range.last + 1))
        }
        if (markers.isEmpty()) return Result.success(null)

        val words = mutableListOf<WordTiming>()
        val leadingText = text.substring(0, markers[0].matchStart)
        if (leadingText.trim().isNotEmpty()) {
            words.add(WordTiming(text = leadingText, begin = lineBegin, end = markers[0].timestamp))
        }

        for (i in markers.indices) {
            val marker = markers[i]
            val nextMarker = markers.getOrNull(i + 1)
            val segmentStart = marker.matchEnd
            val segmentEnd = nextMarker?.matchStart ?: text.length
            val wordText = text.substring(segmentStart, segmentEnd)
            if (wordText.isEmpty()) continue
            words.add(
                WordTiming(
                    text = wordText,
                    begin = marker.timestamp,
                    end = nextMarker?.timestamp ?: PENDING_WORD_END
                )
            )
        }
        if (words.isEmpty()) return Result.success(null)
        return Result.success(
            InlineWordParseResult(
                cleanText = WordSpacesAndSyllables.reconstructLineText(words),
                words = words
            )
        )
    }

    /**
     * Exact port of parseLrc in src/utils/lyrics-parsers/lrc.ts
     */
    fun parseLrc(
        content: String,
        fallbackDuration: Double? = null,
        autoExtractBackgroundVocals: Boolean = true
    ): ParseResult {
        var title = ""
        var artists = emptyList<String>()
        var album = ""
        var duration = 0.0
        var lrcOffsetSeconds = 0.0

        val mutableLines = mutableListOf<LyricLine>()
        val gapMarkers = mutableListOf<Double>()
        val issues = mutableListOf<ParseIssue>()

        content.lineSequence().forEachIndexed { idx, rawLine ->
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty()) return@forEachIndexed
            val lineNumber = idx + 1

            val metaMatch = LRC_METADATA_TAG_REGEX.matchEntire(trimmed)
            if (metaMatch != null) {
                val tag = metaMatch.groupValues[1].lowercase(Locale.ROOT)
                val value = metaMatch.groupValues[2].trim()
                if (value.isNotEmpty()) {
                    when (tag) {
                        "ti", "title" -> title = value
                        "ar", "artist" -> artists = listOf(value)
                        "al", "album" -> album = value
                        "offset" -> value.toDoubleOrNull()?.let { ms -> lrcOffsetSeconds = ms / 1000.0 }
                        "length" -> {
                            val lenMatch = LENGTH_REGEX.matchEntire(value)
                            if (lenMatch != null) {
                                parseLrcClock(
                                    lenMatch.groupValues[1],
                                    lenMatch.groupValues[2],
                                    lenMatch.groupValues.getOrNull(3)?.takeIf { it.isNotEmpty() }
                                )?.let { duration = it }
                            }
                        }
                    }
                }
                return@forEachIndexed
            }

            val tagMatches = LINE_TIMESTAMP_REGEX.findAll(trimmed).toList()
            if (tagMatches.isEmpty()) {
                issues.add(ParseIssue(lineNumber, trimmed, "unparsed"))
                return@forEachIndexed
            }

            val timestamps = tagMatches.mapNotNull { m ->
                parseLrcClock(
                    m.groupValues[1],
                    m.groupValues[2],
                    m.groupValues.getOrNull(3)?.takeIf { it.isNotEmpty() }
                )?.let { rawTs -> (rawTs - lrcOffsetSeconds).coerceAtLeast(0.0) }
            }
            if (timestamps.isEmpty()) {
                issues.add(ParseIssue(lineNumber, trimmed, "invalid-timestamp"))
                return@forEachIndexed
            }
            if (timestamps.size < tagMatches.size) {
                issues.add(ParseIssue(lineNumber, trimmed, "ignored-timestamp"))
            }

            val textWithoutLineTags = trimmed.replace(LINE_TIMESTAMP_REGEX, "")
            if (timestamps.size == 1) {
                val inlineResult = parseInlineWordTags(textWithoutLineTags, timestamps[0])
                if (inlineResult.isFailure) {
                    issues.add(ParseIssue(lineNumber, trimmed, "invalid-timestamp"))
                    return@forEachIndexed
                }
                val inlineParsed = inlineResult.getOrNull()
                if (inlineParsed != null) {
                    mutableLines.add(
                        LyricLine(
                            id = NanoIdGenerator.generateLineId(),
                            text = inlineParsed.cleanText,
                            agentId = "v1",
                            begin = timestamps[0],
                            words = inlineParsed.words
                        )
                    )
                    return@forEachIndexed
                }
            }

            val rawCleanText = textWithoutLineTags.replace(INLINE_WORD_TAG_REGEX, "").trim()
            val sectionHeaderRegex = Regex("^\\[(?:verse|chorus|bridge|intro|outro|hook|pre-chorus|interlude|refrain|solo|instrumental).*]$", RegexOption.IGNORE_CASE)
            if (rawCleanText.isEmpty() || sectionHeaderRegex.matches(rawCleanText)) {
                gapMarkers.addAll(timestamps)
                return@forEachIndexed
            }
            val agentMatch = Regex("^(@a|@b|@both|v\\d+|\\[duet]|\\[harmony]|\\[chorus]):\\s*(.+)$", RegexOption.IGNORE_CASE)
                .matchEntire(rawCleanText)
            val resolvedAgentId: String
            val cleanText: String
            if (agentMatch != null) {
                val rawTag = agentMatch.groupValues[1].lowercase(Locale.ROOT)
                resolvedAgentId = when {
                    rawTag == "@a" || rawTag == "v1" -> "v1"
                    rawTag == "@b" || rawTag.contains("duet") || rawTag == "v2" -> "v2"
                    rawTag == "@both" || rawTag.contains("harmony") || rawTag == "v1000" -> "v1000"
                    rawTag.contains("chorus") || rawTag == "v2000" -> "v2000"
                    else -> "v1"
                }
                cleanText = agentMatch.groupValues[2].trim()
            } else {
                resolvedAgentId = "v1"
                cleanText = rawCleanText
            }
            for (begin in timestamps) {
                mutableLines.add(
                    LyricLine(
                        id = NanoIdGenerator.generateLineId(),
                        text = cleanText,
                        agentId = resolvedAgentId,
                        begin = begin
                    )
                )
            }
        }

        // fillLineEnds logic from src/utils/lyrics-parsers/lrc.ts
        mutableLines.sortBy { it.begin ?: 0.0 }
        gapMarkers.sort()
        val songEnd = duration.takeIf { it > 0.0 } ?: fallbackDuration

        for (i in mutableLines.indices) {
            val begin = mutableLines[i].begin ?: continue
            val nextBegin = mutableLines.getOrNull(i + 1)?.begin
            val gap = gapMarkers.firstOrNull { it > begin }
            val resolvedEnd = if (gap != null && (nextBegin == null || gap < nextBegin)) gap else nextBegin
            mutableLines[i] = mutableLines[i].copy(end = resolvedEnd)
        }

        if (mutableLines.isNotEmpty()) {
            val lastIdx = mutableLines.lastIndex
            val last = mutableLines[lastIdx]
            if (last.words == null && last.begin != null && last.end == null && songEnd != null && songEnd > last.begin) {
                mutableLines[lastIdx] = last.copy(end = songEnd)
            }
        }

        for (i in mutableLines.indices) {
            val words = mutableLines[i].words?.toMutableList() ?: continue
            val lastWord = words.lastOrNull() ?: continue
            if (lastWord.end == PENDING_WORD_END) {
                val candidates = listOfNotNull(mutableLines[i].end, mutableLines.getOrNull(i + 1)?.begin, songEnd)
                val end = candidates.firstOrNull { it > lastWord.begin }
                    ?: (lastWord.begin + TtmlConstants.DEFAULT_MIN_WORD_DURATION)
                words[words.lastIndex] = lastWord.copy(end = end)
                mutableLines[i] = mutableLines[i].copy(words = words)
            }
        }

        val reconciled = mutableLines.map { it.reconcile() }.let { list ->
            if (autoExtractBackgroundVocals) BackgroundVocalExtractor.extractBackgroundVocals(list) else list
        }

        return ParseResult(
            lines = reconciled,
            metadata = ProjectMetadata(
                title = title,
                artists = artists,
                album = album,
                duration = songEnd ?: 0.0
            ),
            hasTimingData = reconciled.any { it.isLineTimed },
            issues = issues
        )
    }

    /**
     * Parses plain text (.txt) or auto-detects .ttml / .lrc / .txt
     */
    fun parsePlainText(
        content: String,
        fallbackDuration: Double? = null,
        autoExtractBackgroundVocals: Boolean = true
    ): ParseResult {
        val sectionHeaderRegex = Regex("^\\[(?:verse|chorus|bridge|intro|outro|hook|pre-chorus|interlude|refrain|solo|instrumental).*]$", RegexOption.IGNORE_CASE)
        val rawLines = content.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && !sectionHeaderRegex.matches(it) }
            .map { text ->
                // Support @A:, @B:, @Both: (from ttml_lyrics_generator-4.ipynb) as well as v1:, v2:, [Duet]:
                val agentMatch = Regex("^(@a|@b|@both|v\\d+|\\[duet]|\\[harmony]|\\[chorus]):\\s*(.+)$", RegexOption.IGNORE_CASE)
                    .matchEntire(text)
                if (agentMatch != null) {
                    val rawTag = agentMatch.groupValues[1].lowercase(Locale.ROOT)
                    val agentId = when {
                        rawTag == "@a" || rawTag == "v1" -> "v1"
                        rawTag == "@b" || rawTag.contains("duet") || rawTag == "v2" -> "v2"
                        rawTag == "@both" || rawTag.contains("harmony") || rawTag == "v1000" -> "v1000"
                        rawTag.contains("chorus") || rawTag == "v2000" -> "v2000"
                        else -> "v1"
                    }
                    LyricLine(id = NanoIdGenerator.generateLineId(), text = agentMatch.groupValues[2].trim(), agentId = agentId)
                } else {
                    LyricLine(id = NanoIdGenerator.generateLineId(), text = text, agentId = "v1")
                }
            }
            .toList()

        val processed = if (autoExtractBackgroundVocals) {
            BackgroundVocalExtractor.extractBackgroundVocals(rawLines)
        } else rawLines

        return ParseResult(
            lines = processed,
            metadata = ProjectMetadata(duration = fallbackDuration ?: 0.0),
            hasTimingData = false
        )
    }

    fun parseAnyLyricsFile(
        filename: String,
        content: String,
        fallbackDuration: Double? = null,
        autoExtractBackgroundVocals: Boolean = true
    ): ParseResult {
        val trimmed = content.trim()
        val lowerName = filename.lowercase(Locale.ROOT)
        return when {
            lowerName.endsWith(".ttml") || lowerName.endsWith(".xml") || trimmed.startsWith("<tt") || trimmed.startsWith("<?xml") ->
                TtmlValidatorAndParser.parseTtml(trimmed, fallbackDuration)
            lowerName.endsWith(".lrc") || SyncTypeDetector.detectLrcSyncType(trimmed) != SyncType.UNSYNCED ->
                parseLrc(trimmed, fallbackDuration, autoExtractBackgroundVocals)
            else ->
                parsePlainText(trimmed, fallbackDuration, autoExtractBackgroundVocals)
        }
    }
}

// ================================================================================================
// 3. LOCAL AUDIO TAG & ISRC EXTRACTOR (Mirrors src/utils/audio-tags.ts & isrc.ts)
// ================================================================================================

object AudioTagExtractor {
    private val ISRC_REGEX = Regex("^[A-Z]{2}[A-Z0-9]{3}\\d{7}$")

    fun normalizeIsrc(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val cleaned = raw.uppercase(Locale.ROOT).replace(Regex("[^A-Z0-9]"), "")
        return if (ISRC_REGEX.matches(cleaned)) cleaned else null
    }

    fun extractMetadataFromUri(context: Context, audioUri: Uri): ProjectMetadata {
        val retriever = MediaMetadataRetriever()
        var title = ""
        val artists = mutableListOf<String>()
        var album = ""
        var durationSec = 0.0
        val songwriters = mutableListOf<String>()
        var isrc: String? = null

        try {
            retriever.setDataSource(context, audioUri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty()
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim()?.takeIf { it.isNotEmpty() }?.let {
                artists.addAll(it.split(featRegex).map { s -> s.trim() }.filter { s -> s.isNotEmpty() })
            }
            album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.trim().orEmpty()
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let { ms ->
                durationSec = ms / 1000.0
            }
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPOSER)?.trim()?.takeIf { it.isNotEmpty() }?.let {
                songwriters.addAll(it.split("/", ",", ";").map { s -> s.trim() }.filter { s -> s.isNotEmpty() })
            }
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_WRITER)?.trim()?.takeIf { it.isNotEmpty() }?.let {
                for (w in it.split("/", ",", ";").map { s -> s.trim() }) {
                    if (w.isNotEmpty() && !songwriters.contains(w)) songwriters.add(w)
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        // Scan raw header bytes for ID3v2 TSRC or Vorbis/FLAC ISRC= tag
        try {
            context.contentResolver.openInputStream(audioUri)?.use { input ->
                isrc = scanStreamForIsrc(input)
            }
        } catch (_: Exception) {
        }

        return ProjectMetadata(
            title = title,
            artists = artists.distinct(),
            album = album,
            duration = durationSec,
            isrc = isrc,
            songwriters = songwriters.takeIf { it.isNotEmpty() }
        )
    }

    private val featRegex = Regex("\\s*(?:/|;|feat\\.?|ft\\.?)\\s*", RegexOption.IGNORE_CASE)

    private fun scanStreamForIsrc(input: InputStream): String? {
        val header = ByteArray(minOf(65536, 131072))
        val read = input.read(header)
        if (read <= 16) return null
        val ascii = String(header, 0, read, StandardCharsets.ISO_8859_1)

        // 1. Vorbis / FLAC comment: ISRC=CCXXXYYNNNNN
        val vorbisMatch = Regex("ISRC=([A-Z]{2}-?[A-Z0-9]{3}-?\\d{2}-?\\d{5})", RegexOption.IGNORE_CASE).find(ascii)
        if (vorbisMatch != null) {
            normalizeIsrc(vorbisMatch.groupValues[1])?.let { return it }
        }

        // 2. ID3v2 TSRC frame
        val tsrcIdx = ascii.indexOf("TSRC")
        if (tsrcIdx >= 0 && tsrcIdx + 22 <= read) {
            val window = ascii.substring(tsrcIdx + 4, minOf(read, tsrcIdx + 32))
            val match = Regex("([A-Z]{2}[A-Z0-9]{3}\\d{7})").find(window)
            if (match != null) {
                normalizeIsrc(match.groupValues[1])?.let { return it }
            }
        }
        return null
    }
}

// ================================================================================================
// 4. LRCLIB + SECONDARY LYRICS SEARCH CLIENT (Mirrors src/utils/lyrics-search/providers/lrclib.ts)
// ================================================================================================

data class LyricsSearchQuery(
    val track: String,
    val artist: String = "",
    val album: String = "",
    val durationSec: Double? = null,
    val isrc: String? = null
)

sealed class LyricsSearchPayload {
    data class Lrc(val synced: String?, val plain: String?) : LyricsSearchPayload()
    data class Ttml(val xml: String) : LyricsSearchPayload()
}

data class LyricsSearchResult(
    val id: String,
    val source: String,
    val sourceLabel: String,
    val syncType: SyncType,
    val durationBadge: DurationMatchBadge,
    val track: String,
    val artist: String,
    val album: String?,
    val durationSec: Int?,
    val payload: LyricsSearchPayload
)

@Serializable
data class LrcLibResponseDto(
    val id: Long,
    val trackName: String = "",
    val artistName: String = "",
    val albumName: String? = null,
    val duration: Double? = null,
    val instrumental: Boolean = false,
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null
)

@Serializable
data class BinimumResultDto(
    val id: String = "",
    @SerialName("track_name") val trackName: String = "",
    @SerialName("artist_name") val artistName: String = "",
    @SerialName("album_name") val albumName: String? = null,
    val duration: Double? = null,
    val isrc: String? = null,
    @SerialName("timing_type") val timingType: String = "line",
    val lyricsUrl: String = ""
)

@Serializable
data class BinimumResponseDto(
    val total: Int = 0,
    val results: List<BinimumResultDto> = emptyList()
)

class LrclibClient(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    companion object {
        private const val LRCLIB_BASE_URL = "https://lrclib.net"
        private const val SEARCH_PATH = "/api/search"
        private const val GET_PATH = "/api/get"
        private const val ID_PREFIX = "lrclib-"
        private const val USER_AGENT = "BetterLyricsAndroid/1.0.0 (https://composer.betterlyrics.org)"
    }

    fun canRunGet(query: LyricsSearchQuery): Boolean =
        query.track.isNotBlank() &&
            query.artist.isNotBlank() &&
            query.album.isNotBlank() &&
            query.durationSec != null &&
            query.durationSec.isFinite() &&
            query.durationSec > 0.0

    private fun deriveSyncType(synced: String?, plain: String?): SyncType? {
        if (!synced.isNullOrBlank()) return SyncTypeDetector.detectLrcSyncType(synced)
        if (!plain.isNullOrBlank()) return SyncType.UNSYNCED
        return null
    }

    private fun mapResponseToResult(
        dto: LrcLibResponseDto,
        targetDurationSec: Double?
    ): LyricsSearchResult? {
        val synced = dto.syncedLyrics?.takeIf { it.isNotBlank() }
        val plain = dto.plainLyrics?.takeIf { it.isNotBlank() }
        val syncType = deriveSyncType(synced, plain) ?: return null
        val usableDur = SyncTypeDetector.toUsableDurationSec(dto.duration)

        return LyricsSearchResult(
            id = "$ID_PREFIX${dto.id}",
            source = "lrclib",
            sourceLabel = "LRCLib",
            syncType = syncType,
            durationBadge = SyncTypeDetector.computeDurationBadge(usableDur, targetDurationSec),
            track = dto.trackName,
            artist = dto.artistName,
            album = dto.albumName?.takeIf { it.isNotBlank() },
            durationSec = usableDur,
            payload = LyricsSearchPayload.Lrc(synced = synced, plain = plain)
        )
    }

    private fun fetchSearchSync(query: LyricsSearchQuery): List<LrcLibResponseDto> {
        val urlBuilder = "$LRCLIB_BASE_URL$SEARCH_PATH".toHttpUrlOrNull()?.newBuilder() ?: return emptyList()
        urlBuilder.addQueryParameter("track_name", query.track.trim())
        if (query.artist.isNotBlank()) urlBuilder.addQueryParameter("artist_name", query.artist.trim())
        if (query.album.isNotBlank()) urlBuilder.addQueryParameter("album_name", query.album.trim())
        if (query.durationSec != null && query.durationSec.isFinite() && query.durationSec > 0.0) {
            urlBuilder.addQueryParameter("duration", query.durationSec.roundToInt().toString())
        }

        val request = Request.Builder()
            .url(urlBuilder.build())
            .header("User-Agent", USER_AGENT)
            .get()
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val body = response.body?.string() ?: return emptyList()
                json.decodeFromString<List<LrcLibResponseDto>>(body)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun fetchGetSync(query: LyricsSearchQuery): LrcLibResponseDto? {
        if (!canRunGet(query)) return null
        val urlBuilder = "$LRCLIB_BASE_URL$GET_PATH".toHttpUrlOrNull()?.newBuilder() ?: return null
        urlBuilder.addQueryParameter("track_name", query.track.trim())
        urlBuilder.addQueryParameter("artist_name", query.artist.trim())
        urlBuilder.addQueryParameter("album_name", query.album.trim())
        urlBuilder.addQueryParameter("duration", query.durationSec!!.roundToInt().toString())

        val request = Request.Builder()
            .url(urlBuilder.build())
            .header("User-Agent", USER_AGENT)
            .get()
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                json.decodeFromString<LrcLibResponseDto>(body)
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Exact port of search(query, signal) in src/utils/lyrics-search/providers/lrclib.ts
     * Queries /api/search and /api/get concurrently, puts exact /api/get match first, and deduplicates by ID.
     */
    suspend fun search(query: LyricsSearchQuery): List<LyricsSearchResult> = withContext(Dispatchers.IO) {
        if (query.track.isBlank()) return@withContext emptyList()

        supervisorScope {
            val searchDeferred = async { fetchSearchSync(query) }
            val getDeferred = if (canRunGet(query)) async { fetchGetSync(query) } else null

            val searchResponses = runCatching { searchDeferred.await() }.getOrDefault(emptyList())
            val getResponse = runCatching { getDeferred?.await() }.getOrNull()

            val merged = mutableListOf<LyricsSearchResult>()
            val seenIds = mutableSetOf<String>()

            if (getResponse != null) {
                val exact = mapResponseToResult(getResponse, query.durationSec)
                if (exact != null) {
                    merged.add(exact)
                    seenIds.add(exact.id)
                }
            }

            for (candidate in searchResponses) {
                val mapped = mapResponseToResult(candidate, query.durationSec) ?: continue
                if (seenIds.add(mapped.id)) {
                    merged.add(mapped)
                }
            }

            merged
        }
    }
}
