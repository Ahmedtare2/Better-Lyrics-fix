package org.betterlyrics.android

import org.betterlyrics.android.alignment.SongWideCtc
import org.betterlyrics.android.alignment.SongWideEmissions
import org.betterlyrics.android.alignment.SongWideLine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Synthetic checks of the v5.13 song-wide CTC anchor logic. Vocabulary: 0 = blank, 1..4 = characters.
 * A "sung" character is a 2-frame spike (log-prob -0.1 on the character, blank -3); everywhere else blank wins.
 */
class SongWideCtcAnchorsTest {
    private fun emissions(frames: Int, sung: List<Pair<Double, Int>>): SongWideEmissions {
        val times = DoubleArray(frames) { 0.02 * it + 0.01 }
        val rows = Array(frames) { FloatArray(5) { v -> if (v == 0) -0.05f else -6f } }
        for ((t, id) in sung) {
            val f = (t / 0.02).toInt()
            for (d in 0..1) {
                if (f + d < frames) {
                    rows[f + d][0] = -3f
                    rows[f + d][id] = -0.1f
                }
            }
        }
        return SongWideEmissions(times, null, rows, 0, 0)
    }

    private fun line(begin: Double, end: Double, vararg ids: Int) =
        SongWideLine(ids, BooleanArray(ids.size) { false }, begin, end)

    private fun spikes(start: Double, ids: IntArray, step: Double = 0.25) = ids.mapIndexed { i, id -> Pair(start + i * step, id) }

    @Test
    fun lineSungThreeSecondsBeforeItsStampIsMoved() {
        // LRC says 10.0 s and 20.0 s; the singer really starts line 2 at 16.9 s.
        val a = intArrayOf(1, 2, 3, 4)
        val b = intArrayOf(4, 3, 2, 1, 2)
        val sung = spikes(10.0, a) + spikes(16.9, b)
        val e = emissions(2000, sung)
        val plan = SongWideCtc.planAnchorMoves(e, listOf(line(10.0, 20.0, *a), line(20.0, 36.0, *b)))?.decisions
        assertNotNull(plan)
        assertFalse(plan!![0].moved)
        assertTrue(plan[1].moved)
        assertEquals(16.9, plan[1].songWideBegin, 0.15)
    }

    @Test
    fun correctlyStampedLinesAreLeftAlone() {
        val a = intArrayOf(1, 2, 3, 4)
        val b = intArrayOf(4, 3, 2, 1, 2)
        val sung = spikes(10.0, a) + spikes(20.0, b)
        val e = emissions(2000, sung)
        val plan = SongWideCtc.planAnchorMoves(e, listOf(line(10.0, 20.0, *a), line(20.0, 36.0, *b)))?.decisions
        assertNotNull(plan)
        assertTrue(plan!!.none { it.moved })
    }

    @Test
    fun identicalRepeatedLinesDoNotSlideOntoTheWrongRepetition() {
        // Two identical lines at 10 s and 20 s; the soft prior must keep the second one at 20 s although the
        // first repetition could also "explain" the second text when the stamps are 10 s apart.
        val a = intArrayOf(1, 2, 3, 4)
        val sung = spikes(10.0, a) + spikes(20.0, a)
        val e = emissions(2000, sung)
        val plan = SongWideCtc.planAnchorMoves(e, listOf(line(10.0, 20.0, *a), line(20.0, 36.0, *a)))?.decisions
        assertNotNull(plan)
        assertEquals(10.0, plan!![0].songWideBegin, 0.15)
        assertEquals(20.0, plan[1].songWideBegin, 0.15)
        assertTrue(plan.none { it.moved })
    }

    @Test
    fun unorderedStampsAreRejected() {
        val a = intArrayOf(1, 2, 3)
        val e = emissions(500, spikes(2.0, a))
        org.junit.Assert.assertNull(SongWideCtc.align(e, listOf(line(5.0, 6.0, *a), line(2.0, 3.0, *a))))
    }

    @Test
    fun arbitrationReplacesWordsThatSitSecondsFromTheSingerAndKeepsGoodOnes() {
        // two words per line: [1,2] [3,4] sung at 10.0/10.5 ; the "current" timing is either right or 3 s late
        val ids = intArrayOf(1, 2, 3, 4)
        val ln = SongWideLine(ids, BooleanArray(4) { false }, 10.0, 20.0, intArrayOf(0, 2))
        val sung = listOf(Pair(10.0, 1), Pair(10.25, 2), Pair(10.6, 3), Pair(10.85, 4))
        val e = emissions(1000, sung)
        val plan = SongWideCtc.planAnchorMoves(e, listOf(ln))!!
        val span = plan.spans[0]
        val good = SongWideCtc.arbitrate(e, ln, span, doubleArrayOf(9.95, 10.55), doubleArrayOf(10.55, 11.1))!!
        assertFalse(good.useSongWide)
        val late = SongWideCtc.arbitrate(e, ln, span, doubleArrayOf(13.0, 13.6), doubleArrayOf(13.6, 14.2))!!
        assertTrue(late.useSongWide)
        assertEquals(10.0 - SongWideCtc.SPIKE_BIAS_WORD_SEC, late.begins[0], 0.1)
    }
}
