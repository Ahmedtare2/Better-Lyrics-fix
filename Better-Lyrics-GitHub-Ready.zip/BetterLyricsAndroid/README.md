# BetterLyricsAndroid — 100% Offline Studio TTML Lyric Synchronizer (`composer-master` Compatible)

An offline-first, serverless Android application (`minSdk = 26`, `targetSdk = 35`) engineered for studio-grade, word-by-word and syllable-accurate **TTML (`Timed Text Markup Language`)** synchronization for **Arabic (`ar`)** and **English (`en`)** songs, with **100% bidirectional compatibility** with `composer-master` (Better Lyrics Composer).

## Project Tree

```text
BetterLyricsAndroid/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── scripts/
│   └── export-models-and-bundle-web.sh
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── assets/
        │   │   └── composer-ui/
        │   │       └── index.html
        │   ├── java/org/betterlyrics/android/
        │   │   ├── domain/ttml/
        │   │   │   └── TtmlModelsAndCodec.kt
        │   │   ├── data/lyrics/
        │   │   │   └── LyricsParsersAndLrclibClient.kt
        │   │   ├── dsp/
        │   │   │   └── AudioDspAndDemucsEngine.kt
        │   │   ├── alignment/
        │   │   │   └── BilingualForcedAlignmentEngine.kt
        │   │   ├── service/
        │   │   │   └── AlignmentForegroundServiceAndModelManager.kt
        │   │   └── ui/
        │   │       └── MainActivityAndComposeUi.kt
        │   └── res/values/
        │       ├── strings.xml
        │       └── themes.xml
        └── test/java/org/betterlyrics/android/
            └── TtmlAndDspParityTest.kt
```

## Building the APK

1. Open `BetterLyricsAndroid` in **Android Studio Ladybug (2024.2.1+)** or run from terminal with JDK 17:
   ```bash
   gradle wrapper
   ./gradlew :app:assembleDebug
   ```
   The compiled APK is emitted to `app/build/outputs/apk/debug/app-debug.apk`.

2. **Offline ONNX Models (`context.filesDir/models/`)**:
   - Open the **ONNX & XML** tab inside the app to download `htdemucs_fp32.onnx` (171 MB), `htdemucs_fp16.onnx` (85 MB), and `mms_fa_ar_en_fp32.onnx` (315 MB) once, **or** tap **Sideload .onnx File** to import them directly from local device storage via Android SAF (`ACTION_OPEN_DOCUMENT`) for 100% air-gapped operation.
