#!/usr/bin/env bash
# ================================================================================================
# Better Lyrics Android — Offline ONNX Model Exporter & composer-master Web Asset Bundler
# ================================================================================================
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODELS_OUT="${ROOT_DIR}/exported-onnx-models"
ASSETS_WEB_DIR="${ROOT_DIR}/app/src/main/assets/composer-ui"

mkdir -p "${MODELS_OUT}" "${ASSETS_WEB_DIR}"

echo "==> [1/3] Exporting Multilingual Arabic (ar) + English (en) CTC Forced Alignment ONNX Model"
python3 - <<'PY'
import os, json
try:
    import torch
    from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
except ImportError:
    print("Install torch, transformers, onnx to export mms_fa_ar_en_fp32.onnx:")
    print("  pip install torch torchaudio transformers onnx onnxruntime")
    raise SystemExit(0)

out_dir = os.environ.get("MODELS_OUT", "./exported-onnx-models")
model_id = "jonatasgrosman/wav2vec2-large-xlsr-53-arabic"
print(f"Loading {model_id}...")
processor = Wav2Vec2Processor.from_pretrained(model_id)
model = Wav2Vec2ForCTC.from_pretrained(model_id).eval()

dummy_input = torch.randn(1, 16000 * 5, dtype=torch.float32)
onnx_path = os.path.join(out_dir, "mms_fa_ar_en_fp32.onnx")

torch.onnx.export(
    model,
    (dummy_input,),
    onnx_path,
    input_names=["input_values"],
    output_names=["logits"],
    dynamic_axes={
        "input_values": {1: "audio_samples"},
        "logits": {1: "time_frames"}
    },
    opset_version=17
)
vocab_path = os.path.join(out_dir, "vocab_ar_en.json")
with open(vocab_path, "w", encoding="utf-8") as f:
    json.dump(processor.tokenizer.get_vocab(), f, ensure_ascii=False, indent=2)
print(f"Saved {onnx_path} and {vocab_path}")
PY

echo "==> [2/3] To export HTDemucs ONNX (htdemucs_fp32.onnx & htdemucs_fp16.onnx):"
echo "    Run composer-master/scripts/build-htdemucs-onnx.sh ${MODELS_OUT}"

echo "==> [3/3] Optional: Bundle full composer-master React build into Android WebView assets"
if [[ -n "${COMPOSER_MASTER_DIR:-}" && -d "${COMPOSER_MASTER_DIR}" ]]; then
  echo "Building composer-master from ${COMPOSER_MASTER_DIR}..."
  (cd "${COMPOSER_MASTER_DIR}" && pnpm install && pnpm build)
  cp -R "${COMPOSER_MASTER_DIR}/dist/"* "${ASSETS_WEB_DIR}/"
  echo "Copied composer-master dist/ into ${ASSETS_WEB_DIR}/"
fi
